import java.io.File;
import org.x2.export.PlaylistPreparer;
import org.x2.export.NativeRemux;

public final class NativeTest {
    public static void main(String[] args) {
        try { run(args); }
        catch (Throwable error) {
            System.out.println("NATIVE_REMUX_REJECTED " + error.getClass().getName() + ": " + error.getMessage());
            System.exit(2);
        }
    }
    private static void run(String[] args) throws Exception {
        if (args.length != 3) throw new IllegalArgumentException("cache work output");
        PlaylistPreparer.Prepared p = PlaylistPreparer.prepare(new File(args[0]), new File(args[1]));
        System.out.println("PREPARED segments=" + p.segments + " duration=" + p.durationSeconds + " source=" + p.sourceName);
        String error = NativeRemux.run(p.playlist.getAbsolutePath(), args[2], p.durationSeconds,
            new NativeRemux.Progress() {
                public void update(double value) { }
                public boolean cancelled() { return false; }
            });
        if (error != null && error.length() > 0) throw new IllegalStateException(error);
        System.out.println("NATIVE_REMUX_SUCCESS");
    }
}
