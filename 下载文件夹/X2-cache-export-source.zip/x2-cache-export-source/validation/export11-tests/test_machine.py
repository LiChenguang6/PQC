import prepare
from pathlib import Path
import json,struct,sys
from unicorn import *
from unicorn.arm64_const import *
from unicorn.x86_const import *
B=Path('/workspace/x2-analysis');R=B/'export11-tests';sys.path.insert(0,str(B/'export-patch'))
from patch_tasks_short import S
results=[]
for abi,s in S.items():
 arm=abi=='arm64-v8a';d=(R/'asm'/f'{abi}-patched.so').read_bytes();u=Uc(UC_ARCH_ARM64 if arm else UC_ARCH_X86,UC_MODE_ARM if arm else UC_MODE_64);u.mem_map(0,0x900000);u.mem_write(0,d);u.mem_map(0x1000000,0x40000);u.mem_map(0x2000000,0x10000)
 heap=0x1000000;stack=0x2008000;model=heap+0x101;t=heap+0x1001;url=heap+0x2001;null=heap+0x81;pool=heap+0x10000;thr=heap+0x8000
 def put(at,v,fmt='Q'):u.mem_write(at,struct.pack('<'+fmt,v))
 def string(at,text):
  b=text.encode('utf-16le');put(at-1,95<<12,'I');put(at+7,len(b),'I');u.mem_write(at+15,b)
 def regs(values):
  for r,v in values.items():u.reg_write(r,v)
 regs({UC_ARM64_REG_X15:stack,UC_ARM64_REG_X29:stack+0x100,UC_ARM64_REG_X22:null,UC_ARM64_REG_X28:0,UC_ARM64_REG_X27:pool} if arm else {UC_X86_REG_RSP:stack,UC_X86_REG_RBP:stack+0x100,UC_X86_REG_R14:thr,UC_X86_REG_R15:pool})
 put(thr+0x48,0);put(thr+0x78,null);put(thr+0x80,null+0x20);put(thr+0x38,0);put(model+0x53,t,'I');put(model+0x67,heap+0x301,'I')
 for i in range(5):
  title='短视频标题😀 '+str(i);uri='https://fixture.invalid/视频'+str(i)+'.mp4';string(t,title);string(url,uri)
  regs({UC_ARM64_REG_X1:model,UC_ARM64_REG_X15:stack} if arm else {UC_X86_REG_RDI:model,UC_X86_REG_RSP:stack})
  u.emu_start(s['entry'],s['entry']+(4 if arm else 7),count=10000)
  regs({UC_ARM64_REG_X0:url} if arm else {UC_X86_REG_RAX:url})
  if not arm:put(stack+0x100,0x1234);put(stack+0x108,0x200f000)
  u.emu_start(s['end'],s['end']+4 if arm else 0x200f000,count=10000)
  if not arm:u.reg_write(UC_X86_REG_RBP,stack+0x100)
 snapshots=[]
 for i in range(4):
  at=s['buffer']+0x6000+i*0x5000;tl,ul,seq,magic=struct.unpack('<IIII',u.mem_read(at,16));assert magic==0x35543258 and seq%2==0
  snapshots.append(bytes(u.mem_read(at+16,tl*2)).decode('utf-16le'))
 assert set(snapshots)=={'短视频标题😀 '+str(i) for i in range(1,5)},snapshots
 results.append(dict(abi=abi,four_preloaded_video_titles_retained=True,unicode_title_and_URI_copy=True))
 for index in [0,2,4,0]:
  put(s['buffer']+0x4900,0,'I');put(model+0x1f,heap+0x401,'I')
  regs({UC_ARM64_REG_X0:model,UC_ARM64_REG_X2:index,UC_ARM64_REG_X15:stack} if arm else {UC_X86_REG_RAX:model,UC_X86_REG_RSI:index,UC_X86_REG_RSP:stack})
  u.emu_start(s['nav'],s['nav']+(4 if arm else 7),count=100)
  assert struct.unpack('<I',u.mem_read(s['buffer']+0x4900,4))[0]==(1 if index==0 else 0)
  assert u.reg_read(UC_ARM64_REG_X2 if arm else UC_X86_REG_RSI)==(2 if index==0 else index)
 results.append(dict(abi=abi,left_tab_requests_native_manager=True,other_tab_indices_preserved=True))
 download=heap+0x4001;string(download,'下载');put(pool+(0x1bd68 if arm else 0x1bee7),download)
 for label in ['活动','视频']:
  string(t,label);put(model+0xf,heap+0x501,'I');regs({UC_ARM64_REG_X0:model,UC_ARM64_REG_X5:t,UC_ARM64_REG_X15:stack} if arm else {UC_X86_REG_RAX:model,UC_X86_REG_RBX:t,UC_X86_REG_RSP:stack})
  u.emu_start(s['caption'],s['caption']+(4 if arm else 7),count=100)
  assert u.reg_read(UC_ARM64_REG_X5 if arm else UC_X86_REG_RBX)==(download if label=='活动' else t)
 results.append(dict(abi=abi,only_activity_caption_replaced=True))
 for enabled in [0,1]:
  put(s['buffer']+0x4904,enabled,'I')
  regs({UC_ARM64_REG_X15:stack,UC_ARM64_REG_X30:0,UC_ARM64_REG_X0:0} if arm else {UC_X86_REG_RSP:stack,UC_X86_REG_RAX:0})
  u.emu_start(s['preview'],s['preview']+(4 if arm else 5) if enabled else s['preview_original'],count=100)
  if enabled:assert u.reg_read(UC_ARM64_REG_X0 if arm else UC_X86_REG_RAX)==null
 results.append(dict(abi=abi,preview_timer_off_calls_original=True,preview_timer_on_returns_without_marking_end=True))
(R/'machine-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print('PASS short-title ring, task entry, caption, development gate and guarded preview timer on both ABIs')
