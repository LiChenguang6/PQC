"""Add narrow media_kit lifecycle callbacks; leave original native libs intact."""
from pathlib import Path
import re


def _insert(path: Path, method: str, call: str) -> bool:
    text = path.read_text(encoding="utf-8")
    pattern = re.compile(
        r"(^\.method " + re.escape(method) + r"\n\s*\.locals \d+\n)(.*?)(^\.end method)",
        re.MULTILINE | re.DOTALL,
    )
    match = pattern.search(text)
    if match is None:
        raise RuntimeError("Expected media_kit lifecycle method was not found: " + method)
    if call in match.group(2):
        return False
    text = text[:match.start()] + match.group(1) + "\n    " + call + "\n" + match.group(2) + match.group(3) + text[match.end():]
    path.write_text(text, encoding="utf-8")
    return True


def inject(decoded) -> dict:
    """Idempotently attach/detach the observer at already-valid player handles."""
    decoded = Path(decoded)
    manager_candidates = sorted(decoded.glob("smali*/l4/d.smali"))
    plugin_candidates = sorted(decoded.glob("smali*/l4/a.smali"))
    if len(manager_candidates) != 1 or len(plugin_candidates) != 1:
        raise RuntimeError("Expected exactly one original media_kit output manager and plugin")
    manager, plugin = manager_candidates[0], plugin_candidates[0]
    return {
        "register": _insert(manager, "public final a(J)Ll4/c;", "invoke-static {p1, p2}, Lorg/x2/export/PlayerCapture;->register(J)V"),
        "unregister": _insert(manager, "public final c(J)V", "invoke-static {p1, p2}, Lorg/x2/export/PlayerCapture;->unregister(J)V"),
        "clear": _insert(plugin, "public final onDetachedFromEngine(Li9/a$b;)V", "invoke-static {}, Lorg/x2/export/PlayerCapture;->clear()V"),
    }


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("decoded", type=Path)
    print(inject(parser.parse_args().decoded))
