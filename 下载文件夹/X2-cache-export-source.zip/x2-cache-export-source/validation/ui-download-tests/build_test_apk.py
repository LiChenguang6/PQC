from pathlib import Path
import subprocess
import zipfile

BASE = Path('/workspace/x2-analysis')
ROOT = BASE / 'ui-download-tests'
TOOLS = BASE / 'patch-tools'
PATCH = BASE / 'export-patch'
BUILD = ROOT / 'build'
BUILD.mkdir(exist_ok=True)
(BUILD / 'classes').mkdir(exist_ok=True)
(BUILD / 'dex').mkdir(exist_ok=True)
ANDROID = TOOLS / 'android-35/android.jar'


def run(*args):
    subprocess.run([str(x) for x in args], check=True)


run('java', '-jar', TOOLS / 'ecj.jar', '-source', '1.8', '-target', '1.8', '-encoding', 'UTF-8',
    '-bootclasspath', ANDROID, '-classpath', str(PATCH / 'build/classes')+':'+str(PATCH / 'build/lambda-stubs'), '-d', BUILD / 'classes',
    ROOT / 'src/org/x2/uitests/DownloadInstrumentation.java',
    BASE / 'capture-tests/src/org/x2/capturetests/CaptureNative.java')
run(TOOLS / 'android-15/d8', '--min-api', '24', '--lib', ANDROID,
    '--classpath', PATCH / 'build/classes', '--output', BUILD / 'dex',
    *sorted((BUILD / 'classes').rglob('*.class')))
run(TOOLS / 'android-15/aapt2', 'link', '-I', ANDROID, '--manifest', ROOT / 'AndroidManifest.xml',
    '-o', BUILD / 'test-unsigned.apk')
with zipfile.ZipFile(BUILD / 'test-unsigned.apk', 'a', compression=zipfile.ZIP_DEFLATED) as archive:
    archive.write(BUILD / 'dex/classes.dex', 'classes.dex')
    archive.write(BASE / 'capture-tests/build/libcapturetest.so', 'lib/x86_64/libcapturetest.so')
run(TOOLS / 'android-15/zipalign', '-f', '4', BUILD / 'test-unsigned.apk', BUILD / 'test-aligned.apk')
run(TOOLS / 'android-15/apksigner', 'sign', '--ks', PATCH / 'build/local-export-key.p12',
    '--ks-pass', 'pass:android', '--key-pass', 'pass:android', '--ks-key-alias', 'x2-export',
    '--out', BUILD / 'test.apk', BUILD / 'test-aligned.apk')
run(BASE / 'android-sdk/platform-tools/adb', '-s', 'emulator-5554', 'install', '-r', BUILD / 'test.apk')
