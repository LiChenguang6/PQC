"""Restore exactly four original instruction sites, with before-image assertions.
This is a baseline experiment, not a claim of restoring server entitlements.
"""
import hashlib
SITES={'arm64-v8a':[(0x70b420,4,'entering_ad_original_initialization'),(0x6bd490,4,'original_vip_getter'),(0x70c168,4,'original_progress_callback'),(0x70caa0,4,'original_pause_branch')],
       'x86_64':[(0x61f214,5,'entering_ad_original_initialization'),(0x779cc7,5,'original_vip_getter'),(0x620322,5,'original_progress_callback'),(0x620edb,6,'original_pause_branch')]}
def apply(data,original,abi,ui_report,tasks_report):
    if abi not in SITES:return data,{}
    changes={v['offset']:v for v in ui_report+tasks_report['changes']}
    out=bytearray(data);restored=[]
    for at,size,name in SITES[abi]:
        change=changes[at];before=bytes.fromhex(change['after']);assert len(before)==size
        assert data[at:at+size]==before,(abi,name,'unexpected modified input')
        expected=bytes.fromhex(change['before']);assert expected==original[at:at+size],(abi,name,'baseline mismatch')
        out[at:at+size]=expected;restored.append({'name':name,'offset':at,'before':before.hex(),'after':expected.hex()})
    return bytes(out),{'baseline':'original uploaded X2 APK','restored_sites':restored,'output_sha256':hashlib.sha256(out).hexdigest()}
