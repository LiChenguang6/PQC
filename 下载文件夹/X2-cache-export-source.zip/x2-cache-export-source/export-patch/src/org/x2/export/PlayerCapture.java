package org.x2.export;

import java.io.IOException;

/** In-memory, read-only view of media already opened by the original player. */
public final class PlayerCapture {
    private static final boolean LIBRARY_READY;
    static {
        boolean ready = false;
        try {
            System.loadLibrary("x2player");
            ready = true;
        } catch (Throwable ignored) {
            // Optional capture must never prevent the original app from playing.
        }
        LIBRARY_READY = ready;
    }

    public static final class Source {
        public final String uri;
        public final String userAgent;
        public final String referrer;
        /** Each element is one complete "Name: value" header, including commas. */
        public final String[] headers;
        public final String title;

        public Source(String uri, String userAgent, String referrer,
                      String[] headers, String title) {
            this.uri = uri;
            this.userAgent = userAgent;
            this.referrer = referrer;
            this.headers = headers == null ? new String[0] : headers.clone();
            this.title = title;
        }
    }

    /** Called only with the original handle while VideoOutput.Create is in flight. */
    public static void register(long originalHandle) {
        if (!LIBRARY_READY || originalHandle == 0) return;
        try { nativeRegister(originalHandle); } catch (Throwable ignored) { }
    }

    public static void unregister(long originalHandle) {
        if (!LIBRARY_READY) return;
        try { nativeUnregister(originalHandle); } catch (Throwable ignored) { }
    }

    public static void clear() {
        if (!LIBRARY_READY) return;
        try { nativeClear(); } catch (Throwable ignored) { }
    }

    /**
     * Call on a background thread while the original player is still visible.
     * Synchronous libmpv property access may wait for its playback core.
     */
    public static Source snapshot() throws IOException {
        if (!LIBRARY_READY) throw new IOException("播放信息读取暂不可用，请重新打开应用后重试");
        return nativeSnapshot();
    }

    public static boolean manageRequested(boolean test) {
        if(!LIBRARY_READY)return false;
        try{return nativeManageRequested(test);}catch(Throwable ignored){return false;}
    }
    private static native boolean nativeManageRequested(boolean test);
    private static native boolean nativeRegister(long originalHandle);
    private static native void nativeUnregister(long originalHandle);
    private static native void nativeClear();
    private static native Source nativeSnapshot() throws IOException;
    private PlayerCapture() { }
}
