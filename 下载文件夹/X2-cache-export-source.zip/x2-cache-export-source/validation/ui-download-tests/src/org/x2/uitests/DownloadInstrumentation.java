package org.x2.uitests;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.x2.capturetests.CaptureNative;
import org.x2.export.DownloadConfig;
import org.x2.export.DownloadStore;
import org.x2.export.ExportEntry;
import org.x2.export.PlayerCapture;

/** Test APK only. No test entry points or fixture credentials are in the user APK. */
public final class DownloadInstrumentation extends Instrumentation {
    private Bundle options;
    @Override public void onCreate(Bundle args){options=args;start();}
    @Override public void onStart(){long handle=0;try{
        String mode=options.getString("mode","capture");
        if(mode.equals("reset")){
            DownloadStore store=DownloadStore.get(getTargetContext());
            for(DownloadStore.Job job:store.all())if(job.title.startsWith("任务 ")||job.title.equals("受控测试视频"))store.remove(job);
            Bundle report=new Bundle();report.putString("result","TEST_RECORDS_RESET");finish(Activity.RESULT_OK,report);return;
        }
        if(mode.equals("seed")){
            DownloadStore store=DownloadStore.get(getTargetContext());
            for(String label:options.getString("jobs","A,B,C,D").split(",")){
                String kind=label.equals("E")?"retry":"slow";
                PlayerCapture.Source source=new PlayerCapture.Source("http://127.0.0.1:18766/"+kind+"/"+label+".mp4?fixture_nonce=BACKGROUND_TEST","X2ControlledBgTest/1.0","",new String[0],"任务 "+label);
                store.add(DownloadStore.playback(getTargetContext(),source));
            }
            Bundle report=new Bundle();report.putString("result","SEEDED_ENCRYPTED_QUEUE");report.putInt("parallel",DownloadConfig.parallel(getTargetContext()));finish(Activity.RESULT_OK,report);return;
        }
        Intent launch=new Intent();launch.setClassName(getTargetContext(),"com.tencent.a.SetupInfoActivity");launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        final Activity activity=startActivitySync(launch);
        if(mode.equals("gesture")){
            final ScrollView[] scroll=new ScrollView[1];
            runOnMainSync(new Runnable(){public void run(){
                ScrollView view=new ScrollView(activity);LinearLayout column=new LinearLayout(activity);column.setOrientation(1);
                for(int i=0;i<100;i++){TextView text=new TextView(activity);text.setText("相关测试视频 "+i);text.setTextSize(20);text.setHeight(110);column.addView(text);}
                view.addView(column);activity.setContentView(view);ExportEntry.install(activity);scroll[0]=view;
            }});
            waitForIdleSync();Thread.sleep(300);
            final View row=activity.findViewById(android.R.id.content).findViewWithTag("x2-download-buttons");int[] location=new int[2];row.getLocationOnScreen(location);
            float x=location[0]+row.getWidth()/4f,y=location[1]+row.getHeight()/2f;
            swipe(x,y,x,y-110);waitForIdleSync();Thread.sleep(400);
            int fromButton=scroll[0].getScrollY();if(fromButton<=0)throw new AssertionError("overlay consumed vertical swipe");
            for(int i=0;i<8;i++)swipe(60,620,60,260);
            waitForIdleSync();Thread.sleep(300);int after=scroll[0].getScrollY();
            if(after<=fromButton)throw new AssertionError("list did not continue scrolling");
            Bundle report=new Bundle();report.putString("result","GESTURE_FORWARDING_PASS");report.putInt("from_button_scroll",fromButton);report.putInt("after_repeated_swipes",after);finish(Activity.RESULT_OK,report);return;
        }
        System.loadLibrary("capturetest");CaptureNative.load(getTargetContext().getApplicationInfo().nativeLibraryDir+"/libmpv.so");String uri=options.getString("fixture");
        handle=CaptureNative.create(uri,"X2ControlledUiTest/1.0","",new String[0],"受控测试视频",false);PlayerCapture.register(handle);
        long deadline=System.currentTimeMillis()+30000;boolean ready=false;
        while(System.currentTimeMillis()<deadline){try{if(uri.equals(PlayerCapture.snapshot().uri)){ready=true;break;}}catch(java.io.IOException e){}Thread.sleep(100);}
        if(!ready)throw new IllegalStateException("controlled playback not ready");
        Bundle report=new Bundle();report.putString("result","CONTROLLED_PLAYER_READY");sendStatus(1,report);Thread.sleep(240000);
        PlayerCapture.unregister(handle);CaptureNative.terminate(handle);handle=0;finish(Activity.RESULT_OK,report);
    }catch(Throwable error){if(handle!=0){PlayerCapture.unregister(handle);CaptureNative.terminate(handle);}Bundle report=new Bundle();report.putString("failure",error.getClass().getSimpleName()+": "+error.getMessage());finish(Activity.RESULT_CANCELED,report);}}
    private void swipe(float x,float y,float endX,float endY){long down=SystemClock.uptimeMillis();MotionEvent event=MotionEvent.obtain(down,down,MotionEvent.ACTION_DOWN,x,y,0);event.setSource(android.view.InputDevice.SOURCE_TOUCHSCREEN);sendPointerSync(event);event.recycle();
        for(int i=1;i<=8;i++){SystemClock.sleep(25);long now=SystemClock.uptimeMillis();event=MotionEvent.obtain(down,now,i==8?MotionEvent.ACTION_UP:MotionEvent.ACTION_MOVE,x+(endX-x)*i/8,y+(endY-y)*i/8,0);event.setSource(android.view.InputDevice.SOURCE_TOUCHSCREEN);sendPointerSync(event);event.recycle();}}
}
