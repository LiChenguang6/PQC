from pathlib import Path
import json
B=Path('/workspace/x2-analysis');O=B/'output';sha=json.loads((O/'build-info.json').read_text())['output_sha256']
s=(Path('/workspace/pqc-upload/下载文件夹/使用说明.md')).read_text().replace('（export6）','（export7）').replace('9.9.9-export6','9.9.9-export7').replace('版本码 14','版本码 15')
s=s.replace('- **下载管理入口**', '- **设置的直接入口**：长按悬浮“下载”，选择“下载设置”；同一菜单也可直接打开“下载管理”。不必先找到左侧标签。直接拖动仍可移动按钮。\n- **下载管理入口**',1)
s=s.replace('首次选择', '首次选择')
s=s.replace('## 自有应用的禁区测试','## 本次入口修复\n\n管理事件监听改为由 Activity 持有，直到页面销毁才停止，不会因悬浮按钮还没挂载或临时移除而永久退出。返回页面时恢复缺失的按钮；在 Flutter 显示首帧后再打开原生管理或设置页面，保留启动初始化。\n\n## 自有应用的禁区测试')
(O/'使用说明.md').write_text(s)
(O/'VALIDATION.md').write_text(f'''# export7 验证记录

版本 `9.9.9-export7` / versionCode `15`。包名与签名保持不变，可以覆盖 export6。

APK SHA-256：`{sha}`。

## 本次问题与修改

用户报告主页“下载”标签仍为空白，无法进入设置。export6 的导航轮询捕获悬浮 View；首次运行时若 `isAttachedToWindow()` 为 false，直接返回且不再调度。先前测试手动在挂载完成后安装浮层，未覆盖初次挂载和后续 View 移除的情况。用户设备未连接，不能断言这是其黑屏的唯一原因。

export7 将导航轮询绑定到 Activity，注册一次，直到 Activity 销毁或结束才退出；不依赖悬浮 View 的挂载状态。onResume 重新安装缺失的浮层。新增长按“下载”菜单，直接进入管理或设置。打开原生页面前检查原 FlutterView 的首帧显示状态（锁定版本的 c9.r.g），保留 Flutter 初始化。

## 实际验证

使用 AOSP API 29 x86_64 软件模拟器、原 Flutter Activity 和独立测试 APK：

- 不再手动重新安装浮层，从生产 onCreate/onResume 注册开始测试管理事件；原生管理页面实际打开。
- 找到并点击管理页顶部“下载设置”，设置 Activity 包含“更改下载文件夹”等真实控件。
- 长按菜单实际显示，通过选择“下载设置”进入同一设置页。
- 移除悬浮 View 超过 1 秒后，再次发送管理事件，管理页仍可打开；返回后 onResume 恢复浮层。
- 安装 APK 的 SHA-256 与交付文件相符；签名 v2/v3 校验通过。

测试通过辅助 JNI 写入与左侧标签相同的管理事件；原标签的 AOT 逻辑沿用 export6 的两架构指令验证。本次不是云端真实首页内容端到端验证，真实平台仍不可达。

首轮辅助测试在 Flutter 首帧前触发导航时发生原生初始化阶段崩溃；单独普通启动通过。最终版本等待首帧后打开原生页面，并给测试辅助代码补上可写内存段范围检查，再完成上述测试。没有关闭全局异常处理、TLS 或原网络初始化。

## 修改范围与回归边界

相对 export6，生产源码只变更 ExportEntry.java 和 build_patch.py。所有 27 个原生库、Flutter 资源、下载服务／暂停／命名代码字节或源码保持一致；APK 变化只包含 AndroidManifest、原 Activity 生命周期调用和新增 Java 导航／菜单代码及签名文件。没有再次声称重跑 export6 的下载服务全部测试。

export6 的暂停、取消崩溃修复、并发配置、标题缓存及本机禁区测试开关保留。暂停不是跨进程字节断点续传；禁区测试开关不恢复服务端 VIP 权限。ARMv7 仍使用原主页和兼容“管理”按钮，长按入口也可用。

源码包 validation/export7-tests 包含本次测试及校验结果，其他版本结果均为历史验证。真实用户设备和真实平台主页未直接测试。
''')
print(sha)
