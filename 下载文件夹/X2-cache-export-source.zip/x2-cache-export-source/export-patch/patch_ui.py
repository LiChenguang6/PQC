"""Pinned 64-bit UI-only changes: suppress raw network debug toast and skip the
manually dismissible entering-player ad container through its own completion path.
HTTP error handling, logging, authorization and playback checks are retained.
"""
import hashlib
from patch_scroll import branch
SPECS={
 'arm64-v8a':{'input':'23479fbb7e02874b9f35707a08614e2043895350f95287a5d2f0d2ac1b17d678','toast':0x4f701c,'show_toast':0x4f7138,'entry':0x70b420,'show_ads':0x70b43c,'post_dismiss':0x70b520},
 'x86_64':{'input':'755d40ac0db208ad3cfce3f7a1ffaaee5362f1e6f7b93fc2ff0770d734128d37','toast':0x56ba27,'show_toast':0x56bb5c,'entry':0x61f214,'show_ads':0x61f22c,'post_dismiss':0x61f310}}
def apply(data,abi):
 if abi not in SPECS:return data,[]
 s=SPECS[abi];assert hashlib.sha256(data).hexdigest()==s['input'],'Unexpected pre-UI snapshot'
 buf=bytearray(data);changes=[]
 for label,at,target,replacement in [
  ('raw_network_debug_toast',s['toast'],s['show_toast'],bytes.fromhex('1f2003d5') if abi=='arm64-v8a' else b'\x90'*5),
  ('entering_ad_to_own_dismiss_completion',s['entry'],s['show_ads'],branch(abi,s['entry'],s['post_dismiss'],True))]:
  expected=branch(abi,at,target,True);assert data[at:at+len(expected)]==expected
  buf[at:at+len(replacement)]=replacement
  changes.append({'name':label,'offset':at,'before':expected.hex(),'after':replacement.hex()})
 return bytes(buf),changes
