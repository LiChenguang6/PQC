package org.x2.export;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.AdapterView;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Locale;

public final class CacheExportActivity extends Activity {
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ArrayList<File> videos = new ArrayList<File>();
    private TextView status;
    private ProgressBar progress;
    private ListView list;
    private Button refresh;
    private File selected;
    private volatile boolean busy;
    private volatile boolean cancelled;
    private static final int SAVE = 1201;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setTitle("缓存导出 MP4");
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = (int)(16 * getResources().getDisplayMetrics().density);
        root.setPadding(pad, pad, pad, pad);
        TextView intro = new TextView(this);
        intro.setText("先返回原界面，使用原有下载功能完成缓存，再点选视频导出。仅处理本导出版自身的缓存；原版数据保持独立。\n导出不重新编码，视频 ID 用于识别，未恢复影片标题。");
        root.addView(intro);
        refresh = new Button(this); refresh.setText("刷新已下载视频"); root.addView(refresh);
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) { scan(); }
        });
        status = new TextView(this); root.addView(status);
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100); root.addView(progress);
        list = new ListView(this);
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> p, View view, int pos, long id) {
                if (!busy) choose(videos.get(pos));
            }
        });
        setContentView(root);
        scan();
    }

    private void scan() {
        if (busy) return;
        videos.clear();
        File base = new File(getDir("flutter", 0), "downloads/video");
        File[] dirs = base.listFiles();
        if (dirs != null) {
            Arrays.sort(dirs, new Comparator<File>() {
                @Override public int compare(File a, File b) { return a.getName().compareTo(b.getName()); }
            });
            for (File d : dirs) if (d.isDirectory() && new File(d, "index.m3u8").isFile()) {
                try {
                    if (d.getCanonicalFile().getParentFile().equals(base.getCanonicalFile())) videos.add(d);
                } catch (IOException ignored) { }
            }
        }
        ArrayList<String> rows = new ArrayList<String>();
        for (File d : videos) {
            long size = 0; int segments = 0;
            File[] children = d.listFiles();
            if (children != null) for (File f : children) {
                if (f.isFile()) size += f.length();
                if (f.getName().toLowerCase(Locale.ROOT).endsWith(".ts")) segments++;
            }
            rows.add("视频 " + d.getName() + "\n缓存完成标记存在 · " + segments + " 个 TS · "
                    + String.format(Locale.ROOT, "%.1f MB", size / 1048576.0) + " · 点击导出");
        }
        list.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, rows));
        status.setText(videos.isEmpty() ? "尚无已完成缓存。请在原界面下载后回来刷新。" : "找到 " + videos.size() + " 项；导出前会检查分片和密钥。");
    }

    private void choose(File video) {
        selected = video;
        Intent pick = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.setType("video/mp4");
        pick.putExtra(Intent.EXTRA_TITLE, "X2_" + video.getName().replaceAll("[^A-Za-z0-9_-]", "_") + ".mp4");
        try { startActivityForResult(pick, SAVE); }
        catch (Exception e) { showError("无法打开系统文件保存窗口：" + e.getMessage()); }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == SAVE && result == RESULT_OK && data != null && data.getData() != null && selected != null)
            export(selected, data.getData());
    }

    private void export(final File video, final Uri destination) {
        busy = true; cancelled = false;
        refresh.setEnabled(false); list.setEnabled(false);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        status.setText("正在检查缓存完整性…"); progress.setProgress(0);
        new Thread(new Runnable() {
            @Override public void run() {
                File work = new File(getCacheDir(), "mp4-export/" + System.currentTimeMillis());
                File temp = new File(work, "output.mp4");
                try {
                    if (!work.mkdirs()) throw new IOException("无法创建临时目录");
                    final PlaylistPreparer.Prepared prepared = PlaylistPreparer.prepare(video, work);
                    main.post(new Runnable() { @Override public void run() {
                        status.setText("正在合并 " + prepared.segments + " 个分片；保留原音视频轨道…");
                    }});
                    String result = NativeRemux.run(prepared.playlist.getAbsolutePath(), temp.getAbsolutePath(), prepared.durationSeconds,
                            new NativeRemux.Progress() {
                        @Override public boolean cancelled() { return cancelled; }
                        @Override public void update(final double amount) {
                            main.post(new Runnable() { @Override public void run() { progress.setProgress((int)(amount * 90)); }});
                        }
                    });
                    if (result.length() > 0) throw new IOException(result);
                    if (cancelled) throw new IOException("已取消");
                    if (temp.length() < 64) throw new IOException("生成的 MP4 无有效内容");
                    main.post(new Runnable() { @Override public void run() { status.setText("MP4 已验证，正在写入所选位置…"); }});
                    try (FileInputStream input = new FileInputStream(temp);
                         OutputStream output = getContentResolver().openOutputStream(destination, "wt")) {
                        if (output == null) throw new IOException("无法写入所选位置");
                        byte[] buffer = new byte[1024 * 1024]; int count;
                        while ((count = input.read(buffer)) != -1) {
                            if (cancelled) throw new IOException("已取消");
                            output.write(buffer, 0, count);
                        }
                        output.flush();
                    }
                    main.post(new Runnable() { @Override public void run() {
                        progress.setProgress(100); status.setText("已保存 MP4。可在所选目录中播放或分享。\n视频 " + video.getName());
                    }});
                } catch (final Throwable error) {
                    try { android.provider.DocumentsContract.deleteDocument(getContentResolver(), destination); } catch (Exception ignored) {}
                    android.util.Log.e("X2Export", "Export failed", error);
                    main.post(new Runnable() { @Override public void run() { showError("导出失败：" + error.getMessage()); }});
                } finally {
                    temp.delete();
                    // Keep the tiny normalized playlist as an audit record; it contains local paths only.
                    main.post(new Runnable() { @Override public void run() {
                        busy = false;
                        refresh.setEnabled(true); list.setEnabled(true);
                        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    }});
                }
            }
        }, "X2-cache-export").start();
    }

    private void showError(String message) {
        status.setText(message);
        new AlertDialog.Builder(this).setTitle("无法导出").setMessage(message).setPositiveButton("知道了", null).show();
    }

    @Override public void onBackPressed() {
        if (!busy) { super.onBackPressed(); return; }
        new AlertDialog.Builder(this).setTitle("正在导出")
                .setMessage("导出期间请保持此页打开。是否取消？")
                .setPositiveButton("继续导出", null)
                .setNegativeButton("取消导出", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int which) {
                        cancelled = true; status.setText("正在取消…");
                    }
                }).show();
    }
}
