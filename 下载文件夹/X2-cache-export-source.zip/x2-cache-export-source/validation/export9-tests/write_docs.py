from pathlib import Path
import subprocess,json
B=Path('/workspace/x2-analysis');R=B/'export9-tests';O=B/'output';sha=json.loads((O/'build-info.json').read_text())['output_sha256']
s=subprocess.check_output(['git','-C','/workspace/pqc-upload','show','6adae13d4f03223f2b21a097e366a3cc0c2ddfb6:下载文件夹/使用说明.md']).decode()
s=s.replace('export8','export9').replace('版本码 16','版本码 17');a=s.index('APK SHA-256：');e=s.index('\n',a);s=s[:a]+'APK SHA-256：`'+sha+'`'+s[e:]
a=s.index('\n- 画面恢复');s=s[:a]+'''
## 本次白屏修复

修复开发测试开关开启时，禁区入口提前返回、未登记页面响应式依赖的问题。现在保留原始用户资料读取，在返回前应用测试结果，避免这条路径触发 GetX 的无依赖构建错误。原有开关状态保留，无需清除数据。下载管理、按钮、目录配置、任务和播放器字节码未修改。

这项修复针对已确认的客户端缺陷。真实平台页面与完整视频仍未端到端验证；若更新后仍白屏，还需要区分真实网络响应或其他页面异常。

## 保留功能
'''+s[a:];(O/'使用说明.md').write_text(s)
getter=json.loads((R/'getter-results.json').read_text());assert getter['passed'] and len(getter['cases'])==40
text='''# export9 白屏修复验证

APK SHA-256：`'''+sha+'''`

原 ForbiddenPage::build 的 Obx 闭包调用 UserService.isForbiddenVip；其原 getter 通过 Rx.value 建立订阅。export8 的测试入口提前返回，未执行任何 Rx 读取；RxNotifier.notifyChildrens 检查 canUpdate，无依赖时抛出 [Get] the improper use of a GetX 异常。此缺陷可解释保留原生浮层、其他栏目正常的白色错误页，但没有读取用户设备运行日志，不能排除其他原因。

ARM64/x86_64 共 40 个完整 getter 指令执行用例，涵盖开关开／关及会员类型 0、1、7、8、9。export8 开启时零次 Rx 读取；export9 原始读取次数全部保留，结果和栈均通过。Rx.value 由测试桩记录调用并返回受控模型，并非实际 Dart VM 中运行整个 Obx。

原 getter 在返回尾部之前与原 APK 逐字一致，无新增分配或调用。所有 Java 源码、dex 和 assets 与 export8 一致。下载功能沿用 export8 的实测记录，本版未重复全部下载用例。

'''
for name in ['comparison-results.json','machine-results.json','payload-results.json','installed-results.json','flutter-startup-results.json','entry-results.json']:
 p=R/name
 if p.exists():text+='## '+name+'\n\n```json\n'+p.read_text()+'\n```\n\n'
text+='真实平台接口不可达；本报告不声称已经验证禁区列表恢复或完整视频播放。\n';(O/'VALIDATION.md').write_text(text)
