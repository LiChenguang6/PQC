# X2 社保存导出版补丁源码（export6）

保留原应用浏览、播放入口，新增并排“下载”“管理”按钮，独立前台服务完成并发下载和本地 MP4 封装。版本码 14，沿用此前导出版签名和包名，可直接更新。

## 使用

首次点击“下载”选择一次系统目录，以后点击直接排队，不离开原视频。可继续浏览、退到桌面或熄屏。通过“管理”取消、重试、删除指定任务；已完成的 MP4 默认保留。“下载设置”修改目录和并发数量可输入 1–32（默认 3），新目录只影响新任务。“导出已有缓存”保留。

允许后台运行和通知可降低系统中断机会。强行停止、厂商省电策略仍可中断；重新打开管理页会重新下载中断任务，不支持字节断点续传。过期播放链接需重新播放后新建任务。原版和副本数据独立。

## export6：任务控制、主页入口及短视频标题

`MediaDownloader` 的取消监控线程关闭连接／流时捕获运行时异常，解决日志中确认的 Okio `Unbalanced enter/exit` 导致进程退出。前台服务每次 onStartCommand 重新履行 startForeground，覆盖停止／新命令交错的恢复路径。

任务增加持久化 paused 状态，工作线程在下载检查和本地封装／写出检查处协作等待。暂停让出并发名额，恢复等待名额，不超出设置值；暂停线程与当前任务最多共 64 个。只有同一进程和仍有效连接可延续当前传输；进程结束后工作文件清理，或连接失效时，恢复可能重新下载。本实现不承诺字节 Range 断点续传。

`patch_tasks_short.py` 固定输入为 export5 的两份 64 位快照。VideoDetail.authPlayUrl getter 的无调用片段复制 field_53 标题和最终 URL，使用 4 槽短视频快照，保留相邻预加载标题。JNI 比对当前 MPV URL 后采用标题。原详情页的独立快照保留。

MainController.changeMainTabIndex 的索引 0 写入原生管理事件，同时维持索引 1（视频），避免进入空白活动页。按钮标题在绘制时把“活动”替换为原存在的“下载”对象，不修改字符串本体。Java 只在窗口有焦点时消费事件并打开原 DownloadTasksActivity。64 位浮层删除“管理”，保留一个可拖动下载按钮；ARMv7 没有新 AOT 桥，保留双按钮作为管理兼容入口。

自有应用开发设置的 forbidden-entry 默认为 false。开启时仅让客户端 UserService.isForbiddenVip getter 放行，关闭时执行原代码；并不修改服务器 VIP、账号资料或其他 VIP 功能。原资料来自 user/base/info，入口判断接受 vipType 7/8。真实服务器不可达，不能声称恢复服务器设备／账号授权。测试开关和事件只占匿名 RW 空间，开关持久化于应用私有配置。

本次验证脚本在 validation/export6-tests；之前版本记录仅作为历史证据。

## export5：主页、标题及开屏（保留）

`patch_launch_title.py` 默认将 MainController 的初始值、`index` 入口与缺省路由选择设为“视频”（索引 1）。保留标签布局和显式其他标签路由。

原启动 `_doLoading` 的网络检查、并发选线、登录、广告数据拉取及 AppService 网络初始化全部保留。最后成功路径调用原 `_tapJumpAction`；只取消广告计数器读取与非零计数拦截，原 StorageService/AppService 就绪判断与失败提示保留。该动作原有的 offHome 路径进入主页。原广告组件在初始化完成后才创建，计时器每秒减 1，初值 5；现在无需创建或点击它。连接超时配置为 15 秒，但失败后备用请求、登录等会影响总启动耗时，不能把它当作总耗时上限。

播放页 URL getter 的两个无调用叶子片段将页面详情模型中的实际标题及生成的播放 URL 复制到新增匿名 RW 内存。只复制 OneByteString/TwoByteString 的内容，不持有 Dart 引用，不调用函数或分配对象。序列号保护读取；JNI 只在完整快照 URL 与当前 MPV path 完全一致时采用该标题，切换中或不匹配时回退到播放器标题。该绑定覆盖原 VideoPlayByVideoId 详情播放页；尚未验证其他播放器入口。RW 段仅增大内存大小，不增加文件或读写 Dart 堆；RX 叶子代码位于原零填充区。

`VideoFilename.mp4` 使用入队时固定的标题创建输出，保留中文和表情，替换控制字符及 `/\:*?"<>|`，限制 UTF-8 文件名长度，避免重复扩展名。同名任务交给 DocumentsProvider 原子创建不同文件；API 29 Downloads provider 实测追加 ` (1)`。名称缺失时为“当前播放视频”；旧任务保留此前入队记录中的标题。设置和管理原有行为保留。

这些 AOT 变化覆盖 ARM64 和 x86_64；ARMv7 保留原主页、启动流程和播放器标题来源。Java 输出命名功能覆盖三个 ABI。云端无法访问实际平台，真实内容标题与启动跳转仍需在用户可连通的平台上观察；受控播放与指令验证的范围见 VALIDATION.md。

## export4 已有交互修正（保留）

“下载”“管理”按钮作为一组拖动，移动超过触摸阈值后取消按钮点击，避免误下载。位置用相对于可用区域的比例保存，恢复时限制在可见范围内。普通点击保留原行为，未覆盖区域继续由原页面接收滑动。

“同时下载数量”改为整数输入框，可设置 1–32，拒绝 0、越界和无效值；后台线程池按该配置同步调整。降低并发时已启动的任务不中断。用户已确认下载队列显示正常，本次保留原管理列表实现。

## 原有网络英文提示与进入播放器弹窗

`patch_ui.py` 在已锁定的 ARM64/x86_64 快照中移除 `ApiExceptionHandler._debugPrintError` 内将原始网络异常展示为 toast 的那一个调用，保留后续日志及其他错误处理、登录和权限提示。

播放器 onInit 原来必定创建 VerticalGroupAds 弹层，即使推广图片列表为空也可能留下空白遮罩。现在直接调用该弹层正常关闭时原有的 `_showAllEntranceAdsDismissAction`，继续详情加载、播放器事件绑定等初始化，跳过入场推广容器。没有修改播放授权判断或其他对话框。这两项补丁与既有滚动补丁一样，目前覆盖 ARM64、x86_64；ARMv7 保留原样。

## 同类视频数量的调查结果

原客户端只调用一次 `video/guessLike`，查询只有 videoId；返回的列表直接赋给推荐数据并显示，没有发现本地 take(12)，也没有翻页或触底续载。这能解释用户观察到的单批 12 项，但当前云机不能验证服务器是否接受分页参数或更大批次。本版没有实现无限相关推荐，也不声称已经突破 12 项。

## 后台实现

`DownloadService` 持有前台 dataSync 通知和活动期间的 PARTIAL_WAKE_LOCK；工作线程独立于 Activity，线程池随配置调整为 1–32，按队列上限调度。每个任务使用隔离的下载目录和 CookieManager。取消、删除不会取消其他任务；网络操作受超时约束。私有队列使用 AndroidKeyStore AES-GCM 和 AtomicFile 保存，进程重启恢复待处理任务。SAF tree URI 获取持久授权，保存目录只需选择一次。目标 MP4 在本地封装与完整性验证后才创建，失败、取消清理半成品。

## 原推荐区域滚动修复

原 `_buildTabBarViewZeroChildWidget` 返回 Padding/GetBuilder/Wrap，卡片位于 TabBarView 中且没有内层纵向滚动容器。`patch_scroll.py` 把最外层 Padding 替换为带同样 padding/child 的 SingleChildScrollView，其余卡片和回调保留。

只接受指定 SHA-256 的 ARM64、x86_64 Dart 3.6.2 snapshot。现有 allocation call 改用原 snapshot 的 SingleChildScrollView allocation stub，原调用返回 PC、栈图保持。返回处跳转到 ELF RX 段后零填充区中的无调用初始化代码，设置 8 个字段后跳回原 epilogue。只扩大该 RX 段在已有填充中的大小，不增加文件长度、不更改 libflutter/libmpv。ARMv7 保留原样，不声称已修复其滚动。

指令模拟验证了两种架构的所有字段及寄存器/栈保持。当前云环境不能连接真实平台页面，真实相关推荐操作仍需实机确认；不能把启动与模拟检查当作真实平台端到端验证。

## 实现与范围

- `libx2player.so` 通过原 media_kit 的 Create/Dispose 生命周期建立独立 MPV weak client，只读原播放器属性，不修改原播放器库或消费 Dart 的事件队列。仅接受实际加载、有 `time-pos` 且未暂停的唯一 HTTP(S) 播放器；多播放器、切换中、未完成加载或不支持的本地源会明确拒绝。
- 点击入口时在后台线程即时读取地址、User-Agent、Referer 和原始 header 数组，保留 query。地址和请求凭据不放入 Intent、不写公开日志；排队任务通过 AndroidKeyStore AES-GCM 加密保存到私有文件，完成后清除请求凭据。原本地缓存服务会引导至缓存导出，保留原始 IV 处理。
- `MediaDownloader` 使用 Android HttpURLConnection，保留 TLS 校验，跟随有限重定向并以最终 URI 解析相对引用；支持无后缀 HLS、普通有限媒体清单、AES-128 及简单复用音视频的 master variant。使用独立 CookieManager，捕获的鉴权头仅在原 origin 使用；不修改全局 CookieHandler。
- 下载失败显示阶段和 HTTP 状态，不输出签名 query 或密钥。临时媒体和密钥在保存、失败或取消后删除；失败时删除系统目标文档。直接媒体要求可探测时长，仍校验输出轨道、编码和完整时长。
- 静态确认缓存位于 `Context.getDir("flutter", 0)/downloads/video/<videoId>`。
- `index.m3u8` 是完成标记；导出优先读取 `index.raw.m3u8`，保留原 `IV`、`MEDIA-SEQUENCE` 和分片顺序，再把媒体与密钥映射为同一缓存目录的本地文件。
- `enc.key` 为普通 AES-128 HLS 的本地 16 字节密钥；不解析加密 Hive 记录库，不访问其他应用数据。
- 通过 `libx2export.so` 内静态链接的最小 FFmpeg 6.0 本地媒体处理组件，进行流复制、必要的自动位流过滤和 MP4 封装。它不启用网络协议；符号隐藏并绑定在本组件内部，避免与原 `libmpv.so` 的 FFmpeg 冲突。原有 libmpv/libflutter 等 19 个原生库原字节保持不变；ARM64、x86_64 的 libapp.so 接受本文限定的滚动、UI、启动与标题复制修改。
- 原 APK 的 `libmpv.so` 没有编译 MP4 封装器，因此仅调用它的导出符号不能完成本任务；已依据实际 Android 运行测试选择独立最小封装组件。
- 已有缓存导出对缺文件、空分片、缺密钥、错误密钥长度、路径越界、同名分片冲突、主清单、独立音轨、byterange、密钥轮换与不支持的加密方式明确拒绝。播放源下载支持普通 AES-128 密钥切换；复杂独立音轨、fMP4 MAP、byterange、直播和 DRM/SAMPLE-AES 暂不支持。
- 缺失原始清单时，若加密本地清单也没有显式 IV，无法排除原下载器曾丢失 IV，会拒绝导出并要求重新下载。
- 输出会重新打开检查轨道数量、编码和预期时长；失败时不将半成品当作成功。所选目标为系统文件保存 URI，无需新增全盘存储权限。
- 不伪造业务令牌或设备身份，不移除 DRM；当前播放源拒绝请求时明确报错。不读取其他应用的私有目录。
- 缓存列表只显示视频 ID 与缓存大小，不声称恢复了加密下载记录中的影片标题。

## 复现构建

需要 Linux x86_64、Python 3、Java 21 运行时和 `keytool`，以及原 APK。源码不包含原 APK 和本地签名私钥。

运行：

```bash
python3 bootstrap_tools.py
bash ../minimal-ffmpeg/fetch-source.sh
bash ../minimal-ffmpeg/build.sh x86_64 arm64-v8a armeabi-v7a
X2_INPUT_APK=/absolute/path/app.apk python3 build_patch.py
```

默认工具位置为源码同级的 `../patch-tools`，可通过 `X2_PATCH_TOOLS` 覆盖；最小 FFmpeg 库默认为 `../minimal-ffmpeg/<ABI>/lib`，可通过 `X2_FFMPEG_ROOT` 覆盖。自定义 NDK 路径时运行媒体构建脚本需设置 `X2_NDK_ROOT`。结果位于 `../output/`：APK、签名验证文本与 `build-info.json`。首次构建会生成本地开发签名；保留自己的 `build/local-export-key.p12` 才能后续更新自己生成的导出版。此签名不等于原应用签名。

工具为 Apktool 2.11.1、ECJ 3.41.0、Android Platform 35、Build Tools 35.0.0 与 NDK r28c。Google 工具按官方仓库元数据摘要校验；Maven 构件按仓库发布的摘要校验（Apktool 为 SHA-512，ECJ 为 SHA-1）。FFmpeg 6.0 的匹配头文件及许可证随源码放在 `third_party/ffmpeg-6.0`。

构建脚本从输入 APK 重新解包，修改包作用域的 provider authorities/自定义权限、新增下载与配置 Activity 和前台服务，并在原 FlutterActivity/壳入口的 `onCreate` 最后添加入口。`inject_player_capture.py` 在 media_kit 输出管理器的 Create/Dispose 与 engine detach 注入三处只读观察器生命周期回调。原始 FlutterActivity 的混淆名称为 `c9/d`；本补丁只适用于本次分析的 APK 版本，不应直接套用于其他版本。

## 验证说明

验证记录以最终交付的分析报告为准。合成测试素材用于验证明文 HLS、带显式 IV 的 AES-128 HLS、分片/密钥缺失等情况；合成测试通过不代表第三方在线服务一定可连接，也不代表原应用所有媒体格式都已覆盖。
