from pathlib import Path
import sys,struct,json,hashlib
from unicorn import *
from unicorn.arm64_const import *
from unicorn.x86_const import *
B=Path('/workspace/x2-analysis');sys.path.insert(0,str(B/'export-patch'))
from patch_scroll import apply as scroll
from patch_ui import apply as ui,SPECS
results={}
for abi in SPECS:
 old=(B/'extracted/lib'/abi/'libapp.so').read_bytes();data,_=scroll(old,abi,B/'patch-tools/android-ndk-r28c/toolchains/llvm/prebuilt/linux-x86_64/bin',B/'export-patch/build/scroll');data,changes=ui(data,abi)
 arm=abi=='arm64-v8a';u=Uc(UC_ARCH_ARM64 if arm else UC_ARCH_X86,UC_MODE_ARM if arm else UC_MODE_64)
 u.mem_map(0x300000,0x600000);u.mem_write(0x300000,data[0x300000:0x900000]);u.mem_map(0x1000000,0x40000);u.mem_map(0x2000000,0x4000)
 this=0x2001001;null=0x2000081;stop=0x300000;stack=0x2002000
 if arm:
  start=0x70b3e0;calls={0x70cb14:'base_onInit',0x89535c:'allocate_closure',SPECS[abi]['post_dismiss']:'original_post_dismiss_initialization'}
  for reg,value in {UC_ARM64_REG_X1:this,UC_ARM64_REG_X15:stack,UC_ARM64_REG_X29:0x2002400,UC_ARM64_REG_X30:stop,UC_ARM64_REG_X26:0x2003000,UC_ARM64_REG_X27:0x1000000,UC_ARM64_REG_X22:null}.items():u.reg_write(reg,value)
 else:
  start=0x61f1dc;calls={0x620f58:'base_onInit',0x8a7c48:'allocate_closure',SPECS[abi]['post_dismiss']:'original_post_dismiss_initialization'}
  for reg,value in {UC_X86_REG_RDI:this,UC_X86_REG_RSP:stack,UC_X86_REG_RBP:0x2002400,UC_X86_REG_R14:0x2003000,UC_X86_REG_R15:0x1000000}.items():u.reg_write(reg,value)
  u.mem_write(stack,struct.pack('<Q',stop));u.mem_write(0x2003078,struct.pack('<Q',null))
 seen=[]
 def hook(uc,at,size,unused):
  assert at!=SPECS[abi]['show_ads'],'ad container still opened'
  if at not in calls:return
  seen.append(calls[at]);value=0x2001201 if calls[at]=='allocate_closure' else null
  if calls[at]=='original_post_dismiss_initialization':assert uc.reg_read(UC_ARM64_REG_X1 if arm else UC_X86_REG_RDI)==this
  if arm:uc.reg_write(UC_ARM64_REG_X0,value);uc.reg_write(UC_ARM64_REG_PC,uc.reg_read(UC_ARM64_REG_X30))
  else:
   sp=uc.reg_read(UC_X86_REG_RSP);ret=struct.unpack('<Q',uc.mem_read(sp,8))[0];uc.reg_write(UC_X86_REG_RSP,sp+8);uc.reg_write(UC_X86_REG_RAX,value);uc.reg_write(UC_X86_REG_RIP,ret)
 u.hook_add(UC_HOOK_CODE,hook);u.emu_start(start,stop,count=80)
 assert seen==['base_onInit','allocate_closure','original_post_dismiss_initialization'],seen
 assert u.reg_read(UC_ARM64_REG_X0 if arm else UC_X86_REG_RAX)==null
 assert u.reg_read(UC_ARM64_REG_X15 if arm else UC_X86_REG_RSP)==stack+(0 if arm else 8)
 toast=SPECS[abi]['toast'];assert data[toast:toast+(4 if arm else 5)]==(bytes.fromhex('1f2003d5') if arm else b'\x90'*5)
 # Removing the debug-toast call does not modify the following log/handler path.
 assert data[toast+(4 if arm else 5):toast+40]==old[toast+(4 if arm else 5):toast+40]
 results[abi]={'onInit_path_executed':seen,'original_ad_container_not_called':True,'same_controller_passed_to_original_completion':True,'stack_and_return_restored':True,'raw_network_toast_call_removed':True,'following_error_log_path_unchanged':True,'changes':changes,'patched_sha256':hashlib.sha256(data).hexdigest()}
(B/'export4-tests/ui-patch-results.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
