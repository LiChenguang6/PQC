"""Pinned AOT widget repair. Allocation stays at its original GC safepoint.
The out-of-line initializer contains no calls, allocations or safepoints.
Only the two analyzed 64-bit snapshots are supported; ARM32 is unchanged.
"""
import hashlib, struct, subprocess
from pathlib import Path
SPECS={
'arm64-v8a':dict(call=0x63bcbc,old=0x57b2c4,alloc=0x5a9088,ret=0x63bcc0,end=0x63bcd0,cave=0x8a5ea0,compiler='aarch64-linux-android24-clang',asm='''
.text
.global init_scroll
init_scroll:
add x1,x27,#0xa000
ldr x1,[x1,#0x2c0]
stur w1,[x0,#0xb]
add x1,x22,#0x30
stur w1,[x0,#0xf]
ldur x1,[x29,#-0x28]
stur w1,[x0,#0x13]
ldur x1,[x29,#-8]
stur w1,[x0,#0x23]
add x1,x27,#0xc000
ldr x1,[x1,#0x5c8]
stur w1,[x0,#0x27]
add x1,x27,#0x3000
ldr x1,[x1,#0x840]
stur w1,[x0,#0x2b]
add x1,x27,#0x13000
ldr x1,[x1,#0x998]
stur w1,[x0,#0x2f]
add x1,x27,#0x17000
ldr x1,[x1,#0xf68]
stur w1,[x0,#0x37]
.word 0
'''),
'x86_64':dict(call=0x6e18a4,old=0x62a808,alloc=0x656e9c,ret=0x6e18a9,end=0x6e18b7,cave=0x8b99b0,compiler='x86_64-linux-android24-clang',asm='''
.text
.global init_scroll
init_scroll:
movq 0xa357(%r15),%rcx
movl %ecx,0xb(%rax)
movq 0x88(%r14),%rcx
movl %ecx,0xf(%rax)
movq -0x28(%rbp),%rcx
movl %ecx,0x13(%rax)
movq -8(%rbp),%rcx
movl %ecx,0x23(%rax)
movq 0xc72f(%r15),%rcx
movl %ecx,0x27(%rax)
movq 0x3877(%r15),%rcx
movl %ecx,0x2b(%rax)
movq 0x13ae7(%r15),%rcx
movl %ecx,0x2f(%rax)
movq 0x180d7(%r15),%rcx
movl %ecx,0x37(%rax)
.byte 0xe9
.long 0
''')}
def branch(abi,at,to,call=False):
 if abi=='arm64-v8a':
  delta=to-at;assert delta%4==0 and -(1<<27)<=delta<(1<<27)
  return struct.pack('<I',(0x94000000 if call else 0x14000000)|((delta//4)&0x3ffffff))
 return bytes([0xe8 if call else 0xe9])+struct.pack('<i',to-at-5)
def apply(data,abi,ndk,work):
 if abi not in SPECS:return data,None
 s=SPECS[abi];buf=bytearray(data)
 pins={'arm64-v8a':'c790801eaa4a1d0748df8158d6059dbe63b30010f6dcfa3d28f2e0b94a760edb','x86_64':'692a96b1ad187c36a678df655ef4d1bbeb47ed3155a9b30abf752344e1d98c5e'}
 assert hashlib.sha256(data).hexdigest()==pins[abi], 'Unsupported libapp snapshot'
 assert data[:6]==b'\x7fELF\x02\x01'
 assert data[s['call']:s['call']+len(branch(abi,s['call'],s['old'],True))]==branch(abi,s['call'],s['old'],True)
 expected=bytes.fromhex('a1835df8' if abi=='arm64-v8a' else '488b4dd889')
 assert data[s['ret']:s['ret']+len(expected)]==expected,(abi,'unexpected initialization')
 work=Path(work);work.mkdir(parents=True,exist_ok=True);asm=work/(abi+'.S');obj=work/(abi+'.o');binary=work/(abi+'.bin')
 asm.write_text(s['asm']);subprocess.run([str(Path(ndk)/s['compiler']),'-c',str(asm),'-o',str(obj)],check=True)
 subprocess.run([str(Path(ndk)/'llvm-objcopy'),'--only-section=.text','-O','binary',str(obj),str(binary)],check=True)
 code=bytearray(binary.read_bytes());tail=4 if abi=='arm64-v8a' else 5
 code[-tail:]=branch(abi,s['cave']+len(code)-tail,s['end'])
 phoff=struct.unpack_from('<Q',buf,32)[0];entsize,count=struct.unpack_from('<HH',buf,54)
 found=False
 for i in range(count):
  p=phoff+i*entsize;typ,flags,off,va,pa,fs,ms,align=struct.unpack_from('<IIQQQQQQ',buf,p)
  if typ==1 and flags==5:
   assert off==va and off+fs==s['cave'] and ms==fs
   end=s['cave']+len(code)
   assert not any(buf[s['cave']:end])
   for j in range(count):
    t,f,o,v,pa2,fs2,ms2,a=struct.unpack_from('<IIQQQQQQ',buf,phoff+j*entsize)
    assert t!=1 or v<=va or end<=v
   struct.pack_into('<QQ',buf,p+32,fs+len(code),ms+len(code));found=True
 assert found
 buf[s['call']:s['call']+len(branch(abi,s['call'],s['alloc'],True))]=branch(abi,s['call'],s['alloc'],True)
 jump=branch(abi,s['ret'],s['cave']);buf[s['ret']:s['ret']+len(jump)]=jump
 buf[s['cave']:s['cave']+len(code)]=code
 report={k:s[k] for k in ('call','ret','end','cave','alloc')};report.update(initializer_size=len(code),input_sha256=hashlib.sha256(data).hexdigest(),output_sha256=hashlib.sha256(buf).hexdigest())
 return bytes(buf),report
