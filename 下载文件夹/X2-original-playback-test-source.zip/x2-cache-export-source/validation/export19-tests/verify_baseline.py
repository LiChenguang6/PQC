from pathlib import Path
import zipfile,json,hashlib,sys
B=Path('/workspace/x2-analysis');P=B/'export-patch';R=B/'export19-tests';sys.path.insert(0,str(P))
from restore_original_playback import SITES
info=json.loads((B/'output/build-info.json').read_text());result={'baseline_sha256':info['input_sha256'],'apk_sha256':info['output_sha256'],'restored_sites':[],'checked_original_functions':[],'real_platform_full_playback_verified':False}
with zipfile.ZipFile(B/'input/app.apk') as original,zipfile.ZipFile(B/'output/X2-cache-export.apk') as current:
 for abi,sites in SITES.items():
  a=original.read('lib/'+abi+'/libapp.so');b=current.read('lib/'+abi+'/libapp.so')
  for at,size,name in sites:
   assert a[at:at+size]==b[at:at+size],(abi,name)
   result['restored_sites'].append({'abi':abi,'name':name,'offset':at,'bytes':a[at:at+size].hex()})
 for at,size,name in [(0x640234,0x20c,'load_video_detail'),(0x640440,0x118,'request_video_detail'),(0x64059c,0x3d4,'parse_video_detail'),(0x70c130,0x54,'play_progress_callback'),(0x70ca18,0xfc,'player_position_callback')]:
  a=original.read('lib/arm64-v8a/libapp.so')[at:at+size];b=current.read('lib/arm64-v8a/libapp.so')[at:at+size];assert a==b,name;result['checked_original_functions'].append(name)
with zipfile.ZipFile('/workspace/pqc-upload/下载文件夹/X2-cache-export-source.zip') as old:
 for path in (P/'src').rglob('*.java'):
  if path.name=='DownloadSettingsActivity.java':continue
  assert path.read_bytes()==old.read('x2-cache-export-source/export-patch/'+str(path.relative_to(P))),path.name
result['download_preview_and_dedupe_java_unchanged']=True;result['passed']=True
(R/'baseline-results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
