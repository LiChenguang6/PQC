#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$root/source"
tarball="$root/source/FFmpeg-n6.0.tar.gz"
if [[ ! -f "$tarball" ]]; then
 curl --fail --location --max-time 180 https://codeload.github.com/FFmpeg/FFmpeg/tar.gz/refs/tags/n6.0 --output "$tarball.part"
 mv "$tarball.part" "$tarball"
fi
printf '%s  %s\n' '9a1fa94608300e835bf89bdfcd7d77deceba67bff3494f609816f84bd69a459e' "$tarball" | sha256sum --check --status
if [[ ! -f "$root/source/FFmpeg-n6.0/configure" ]]; then
 tar -xzf "$tarball" -C "$root/source"
fi
