from pathlib import Path
import json
B=Path('/workspace/x2-analysis');R=B/'export14-tests';O=B/'output';sha=json.loads((O/'build-info.json').read_text())['output_sha256']
(O/'使用说明.md').write_text('''# export14 手机端播放源检查（诊断测试版）

版本9.9.9-export14，版本码22。覆盖安装，保留下载记录和保存目录授权。

**尚未修复或验证禁区完整播放。没有修改服务器账户、认证令牌或上传VIP声明。本版用于让手机通过用户现有VPN取得媒体清单诊断。**

## 测试步骤

1. 保持手机上原来能浏览视频的VPN连接。
2. “管理 → 下载设置”开启“开发测试”。返回目标视频，让视频实际播放几秒。
3. 在30秒内进入“管理 → 下载设置 → 检查当前播放源（复制）”。检查完成后点“复制”，把文字发回即可；无需USB或Root。
4. 同时可以保留原“播放诊断（复制）”的数值轨迹。进入管理页可能暂停播放器，因此新增检查允许读取最近30秒内的播放连接，报告标明snapshot与source_age_ms。

## 如何理解结果

- manifest_seconds：所选HLS媒体清单中EXTINF的总时长；segments为分片数量。
- endlist=1：清单有结束标记；若时长只有约12秒，说明本次请求所得清单就只列出了这段内容，仍不能仅据此判定是会员限制、广告或短片。
- 时长超过20秒但播放器提前结束时，需要结合数值轨迹检查客户端或分片加载问题。
- kind=direct_or_unknown：不是可识别的HLS清单；这次检查不会下载整个文件，仍需结合播放器时长。
- kind=html/json、HTTP状态码或error_type：请求未取得可分析清单。开启开发测试后返回实际播放，再在30秒内重试。
- 主清单沿用最高带宽选择，不检查其他变体。重新请求的响应可能不同于播放时的响应，不能据此宣称服务器已经提供完整版。

检查只重新读取已捕获播放地址的清单，最多四层、每份4MiB；45秒截止，可取消。不读取视频分片和密钥，不改变账号权限。报告只含版本、地址摘要标识、数值、清单统计；不含播放URL、标题、请求头值、账号或密钥。捕获的请求上下文只短暂保存在进程内存，30秒过期，不写入报告或配置。

## 保留功能

并排可拖动“下载／管理”、后台并行下载、目录记忆、暂停／继续、分区和批量操作保留。完成项长按或多选删除，可选仅删除记录或同时删除MP4。名称、图标、开屏入口仍在下载设置，自定义名称和图标通过桌面快捷方式生效。

APK SHA-256：`'''+sha+'`\n')
text='# export14 验证记录\n\n**真实指定视频超过20秒尚未验证，不能把受控素材当作成功。**\n\nAPK SHA-256：`'+sha+'`\n\n'
for name in ['inspection-results.json','ui-results.json','installed-results.json','flutter-startup-results.json','payload-results.json','comparison-results.json']:
 p=R/name
 if p.exists():text+='## '+name+'\n\n```json\n'+p.read_text()+'\n```\n\n'
text+='\n主机用11种清单/传输场景验证时长、ENDLIST、主清单选择、错误响应、长度限制、跨域凭据隔离及复制报告脱敏，未请求分片/密钥。Android API29 x86_64上用受控12秒HLS、原MPV和背景采样，先播放再暂停，验证设置入口、最近源回退、清单统计与复制；同时回归实际SAF文件删除。\n\n首次手机端检查暴露了暂停后原snapshot不再返回地址的问题，已加入开启开发测试时的30秒内存快照，并重新构建验证。历史export13的完整后台/外观/两架构指令用例是基线，未冒充本构建重跑。comparison-results记录现有下载器实现和所有原生库与export13逐字节相同；新增代码为Java检查与诊断采样。\n';(O/'VALIDATION.md').write_text(text)
