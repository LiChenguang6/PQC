from pathlib import Path
import sys,json,struct,zipfile,subprocess,io
from unicorn import *
from unicorn.arm64_const import *
from unicorn.x86_const import *
B=Path('/workspace/x2-analysis');R=B/'export12-tests';sys.path.insert(0,str(B/'export-patch'))
import patch_scroll,patch_ui,patch_launch_title,patch_tasks_short
N=B/'patch-tools/android-ndk-r28c/toolchains/llvm/prebuilt/linux-x86_64/bin';W=R/'asm';W.mkdir(exist_ok=True);results=[]
oldapk=zipfile.ZipFile(io.BytesIO(subprocess.check_output(["git","-C","/workspace/pqc-upload","show","6adae13d4f03223f2b21a097e366a3cc0c2ddfb6:下载文件夹/X2-cache-export.apk"])))
for abi,s in patch_tasks_short.S.items():
 arm=abi=='arm64-v8a'
 with zipfile.ZipFile(B/'input/app.apk') as z:d=z.read('lib/'+abi+'/libapp.so')
 d,_=patch_scroll.apply(d,abi,N,W);d,_=patch_ui.apply(d,abi);d,_=patch_launch_title.apply(d,abi,N,W);d,report=patch_tasks_short.apply(d,abi,N,W)
 (W/(abi+'-patched.so')).write_bytes(d);(W/(abi+'-report.json')).write_text(json.dumps(report,indent=2))
 entry=0x6bd428 if arm else 0x779c58;read=0x86eec8 if arm else 0x82f600
 with zipfile.ZipFile(B/'input/app.apk') as z:original=z.read('lib/'+abi+'/libapp.so')
 assert d[entry:s['vip']]==original[entry:s['vip']], 'Getter body or original reactive reads changed'
 for variant,d in [('export8',oldapk.read('lib/'+abi+'/libapp.so')),('export12',d)]:
  for enabled in [0,1]:
   for viptype in [0,1,7,8,9]:
    u=Uc(UC_ARCH_ARM64 if arm else UC_ARCH_X86,UC_MODE_ARM if arm else UC_MODE_64);u.mem_map(0,0x900000);u.mem_write(0,d);u.mem_map(0x1000000,0x40000);u.mem_map(0x2000000,0x10000)
    heap=0x1000000;stack=0x2008000;service=heap+0x101;rx=heap+0x501;user=heap+0x1001;null=heap+0x81;thr=heap+0x8000;sentinel=0x200f000
    def put(at,v,fmt='Q'):u.mem_write(at,struct.pack('<'+fmt,v))
    put(service+0x37,rx,'I');put(user+0xcb,viptype*2,'I');put(s['buffer']+0x4904,enabled,'I');put(thr+0x48,0);put(thr+0x38,0);put(thr+0x80,null+0x20);put(thr+0x88,null+0x30)
    regs={UC_ARM64_REG_X1:service,UC_ARM64_REG_X15:stack,UC_ARM64_REG_X29:stack+0x100,UC_ARM64_REG_X30:sentinel,UC_ARM64_REG_X22:null,UC_ARM64_REG_X26:thr,UC_ARM64_REG_X28:0} if arm else {UC_X86_REG_RDI:service,UC_X86_REG_RSP:stack,UC_X86_REG_RBP:stack+0x100,UC_X86_REG_R14:thr}
    for k,v in regs.items():u.reg_write(k,v)
    if not arm:put(stack,sentinel)
    calls=[]
    def hook(emu,pc,size,data):
     if pc!=read:return
     receiver=emu.reg_read(UC_ARM64_REG_X1 if arm else UC_X86_REG_RDI);assert receiver==rx;calls.append(pc)
     if arm:emu.reg_write(UC_ARM64_REG_X0,user);emu.reg_write(UC_ARM64_REG_PC,emu.reg_read(UC_ARM64_REG_X30))
     else:
      sp=emu.reg_read(UC_X86_REG_RSP);ret=struct.unpack('<Q',emu.mem_read(sp,8))[0];emu.reg_write(UC_X86_REG_RSP,sp+8);emu.reg_write(UC_X86_REG_RAX,user);emu.reg_write(UC_X86_REG_RIP,ret)
    u.hook_add(UC_HOOK_CODE,hook);u.emu_start(entry,sentinel,count=500)
    assert len(calls)==(0 if variant=="export8" and enabled else 1 if viptype==7 else 2),(abi,enabled,viptype,len(calls))
    value=u.reg_read(UC_ARM64_REG_X0 if arm else UC_X86_REG_RAX);assert value==null+(0x20 if enabled or viptype in [7,8] else 0x30),(abi,enabled,viptype,value)
    assert u.reg_read(UC_ARM64_REG_X15 if arm else UC_X86_REG_RSP)==stack+(0 if arm else 8)
    results.append(dict(version=variant,abi=abi,development_enabled=bool(enabled),vip_type=viptype,original_reactive_reads_executed=len(calls),expected_result=True,stack_restored=True))
(R/'getter-results.json').write_text(json.dumps(dict(passed=True,cases=results),indent=2));print('PASS 40 full getter executions: export8 enabled skips all reactive reads; export12 preserves them in all cases')
