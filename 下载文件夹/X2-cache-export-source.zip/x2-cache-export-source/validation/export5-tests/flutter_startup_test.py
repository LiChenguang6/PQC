from pathlib import Path
import subprocess,json,time
B=Path('/workspace/x2-analysis');R=B/'export5-tests';A=str(B/'android-sdk/platform-tools/adb');P='com.example.yinqishe_export'
def adb(*args,timeout=30):return subprocess.check_output([A,'-s','emulator-5554',*args],timeout=timeout)
adb('shell','am','force-stop',P)
launch=adb('shell','am','start','-W','-n',P+'/com.example.yinqishe_app.MainActivity',timeout=60).decode();(R/'flutter-launch.txt').write_text(launch)
end=time.monotonic()+45;maps='';pid=''
while time.monotonic()<end:
 pid=adb('shell','pidof',P).decode().strip().split()[0]
 maps=adb('shell','cat','/proc/'+pid+'/maps').decode()
 if '/libapp.so' in maps and '/libflutter.so' in maps:break
 time.sleep(2)
else:raise RuntimeError('Flutter snapshot libraries not mapped')
time.sleep(5)
assert adb('shell','pidof',P).decode().strip().split()[0]==pid
logs=adb('logcat','-d','--pid='+pid).decode(errors='replace');(R/'flutter-process.log').write_text(logs)
assert 'Fatal signal' not in logs and 'Snapshot not compatible' not in logs and 'FATAL EXCEPTION' not in logs
(R/'flutter-startup.png').write_bytes(adb('exec-out','screencap','-p'))
r={'final_apk_sha256':json.loads((B/'output/build-info.json').read_text())['output_sha256'],'original_Flutter_activity_started':True,'patched_libapp_and_original_libflutter_mapped':True,'process_survived_startup':True,'no_native_fatal_or_snapshot_compatibility_error_in_process_log':True,'real_platform_related_page_not_tested':True}
(R/'flutter-startup-results.json').write_text(json.dumps(r,indent=2));print(json.dumps(r),flush=True)
