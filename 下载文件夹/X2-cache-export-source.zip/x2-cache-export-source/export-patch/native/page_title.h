/* UTF-16 snapshots written by pinned, no-allocation Dart leaf trampolines.
 * Sequence checks reject concurrent updates and a URL must match the player.
 * No pointers into the moving Dart heap are retained or read here. */
#include <link.h>
#include <stdatomic.h>
typedef struct TitleSnapshot { uint32_t title_len,uri_len,sequence,magic; uint16_t title[1024],uri[8192]; } TitleSnapshot;
static uintptr_t title_buffer_address;
static int locate_title_buffer(struct dl_phdr_info *info,size_t size,void *opaque) {
    (void)size; (void)opaque;
#if defined(__aarch64__)
    const uintptr_t offset=0x8b1000;
#elif defined(__x86_64__)
    const uintptr_t offset=0x8c1000;
#else
    const uintptr_t offset=0;
#endif
    const char *name=strrchr(info->dlpi_name,'/');name=name?name+1:info->dlpi_name;
    if(!offset||strcmp(name,"libapp.so"))return 0;
    for(int i=0;i<info->dlpi_phnum;i++) {
        const ElfW(Phdr) *p=&info->dlpi_phdr[i];
        if(p->p_type==PT_LOAD&&(p->p_flags&PF_W)&&offset>=p->p_vaddr&&offset+sizeof(TitleSnapshot)<=p->p_vaddr+p->p_memsz) {
            title_buffer_address=info->dlpi_addr+offset;return 1;
        }
    }
    return 0;
}
static jstring page_title(JNIEnv *env,jstring uri) {
    /* Called from the capture worker; resolution and copying are serialized. */
    static pthread_mutex_t lock=PTHREAD_MUTEX_INITIALIZER;
    pthread_mutex_lock(&lock);
    if(!title_buffer_address)dl_iterate_phdr(locate_title_buffer,NULL);
    jstring result=NULL;
    if(title_buffer_address) {
        const volatile TitleSnapshot *p=(const volatile TitleSnapshot *)title_buffer_address;
        uint32_t before=__atomic_load_n(&p->sequence,__ATOMIC_ACQUIRE);
        if(!(before&1)&&p->magic==0x35543258&&p->title_len>0&&p->title_len<=1024&&p->uri_len>0&&p->uri_len<=8192) {
            TitleSnapshot copy;memcpy(&copy,(const void *)p,sizeof(copy));
            __atomic_thread_fence(__ATOMIC_ACQUIRE);
            uint32_t after=__atomic_load_n(&p->sequence,__ATOMIC_ACQUIRE);
            if(before==after&&!(after&1)&&copy.title_len<=1024&&copy.uri_len<=8192&&(*env)->GetStringLength(env,uri)==(jsize)copy.uri_len) {
                const jchar *chars=(*env)->GetStringChars(env,uri,NULL);
                if(chars) {
                    if(!memcmp(chars,copy.uri,copy.uri_len*2))result=(*env)->NewString(env,copy.title,(jsize)copy.title_len);
                    (*env)->ReleaseStringChars(env,uri,chars);
                }
            }
        }
    }
    pthread_mutex_unlock(&lock);return result;
}
