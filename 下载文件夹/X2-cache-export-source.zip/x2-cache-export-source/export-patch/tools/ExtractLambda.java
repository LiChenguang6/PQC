import java.io.*;
import java.nio.file.*;
public final class ExtractLambda {
 public static void main(String[] args)throws Exception {
  Path out=Paths.get(args[0],"java/lang/invoke/LambdaMetafactory.class");Files.createDirectories(out.getParent());
  try(InputStream in=ClassLoader.getSystemResourceAsStream("java/lang/invoke/LambdaMetafactory.class")) {
   if(in==null)throw new IOException("JDK LambdaMetafactory class unavailable");Files.copy(in,out,StandardCopyOption.REPLACE_EXISTING);
  }
 }
}
