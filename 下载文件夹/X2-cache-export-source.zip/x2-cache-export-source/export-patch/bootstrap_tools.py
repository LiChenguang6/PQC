#!/usr/bin/env python3
"""Fetch pinned upstream build tools, verify published checksums, and extract.

Network access is used only for public upstream artifacts. No credentials or
application account state are required. The original APK must be supplied by
its user and is never fetched from third-party download sites.
"""
import concurrent.futures
import hashlib
import os
from pathlib import Path
import stat
import urllib.request
import xml.etree.ElementTree as ET
import zipfile

HERE = Path(__file__).resolve().parent
TOOLS = Path(os.environ.get("X2_PATCH_TOOLS", str(HERE.parent / "patch-tools")))

def fetch(url, path, algorithm=None, expected=None):
    path = Path(path)
    if not path.exists():
        temporary = path.with_name(path.name + ".partial")
        print("Download", url, flush=True)
        with urllib.request.urlopen(url, timeout=120) as source, temporary.open("wb") as output:
            while True:
                block = source.read(1024 * 1024)
                if not block:
                    break
                output.write(block)
        temporary.replace(path)
    if algorithm:
        digest = hashlib.new(algorithm)
        with path.open("rb") as source:
            for block in iter(lambda: source.read(1024 * 1024), b""):
                digest.update(block)
        if digest.hexdigest().lower() != expected.lower():
            raise RuntimeError("Artifact checksum mismatch: " + path.name)
        print("Verified", path.name, algorithm, flush=True)
    return path

def extract(path):
    with zipfile.ZipFile(path) as archive:
        entries = archive.infolist()
        for item in entries:
            destination = (TOOLS / item.filename).resolve()
            if not destination.is_relative_to(TOOLS.resolve()):
                raise RuntimeError("Archive entry escapes tool directory")
            if stat.S_ISLNK(item.external_attr >> 16):
                continue
            archive.extract(item, TOOLS)
            if item.external_attr >> 16 & 0o111:
                destination.chmod(0o755)
        # ZipFile does not restore Unix symlinks, which NDK clang requires.
        for item in entries:
            if stat.S_ISLNK(item.external_attr >> 16):
                destination = TOOLS / item.filename
                target = archive.read(item).decode("utf-8")
                if not (destination.parent / target).resolve().is_relative_to(TOOLS.resolve()):
                    raise RuntimeError("Archive symlink escapes tool directory")
                if destination.exists() or destination.is_symlink():
                    destination.unlink()
                destination.symlink_to(target)

def google_tools():
    repository = fetch("https://dl.google.com/android/repository/repository2-3.xml", TOOLS / "repository2-3.xml")
    wanted = {"platforms;android-35", "build-tools;35.0.0", "ndk;28.2.13676358"}
    packages = [p for p in ET.parse(repository).getroot()
                if p.tag.endswith("remotePackage") and p.attrib["path"] in wanted]
    if len(packages) != len(wanted):
        raise RuntimeError("Pinned Google tool version missing from repository metadata")
    def one(package):
        for archive in package.find("archives").findall("archive"):
            if archive.findtext("host-os") not in (None, "linux"):
                continue
            complete = archive.find("complete")
            filename = complete.findtext("url")
            checksum = complete.find("checksum")
            algorithm = checksum.get("type", "sha1")
            path = fetch("https://dl.google.com/android/repository/" + filename,
                         TOOLS / filename, algorithm, checksum.text)
            extract(path)
            return
        raise RuntimeError("Linux archive unavailable")
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        list(pool.map(one, packages))

def maven(relative, filename, algorithm):
    url = "https://repo.maven.apache.org/maven2/" + relative
    with urllib.request.urlopen(url + "." + algorithm) as response:
        checksum = response.read().decode("ascii").strip().split()[0]
    fetch(url, TOOLS / filename, algorithm, checksum)

def main():
    TOOLS.mkdir(parents=True, exist_ok=True)
    google_tools()
    maven("org/eclipse/jdt/ecj/3.41.0/ecj-3.41.0.jar", "ecj.jar", "sha1")
    maven("org/apktool/apktool-cli/2.11.1/apktool-cli-2.11.1.jar", "apktool-cli.jar", "sha512")
    print("Build tools ready; build the minimal FFmpeg libraries, then run build_patch.py", flush=True)

if __name__ == "__main__":
    main()
