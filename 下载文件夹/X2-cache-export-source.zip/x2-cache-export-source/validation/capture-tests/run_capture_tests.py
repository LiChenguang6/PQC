#!/usr/bin/env python3
"""Run production PlayerCapture against original libmpv in an Android emulator.

Only synthetic media and headers are used. The installed application, account
state, remote services, and original native-library bytes are never modified.
"""
import argparse
from functools import partial
import hashlib
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import shutil
import subprocess
import threading
import time

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
TOOLS = BASE / "patch-tools"
BUILD = HERE / "build"
FIXTURE = HERE / "fixture"
RESULTS = HERE / "results"
ADB = BASE / "android-sdk/platform-tools/adb"
NDK = TOOLS / "android-ndk-r28c/toolchains/llvm/prebuilt/linux-x86_64/bin"
DEVICE_DIR = "/data/local/tmp/x2-capture-tests"
PRODUCTION = BASE / "export-patch"


def run(args, **kwargs):
    print("+", " ".join(str(x) for x in args), flush=True)
    return subprocess.run([str(x) for x in args], check=True, **kwargs)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def build():
    for folder in (BUILD, FIXTURE, RESULTS):
        folder.mkdir(exist_ok=True)
    fixture = FIXTURE / "capture-fixture.mp4"
    if not fixture.exists():
        run(["ffmpeg", "-nostdin", "-hide_banner", "-loglevel", "error", "-y",
             "-f", "lavfi", "-i", "testsrc2=size=160x90:rate=15",
             "-f", "lavfi", "-i", "sine=frequency=550:sample_rate=44100",
             "-t", "2", "-c:v", "libx264", "-preset", "ultrafast", "-threads", "1",
             "-pix_fmt", "yuv420p", "-c:a", "aac", "-movflags", "+faststart", fixture])
    run([NDK / "x86_64-linux-android24-clang", "-shared", "-fPIC", "-O2", "-Wall", "-Wextra",
         "-Werror=implicit-function-declaration", "-I" + str(TOOLS),
         HERE / "native/capture_helper.c", "-ldl", "-Wl,-soname,libcapturetest.so",
         "-Wl,-z,max-page-size=16384", "-o", BUILD / "libcapturetest.so"])
    run([NDK / "x86_64-linux-android24-clang", "-shared", "-fPIC", "-O2", "-Wall", "-Wextra",
         "-Werror=implicit-function-declaration", PRODUCTION / "native/player_capture.c",
         "-ldl", "-Wl,-soname,libx2player.so", "-Wl,-z,max-page-size=16384",
         "-o", BUILD / "libx2player.so"])
    classes, dex = BUILD / "classes", BUILD / "dex"
    for folder in (classes, dex):
        shutil.rmtree(folder, ignore_errors=True)
        folder.mkdir()
    java = sorted((HERE / "src").rglob("*.java"))
    java += [PRODUCTION / "src/org/x2/export/PlayerCapture.java"]
    android = TOOLS / "android-35/android.jar"
    run(["java", "-jar", TOOLS / "ecj.jar", "-source", "1.8", "-target", "1.8",
         "-encoding", "UTF-8", "-bootclasspath", android, "-d", classes, *java])
    run([TOOLS / "android-15/d8", "--min-api", "24", "--lib", android,
         "--output", dex, *sorted(classes.rglob("*.class"))])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--build-only", action="store_true")
    parser.add_argument("--serial", default="emulator-5554")
    parser.add_argument("--port", type=int, default=18765)
    args = parser.parse_args()
    build()
    if args.build_only:
        return
    adb = [ADB, "-s", args.serial]
    run([*adb, "shell", "mkdir", "-p", DEVICE_DIR])
    for src in (BUILD / "libcapturetest.so", BUILD / "libx2player.so",
                TOOLS / "x86_64/libmpv.so", BUILD / "dex/classes.dex",
                FIXTURE / "capture-fixture.mp4"):
        run([*adb, "push", src, DEVICE_DIR + "/" + src.name], stdout=subprocess.DEVNULL)

    requests = []
    pending_release = threading.Event()
    class Handler(SimpleHTTPRequestHandler):
        def do_GET(self):
            requests.append({"path": self.path, "headers": dict(self.headers.items())})
            if self.path == "/pending.mp4":
                body = (FIXTURE / "capture-fixture.mp4").read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "video/mp4")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.flush()
                pending_release.wait(20)
                try:
                    self.wfile.write(body)
                except (BrokenPipeError, ConnectionResetError):
                    pass
                return
            super().do_GET()
        def log_message(self, fmt, *values):
            print("fixture:", fmt % values, flush=True)
    server = ThreadingHTTPServer(("0.0.0.0", args.port), partial(Handler, directory=str(FIXTURE)))
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    uri = "http://10.0.2.2:%d/capture-fixture.mp4" % args.port
    command = "CLASSPATH={0}/classes.dex LD_LIBRARY_PATH={0} app_process -Djava.library.path={0} /system/bin org.x2.capturetests.CaptureTest {0} {1}".format(DEVICE_DIR, uri)
    start = time.monotonic()
    try:
        process = subprocess.run([str(x) for x in [*adb, "shell", command]], capture_output=True,
                                 text=True, timeout=90)
    finally:
        pending_release.set()
        server.shutdown()
        server.server_close()
    log = process.stdout + process.stderr
    (RESULTS / "runtime.log").write_text(log)
    (RESULTS / "fixture-http-requests.json").write_text(json.dumps(requests, indent=2) + "\n")
    print(log, end="")
    expected_headers = {"User-Agent": "X2CaptureTest/1.0 (controlled fixture)",
                        "Referer": "https://reference.invalid/watch?fixture=1",
                        "X-Capture-Test": "alpha,beta",
                        "X-Second-Test": "left, right; mode=fixture"}
    header_ok = bool(requests) and all(all(item["headers"].get(name) == value
                    for name, value in expected_headers.items()) for item in requests)
    success = process.returncode == 0 and "CAPTURE_TEST_SUCCESS" in log and header_ok
    result = {"passed": success, "exit": process.returncode,
              "elapsed_seconds": round(time.monotonic() - start, 3),
              "case_count": log.count("CASE_PASS "), "http_request_count": len(requests),
              "http_headers_verified": header_ok, "serial": args.serial, "fixture": uri,
              "original_mpv_sha256": sha(TOOLS / "x86_64/libmpv.so"),
              "production_source_sha256": {"PlayerCapture.java": sha(PRODUCTION / "src/org/x2/export/PlayerCapture.java"),
                                           "player_capture.c": sha(PRODUCTION / "native/player_capture.c")}}
    (RESULTS / "results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))
    if not success:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
