#include <jni.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <android/log.h>
#include "libavformat/avformat.h"
#include "libavcodec/avcodec.h"
#include "libavutil/error.h"

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "X2Export", __VA_ARGS__)

JNIEXPORT jstring JNICALL
Java_org_x2_export_NativeRemux_run(JNIEnv *env, jclass cls, jstring input,
                                  jstring output, jdouble expected_duration, jobject progress) {
    (void)cls;
    const char *src = (*env)->GetStringUTFChars(env, input, NULL);
    const char *dst = (*env)->GetStringUTFChars(env, output, NULL);
    AVFormatContext *in = NULL, *out = NULL, *verified = NULL;
    AVDictionary *opts = NULL, *muxopts = NULL;
    AVPacket *pkt = NULL;
    long *counts = NULL;
    char message[512] = "";
    int ret = 0, wrote_header = 0, n = 0;
    jclass pcb = (*env)->GetObjectClass(env, progress);
    jmethodID update = (*env)->GetMethodID(env, pcb, "update", "(D)V");
    jmethodID cancelled = (*env)->GetMethodID(env, pcb, "cancelled", "()Z");
#define FAIL_TEXT(s) do { snprintf(message, sizeof(message), "%s", (s)); goto cleanup; } while (0)
#define CHECK(call, stage) do { ret = (call); if (ret < 0) { char why[128]; av_strerror(ret, why, sizeof(why)); snprintf(message, sizeof(message), "%s: %s", (stage), why); goto cleanup; } } while (0)
    if (!src || !dst || !update || !cancelled) FAIL_TEXT("JNI initialization failed");
    if ((avformat_version() >> 16) != 60 || (avcodec_version() >> 16) != 60)
        FAIL_TEXT("Unsupported bundled media engine ABI");
    av_dict_set(&opts, "protocol_whitelist", "file,crypto,data", 0);
    av_dict_set(&opts, "allowed_extensions", "ALL", 0);
    av_dict_set(&opts, "err_detect", "explode", 0);
    CHECK(avformat_open_input(&in, src, NULL, &opts), "Open local cache");
    CHECK(avformat_find_stream_info(in, NULL), "Read cached media tracks");
    // Direct finite files have no HLS EXTINF total. Require the demuxer's
    // duration before writing, then apply the same complete-duration check.
    if (expected_duration == -1.0) {
        if (in->duration == AV_NOPTS_VALUE || in->duration <= 0)
            FAIL_TEXT("Source duration is unknown; complete-file verification is unavailable");
        expected_duration = (double)in->duration / AV_TIME_BASE;
    }
    if (in->nb_streams == 0 || in->nb_streams > 128) FAIL_TEXT("Invalid media track count");
    CHECK(avformat_alloc_output_context2(&out, NULL, "mp4", dst), "Create MP4");
    out->flags |= AVFMT_FLAG_AUTO_BSF;
    counts = calloc(in->nb_streams, sizeof(*counts));
    if (!counts) FAIL_TEXT("Out of memory");
    for (unsigned i = 0; i < in->nb_streams; i++) {
        AVStream *is = in->streams[i];
        if (is->codecpar->codec_type != AVMEDIA_TYPE_VIDEO &&
            is->codecpar->codec_type != AVMEDIA_TYPE_AUDIO &&
            is->codecpar->codec_type != AVMEDIA_TYPE_SUBTITLE)
            FAIL_TEXT("Cache contains an unsupported metadata/data track; no tracks were silently dropped");
        if (avformat_query_codec(out->oformat, is->codecpar->codec_id, FF_COMPLIANCE_NORMAL) == 0)
            FAIL_TEXT("A cached track is incompatible with MP4; transcoding is not enabled");
        AVStream *os = avformat_new_stream(out, NULL);
        if (!os) FAIL_TEXT("Create output track failed");
        CHECK(avcodec_parameters_copy(os->codecpar, is->codecpar), "Copy track information");
        os->codecpar->codec_tag = 0;
        os->time_base = is->time_base;
        os->disposition = is->disposition;
        av_dict_copy(&os->metadata, is->metadata, 0);
    }
    CHECK(avio_open(&out->pb, dst, AVIO_FLAG_WRITE), "Open temporary MP4");
    av_dict_set(&muxopts, "movflags", "+faststart", 0);
    CHECK(avformat_write_header(out, &muxopts), "Write MP4 header");
    wrote_header = 1;
    pkt = av_packet_alloc();
    if (!pkt) FAIL_TEXT("Allocate media packet failed");
    int64_t start = in->start_time == AV_NOPTS_VALUE ? 0 : in->start_time;
    int64_t last_time = 0;
    while ((ret = av_read_frame(in, pkt)) >= 0) {
        if ((*env)->CallBooleanMethod(env, progress, cancelled)) FAIL_TEXT("Cancelled");
        if ((*env)->ExceptionCheck(env)) FAIL_TEXT("Progress callback failed");
        int index = pkt->stream_index;
        if (index < 0 || (unsigned)index >= in->nb_streams) FAIL_TEXT("Invalid packet stream index");
        AVStream *is = in->streams[index], *os = out->streams[index];
        int64_t offset = av_rescale_q(start, AV_TIME_BASE_Q, is->time_base);
        if (pkt->pts != AV_NOPTS_VALUE) pkt->pts -= offset;
        if (pkt->dts != AV_NOPTS_VALUE) pkt->dts -= offset;
        if (pkt->pts != AV_NOPTS_VALUE) {
            int64_t time = av_rescale_q(pkt->pts, is->time_base, AV_TIME_BASE_Q);
            if (time > last_time) last_time = time;
        }
        av_packet_rescale_ts(pkt, is->time_base, os->time_base);
        pkt->pos = -1;
        counts[index]++;
        CHECK(av_interleaved_write_frame(out, pkt), "Write media packet");
        av_packet_unref(pkt);
        if ((++n % 32) == 0 && in->duration > 0) {
            double p = (double)last_time / (double)in->duration;
            (*env)->CallVoidMethod(env, progress, update, p > .99 ? .99 : p);
            if ((*env)->ExceptionCheck(env)) FAIL_TEXT("Progress callback failed");
        }
    }
    if (ret != AVERROR_EOF) CHECK(ret, "Read cached segment");
    for (unsigned i = 0; i < in->nb_streams; i++)
        if (counts[i] == 0) FAIL_TEXT("A media track contained no packets");
    CHECK(av_write_trailer(out), "Finalize MP4");
    wrote_header = 0;
    CHECK(avio_closep(&out->pb), "Close MP4");
    CHECK(avformat_open_input(&verified, dst, NULL, NULL), "Verify MP4 container");
    CHECK(avformat_find_stream_info(verified, NULL), "Verify MP4 tracks");
    if (verified->nb_streams != in->nb_streams || verified->duration <= 0)
        FAIL_TEXT("MP4 verification failed: track count or duration");
    double duration_delta = (double)verified->duration / AV_TIME_BASE - expected_duration;
    if (duration_delta < 0) duration_delta = -duration_delta;
    // A/V packet boundaries add a few frames; a skipped HLS segment must not
    // be accepted merely because libavformat eventually returned EOF.
    if (expected_duration <= 0 || duration_delta > 0.25)
        FAIL_TEXT("MP4 duration differs from complete playlist; a segment may be damaged or missing");
    for (unsigned i = 0; i < in->nb_streams; i++) {
        if (verified->streams[i]->codecpar->codec_id != in->streams[i]->codecpar->codec_id)
            FAIL_TEXT("MP4 verification failed: codec changed");
    }
    LOGI("Remux OK: %u tracks, %d packets, duration %.3f seconds", verified->nb_streams, n,
         (double)verified->duration / AV_TIME_BASE);
cleanup:
    (void)wrote_header;
    av_dict_free(&opts);
    av_dict_free(&muxopts);
    av_packet_free(&pkt);
    if (verified) avformat_close_input(&verified);
    if (out) {
        if (out->pb) avio_closep(&out->pb);
        avformat_free_context(out);
    }
    if (in) avformat_close_input(&in);
    free(counts);
    if (src) (*env)->ReleaseStringUTFChars(env, input, src);
    if (dst) (*env)->ReleaseStringUTFChars(env, output, dst);
    return (*env)->NewStringUTF(env, message);
}
