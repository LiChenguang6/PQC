#define _GNU_SOURCE
#include <jni.h>
#include <dlfcn.h>
#include <stdint.h>
#include <string.h>
static void *library;
static uint8_t *buffer;
JNIEXPORT void JNICALL Java_org_x2_titletests_PageTitleTest_seed(JNIEnv *e,jclass c,jstring path,jstring uri,jstring title,jint odd) {
 (void)c;
 if(!library) { const char *p=(*e)->GetStringUTFChars(e,path,0);library=dlopen(p,RTLD_NOW|RTLD_LOCAL);(*e)->ReleaseStringUTFChars(e,path,p);if(!library){jclass ex=(*e)->FindClass(e,"java/lang/RuntimeException");(*e)->ThrowNew(e,ex,dlerror());return;} void *symbol=dlsym(library,"_kDartVmSnapshotData");Dl_info info;dladdr(symbol,&info);buffer=(uint8_t *)info.dli_fbase+0x8c1000; }
 uint32_t *h=(uint32_t *)buffer;h[2]=1;__sync_synchronize();h[0]=(*e)->GetStringLength(e,title);h[1]=(*e)->GetStringLength(e,uri);
 (*e)->GetStringRegion(e,title,0,h[0],(jchar *)(buffer+16));(*e)->GetStringRegion(e,uri,0,h[1],(jchar *)(buffer+2064));h[3]=0x35543258;__sync_synchronize();h[2]=odd?1:2;
}
