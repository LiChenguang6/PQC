from pathlib import Path
import zipfile,json,hashlib
B=Path('/workspace/x2-analysis');P=B/'export-patch';R=B/'export20-tests';G=Path('/workspace/pqc-upload/下载文件夹');changed=[]
with zipfile.ZipFile(G/'X2-original-playback-test.apk') as baseline,zipfile.ZipFile(B/'output/X2-cache-export.apk') as new,zipfile.ZipFile(B/'input/app.apk') as original:
 for abi,progress,size,pause,pause_size in [('arm64-v8a',0x70c130,0x54,0x70ca18,0xfc),('x86_64',0x6202e8,0x54,0x620e44,0x100)]:
  old=baseline.read('lib/'+abi+'/libapp.so');data=new.read('lib/'+abi+'/libapp.so')
  assert old[progress:progress+size]==data[progress:progress+size],(abi,'progress callback changed')
  assert old[pause:pause+pause_size]==data[pause:pause+pause_size],(abi,'pause callback changed')
 for n in original.namelist():
  if n.startswith('lib/') and n.endswith('.so') and not n.endswith('/libapp.so'):assert original.read(n)==new.read(n),n
 for n in baseline.namelist():
  if n.startswith('lib/') and n.endswith('.so') and baseline.read(n)!=new.read(n):changed.append(n)
 assert not any('capturetest' in n for n in new.namelist())
with zipfile.ZipFile(G/'X2-original-playback-test-source.zip') as source:
 for n in ['DownloadStore.java','DownloadService.java','DownloadTasksActivity.java','DownloadConfig.java','VideoIdentity.java','VideoThumbnails.java','VideoPreviewActivity.java','VideoPreviewCard.java','MediaDownloader.java']:
  assert source.read('x2-cache-export-source/export-patch/src/org/x2/export/'+n)==(P/'src/org/x2/export'/n).read_bytes(),n
r={'passed':True,'apk_sha256':hashlib.sha256((B/'output/X2-cache-export.apk').read_bytes()).hexdigest(),'working_baseline_player_progress_and_pause_unchanged':True,'download_preview_dedupe_java_unchanged':True,'changed_native_files':changed,'real_forbidden_full_playback_verified':False};(R/'payload-results.json').write_text(json.dumps(r,indent=2));print(r)
