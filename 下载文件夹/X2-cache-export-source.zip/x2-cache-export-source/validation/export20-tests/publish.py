from pathlib import Path
import hashlib,json,zipfile,subprocess,shutil,urllib.request,urllib.parse
B=Path('/workspace/x2-analysis');P=B/'export-patch';R=B/'export20-tests';O=B/'output';G=Path('/workspace/pqc-upload');F='下载文件夹'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(*a):return subprocess.check_output(a,text=True).strip()
h=sha(O/'X2-cache-export.apk');ui=json.loads((R/'ui-results.json').read_text());assert ui['apk_sha256']==h and all(ui[k]['passed'] for k in ['controls20','gallery16'])
for n in ['payload-results.json','ad-route-results.json']:
 d=json.loads((R/n).read_text());assert d['passed'] and d['apk_sha256']==h
assert len(json.loads((R/'pause-results.json').read_text())['cases'])==96
assert json.loads((R/'getter-results.json').read_text())['passed']
usage='''# X2 export20：基于可播放回归包的广告和入口设置

本版保留用户确认可播放的 export19-baseline 原版进度回调、暂停分支和播放地址链路，不恢复 export18 的试看计时跳过钩子。

## 广告

管理 → 下载设置 → 自动跳过播放器广告，默认开启。进入长视频播放器时跳过进入广告，调用应用自己的广告关闭完成函数，保留详情更新及播放器初始化动作。开关在重新进入视频时生效。若关闭广告后出现播放异常，关闭此开关，重新进入视频即可恢复 export19-baseline 的原版广告进入路径，无需换包。

这次仅处理播放器进入广告，不声称移除全部页面的所有广告。保留正常业务弹窗。

## 禁区入口测试

管理 → 下载设置 → 开发测试：禁区入口（仅本地）。本次升级首次打开时关闭旧实验标记，需手动开启；开启后返回主页重新进入禁区。此功能只对原会员 getter 的返回值作本地测试覆盖，保留原反应式用户信息读取；不会更改账号、登录令牌、发往服务器的会员参数或服务器权限。

原进度和暂停逻辑仍按当前详情可播放状态运行；如果服务器返回试看源或 canWatch=false，仍可能只能试看或提示会员。未验证禁区完整播放，不代表获得完整内容权限。

## 对比结论

export18 与 export19-baseline 恢复差异集中于进入广告调用、会员 getter、进度回调和暂停分支四处。用户确认整体回退后免费视频恢复，尚不能据此唯一定位其中哪一个改动是根因。export20 将广告和本地入口分成独立开关，保持两处播放回调为用户确认版本的原始实现，便于单独关闭广告路径改动。

下载、源去重、已完成预览、每行列数、文件管理、后台任务及系统导航栏保留。直接覆盖安装，无需先卸载。原版播放回归 APK 仍保留在同目录。

APK SHA-256：`'''+h+'`\n'
(O/'使用说明.md').write_text(usage)
(O/'VALIDATION.md').write_text('''# export20 验证

交付 APK SHA-256：`'''+h+'''`

- ARM64/x86_64 共 96 组实际交付库回调指令测试，0–120 秒在开关组合下保留原版播放许可及暂停判断。
- 8 组广告分支测试验证开关互不影响、跳转原版 showAds 或原版关闭完成函数、控制器和回调参数及栈保持。
- 20 组完整会员 getter 指令测试保留原有用户信息读取，入口开关只改变本地返回结果。
- 云端 API29 x86_64 安装最终 APK 并核对 SHA；真实映射 AOT 库后，通过设置界面验证升级不自动沿用旧实验入口标记、两个开关持久化及 JNI 对各自内存标记的实际写入和互不干扰。
- 两架构的进度和暂停函数与用户确认可播放的 export19-baseline 字节一致；下载、队列、去重、预览 Java 业务代码一致。
- 预览设置、列数、隐藏图片、独立预览页及本地播放请求界面回归通过。
- 原有 libflutter/libmpv 等库与原始 APK 字节一致，测试辅助库未包含在交付 APK。

真实平台广告不再出现、免费视频继续完整播放及禁区完整播放尚未在用户设备验收。不能将以上离线/模拟器结果描述为禁区完整播放成功或已开通服务端 VIP。
''')
f=P/'README.md';t=f.read_text().replace('源码（export19-baseline）','源码（export20）',1).replace('版本码 27','版本码 28',1);i=t.index('## export19-baseline');t=t[:i]+'''## export20：独立广告开关与本地入口测试

保留用户确认可播放回归包的进度和暂停函数。新增 0x4934 独立广告标记、只写该标记的 JNI 设置接口，以及尾跳转的广告入口小包装；零值调用原 showAds，非零值调用其原关闭完成函数。与 0x4904 本地入口测试标记分离，默认跳过播放器进入广告，可在设置回退原路径。原用户 getter 的可选入口测试恢复；不恢复原先跳过进度/暂停的测试分支，不更改服务器账号或请求权限。测试见 validation/export20-tests。真实禁区完整播放未验证，不能声明解锁。

'''+t[i:];f.write_text(t)
subprocess.run(['python3',str(P/'package_source.py')],check=True)
with zipfile.ZipFile(O/'X2-cache-export-source.zip') as z:assert z.testzip() is None and not any(n.endswith(('.apk','.p12')) for n in z.namelist());assert z.read('x2-cache-export-source/export-patch/restore_original_playback.py')==(P/'restore_original_playback.py').read_bytes()
assert not run('git','-C',str(G),'status','--porcelain')
subprocess.run(['git','-C',str(G),'fetch','origin','main'],check=True);subprocess.run(['git','-C',str(G),'merge','--ff-only','origin/main'],check=True)
names=['X2-cache-export.apk','X2-cache-export-source.zip','使用说明.md','VALIDATION.md']
for n in names:shutil.copy2(O/n,G/F/n)
subprocess.run(['git','-C',str(G),'add','--',*[F+'/'+n for n in names]],check=True)
assert set(run('git','-C',str(G),'-c','core.quotepath=false','diff','--cached','--name-only').splitlines())=={F+'/'+n for n in names}
subprocess.run(['git','-C',str(G),'commit','-m','X2 export20: independent ad and local entry settings with working player callbacks preserved'],check=True);subprocess.run(['git','-C',str(G),'push','origin','HEAD:main'],check=True)
c=run('git','-C',str(G),'rev-parse','HEAD');url='https://raw.githubusercontent.com/LiChenguang6/PQC/'+c+'/'+urllib.parse.quote(F+'/X2-cache-export.apk')
with urllib.request.urlopen(url,timeout=60) as response:assert hashlib.sha256(response.read()).hexdigest()==h
result={'commit':c,'url':url,'sha256':h,'real_forbidden_full_playback_verified':False};(R/'published-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False))
