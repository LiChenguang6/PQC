from pathlib import Path
import zipfile,struct,json,hashlib
from unicorn import *
from unicorn.arm64_const import *
from unicorn.x86_const import *
B=Path('/workspace/x2-analysis');R=B/'export21-tests';cases=[]
for abi,buffer,start,end in [('arm64-v8a',0x8b1000,0x6403fc,0x640420),('x86_64',0x8c1000,0x6200ac,0x6200ca)]:
 with zipfile.ZipFile(B/'output/X2-cache-export.apk') as z:d=z.read('lib/'+abi+'/libapp.so')
 arm=abi=='arm64-v8a'
 for high in [0,1]:
  base=high<<32
  for value in [None,False,True]:
   for enabled in [0,1]:
    for ads in [0,1]:
     for entry in [0,1]:
      u=Uc(UC_ARCH_ARM64 if arm else UC_ARCH_X86,UC_MODE_ARM if arm else UC_MODE_64);u.mem_map(0,0x900000);u.mem_write(0,d);u.mem_map(base+0x1000000,0x20000);u.mem_map(0x3000000,0x20000)
      model=base+0x1000101;controller=base+0x1001001;player=base+0x1002001;null=base+0x1003001;pool=0x3000100;thr=0x3008000
      original=null+(0 if value is None else 0x20 if value else 0x30);expected=null+0x20 if enabled else original
      def put(at,v,fmt='I'):u.mem_write(at,struct.pack('<'+fmt,v))
      put(model+0xb,original&0xffffffff);put(controller+0x27,player&0xffffffff);put(buffer+0x4938,enabled);put(buffer+0x4934,ads);put(buffer+0x4904,entry)
      if arm:
       put(pool+0x40,0xdeadbeef,'Q');regs={UC_ARM64_REG_X0:model,UC_ARM64_REG_X1:controller,UC_ARM64_REG_X22:null,UC_ARM64_REG_X28:high,UC_ARM64_REG_X27:pool}
      else:
       put(pool+0x3f,0xdeadbeef);put(thr+0x48,base,'Q');put(thr+0x80,null+0x20,'Q');regs={UC_X86_REG_RAX:model,UC_X86_REG_RDI:controller,UC_X86_REG_R14:thr,UC_X86_REG_R15:pool}
      for k,v in regs.items():u.reg_write(k,v)
      u.emu_start(start,end,count=80)
      for at in [controller+0x5f,player+0x47]:assert struct.unpack('<I',u.mem_read(at,4))[0]==(expected&0xffffffff),(abi,high,value,enabled,hex(at))
      assert struct.unpack('<I',u.mem_read(model+0xb,4))[0]==(original&0xffffffff),'server model altered'
      cases.append({'abi':abi,'heap_high':high,'source_can_watch':value,'experimental':bool(enabled),'ad_mode':ads,'entry_mode':entry,'server_model_preserved':True,'both_player_states_correct':True})
r={'passed':True,'apk_sha256':hashlib.sha256((B/'output/X2-cache-export.apk').read_bytes()).hexdigest(),'cases':cases,'actual_server_full_content_verified':False};(R/'permission-results.json').write_text(json.dumps(r,indent=2));print('PASS',len(cases),'actual-payload permit-state cases; default reproduces original, opt-in changes controller/player only, server detail unchanged')
