exec(open('/workspace/x2-analysis/export3-tests/first_folder.py').read().split("end=time.monotonic()+60")[0])
import subprocess
assert 'HOME_AND_SCREEN_OFF_WITH_FOREGROUND_SERVICE' in (ROOT/'background-run.log').read_text()
assert 'isForeground=true' in (ROOT/'foreground-service.txt').read_text()
assert ':downloads' in (ROOT/'wake-lock.txt').read_text()
power=(ROOT/'background-screen-state.txt').read_text();assert 'mWakefulness=Asleep' in power or 'mWakefulness=Dozing' in power
for label in ['B','C']:ui.wait_node('done-'+label,lambda n,l=label:'任务 '+l+' ·' in n.get('text','') and '已保存 MP4' in n.get('text',''),seconds=30)
texts=[n.get('text','') for n in ui.dump('completed-queue')];assert not any('任务 A ·' in s or '任务 D ·' in s for s in texts),texts
files=ui.adb('shell','find','/sdcard/Download/X2_export3_A','-type','f').stdout.decode().splitlines();assert len(files)==3,files
# Reuse the corrected socket teardown-aware assertions and MP4 verification.
source=(ROOT/'background_test.py').read_text();exec(source[source.index('server=json.loads'):])
