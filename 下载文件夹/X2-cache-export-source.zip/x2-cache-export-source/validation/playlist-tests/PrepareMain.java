import java.io.File;
import org.x2.export.PlaylistPreparer;

public final class PrepareMain {
    public static void main(String[] args) throws Exception {
        PlaylistPreparer.Prepared prepared = PlaylistPreparer.prepare(new File(args[0]), new File(args[1]));
        System.out.println(prepared.playlist.getCanonicalPath());
        System.out.println(prepared.segments);
        System.out.println(prepared.durationSeconds);
        System.out.println(prepared.sourceName);
    }
}
