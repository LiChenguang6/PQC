"""Pinned launch/default-tab changes and GC-safe leaf copies of title + play URL.
No Dart references escape to native code; strings are copied before any safepoint.
"""
import hashlib,struct,subprocess
from pathlib import Path
from patch_scroll import branch
PINS={'arm64-v8a':'e03d55d9baf0b7609007e52eabc7893867e599251a20c36be175352745930205','x86_64':'ac2c01b002265b00282fb664308d269225ecabc3a58eb37c19714e9b432c3e7c'}
SPECS={
 'arm64-v8a':dict(buffer=0x8b1000,entry=0x641f50,end=0x641fec,entry_old='02b042b8',end_old='ef031daa',ready=0x5b1cc0,setstate=0x442490,home=0x5f9490,default=0x86e470),
 'x86_64':dict(buffer=0x8c1000,entry=0x6e757d,end=0x6e761e,entry_old='8b482b49034e48',end_old='4889ec5dc3',ready=0x65f695,setstate=0x4057cc,home=0x6a36dc,default=0x8208ef)}

def arm_string(prefix,dest,limit):
 return f'''
ldur w3,[x1,#-1]
ubfx w3,w3,#12,#20
cmp w3,#94
b.eq {prefix}_valid
cmp w3,#95
b.ne {prefix}_done
{prefix}_valid:
ldur w4,[x1,#7]
lsr w4,w4,#1
cmp w4,#{limit}
b.hi {prefix}_done
str w4,[x2,#{0 if prefix=='title' else 4}]
add x5,x2,#{dest}
add x1,x1,#15
cbz w4,{prefix}_done
{prefix}_loop:
cmp w3,#94
b.ne {prefix}_wide
ldrb w6,[x1],#1
b {prefix}_put
{prefix}_wide:
ldrh w6,[x1],#2
{prefix}_put:
strh w6,[x5],#2
subs w4,w4,#1
b.ne {prefix}_loop
{prefix}_done:
'''
def _arm_base(s):
 save='stp x0,x1,[x15,#-16]!\nstp x2,x3,[x15,#-16]!\nstp x4,x5,[x15,#-16]!\nstp x6,x7,[x15,#-16]!\n'
 restore='ldp x6,x7,[x15],#16\nldp x4,x5,[x15],#16\nldp x2,x3,[x15],#16\nldp x0,x1,[x15],#16\n'
 addr='adrp x2,title_buffer\nadd x2,x2,:lo12:title_buffer\n'
 return '.text\n.global entry_copy,end_copy\nentry_copy:\n'+save+addr+'''
ldr w3,[x2,#8]
add w3,w3,#1
orr w3,w3,#1
str w3,[x2,#8]
dmb ish
str xzr,[x2]
ldur w1,[x0,#0x53]
add x1,x1,x28,lsl #32
cmp w1,w22
b.eq title_done
ldur w1,[x1,#0x53]
add x1,x1,x28,lsl #32
'''+arm_string('title',16,1024)+restore+'ldur w2,[x0,#0x2b]\nb entry_resume\nend_copy:\n'+save+addr+'mov x1,x0\n'+arm_string('uri',2064,8192)+'''
mov w3,#0x3258
movk w3,#0x3554,lsl #16
str w3,[x2,#12]
dmb ish
ldr w3,[x2,#8]
add w3,w3,#1
str w3,[x2,#8]
'''+restore+'mov x15,x29\nb end_resume\n'
def x_string(prefix,dest,limit):
 return f'''
movl -1(%rdi),%ecx
shrl $12,%ecx
cmpl $94,%ecx
je {prefix}_valid
cmpl $95,%ecx
jne {prefix}_done
{prefix}_valid:
movl 7(%rdi),%edx
shrl $1,%edx
cmpl ${limit},%edx
ja {prefix}_done
movl %edx,{0 if prefix=='title' else 4}(%r8)
leaq {dest}(%r8),%rsi
addq $15,%rdi
testl %edx,%edx
jz {prefix}_done
{prefix}_loop:
cmpl $94,%ecx
jne {prefix}_wide
movzbl (%rdi),%eax
incq %rdi
jmp {prefix}_put
{prefix}_wide:
movzwl (%rdi),%eax
addq $2,%rdi
{prefix}_put:
movw %ax,(%rsi)
addq $2,%rsi
decl %edx
jnz {prefix}_loop
{prefix}_done:
'''
def _x_base(s):
 regs=['rax','rcx','rdx','rdi','rsi','r8'];save='pushfq\n'+''.join('pushq %'+r+'\n' for r in regs);restore=''.join('popq %'+r+'\n' for r in regs[::-1])+'popfq\n'
 addr=f'leaq 0x{s["buffer"]:x}(%rip),%r8\n' # replaced with symbolic absolute relocation below
 addr='leaq title_buffer(%rip),%r8\n'
 return '.text\n.global entry_copy,end_copy,default_video\nentry_copy:\n'+save+addr+'''
movl 8(%r8),%ecx
incl %ecx
orl $1,%ecx
movl %ecx,8(%r8)
mfence
movq $0,(%r8)
movl 0x53(%rax),%edi
addq 0x48(%r14),%rdi
cmpq 0x78(%r14),%rdi
je title_done
movl 0x53(%rdi),%edi
addq 0x48(%r14),%rdi
'''+x_string('title',16,1024)+restore+f'movl 0x2b(%rax),%ecx\naddq 0x48(%r14),%rcx\njmp 0x{s["entry"]+7:x}\nend_copy:\n'+save+addr+'movq %rax,%rdi\n'+x_string('uri',2064,8192)+'''
movl $0x35543258,12(%r8)
mfence
incl 8(%r8)
'''+restore+'movq %rbp,%rsp\npopq %rbp\nret\ndefault_video:\nmovl $1,%edi\njmp 0x6b25b0\n'

def arm_asm(s):
 a=_arm_base(s)
 if s['entry']!=SPECS['arm64-v8a']['entry']:return a
 anchor='ldur w1,[x0,#0x53]\n'
 copy="""add x4,x2,#0x4000
mov x3,#-1
str x3,[x4,#0x820]
str x3,[x4,#0x828]
str x3,[x4,#0x830]
str x3,[x4,#0x838]
str x3,[x4,#0x840]
str xzr,[x4,#0x848]
ldur w1,[x0,#0x53]
add x1,x1,x28,lsl #32
cmp w1,w22
b.eq detail_done
ldur w3,[x1,#-1]
ubfx w3,w3,#12,#20
cmp w3,#245
b.ne detail_done
ldur x3,[x1,#0x57]
str x3,[x4,#0x820]
ldur x3,[x1,#0x3b]
str x3,[x4,#0x828]
ldur x3,[x1,#0x5f]
str x3,[x4,#0x830]
ldur x3,[x1,#0x4b]
str x3,[x4,#0x838]
ldur w3,[x1,#0xb]
add w5,w22,#0x20
cmp w3,w5
b.eq detail_true
add w5,w22,#0x30
cmp w3,w5
b.ne detail_marker
str xzr,[x4,#0x840]
b detail_marker
detail_true:
mov x3,#1
str x3,[x4,#0x840]
detail_marker:
mov w3,#0x444d
movk w3,#0x3531,lsl #16
str x3,[x4,#0x848]
detail_done:
"""
 assert anchor in a;return a.replace(anchor,copy+anchor,1)

def x_asm(s):
 a=_x_base(s)
 if s['entry']!=SPECS['x86_64']['entry']:return a
 anchor='movl 0x53(%rax),%edi\n'
 copy="""movq $-1,0x4820(%r8)
movq $-1,0x4828(%r8)
movq $-1,0x4830(%r8)
movq $-1,0x4838(%r8)
movq $-1,0x4840(%r8)
movq $0,0x4848(%r8)
movl 0x53(%rax),%edi
addq 0x48(%r14),%rdi
cmpq 0x78(%r14),%rdi
je detail_done
movl -1(%rdi),%ecx
shrl $12,%ecx
andl $0xfffff,%ecx
cmpl $245,%ecx
jne detail_done
movq 0x57(%rdi),%rcx
movq %rcx,0x4820(%r8)
movq 0x3b(%rdi),%rcx
movq %rcx,0x4828(%r8)
movq 0x5f(%rdi),%rcx
movq %rcx,0x4830(%r8)
movq 0x4b(%rdi),%rcx
movq %rcx,0x4838(%r8)
movl 0xb(%rdi),%ecx
cmpl 0x80(%r14),%ecx
je detail_true
movl 0x78(%r14),%edx
addl $0x30,%edx
cmpl %edx,%ecx
jne detail_marker
movq $0,0x4840(%r8)
jmp detail_marker
detail_true:
movq $1,0x4840(%r8)
detail_marker:
movq $0x3531444d,0x4848(%r8)
detail_done:
"""
 assert anchor in a;return a.replace(anchor,copy+anchor,1)


def apply(data,abi,ndk,work):
 if abi not in SPECS:return data,None
 assert hashlib.sha256(data).hexdigest()==PINS[abi]
 s=SPECS[abi];buf=bytearray(data);work=Path(work);work.mkdir(parents=True,exist_ok=True)
 ph=struct.unpack_from('<Q',buf,32)[0];n=struct.unpack_from('<H',buf,56)[0]
 for i in range(n):
  p=ph+56*i;t,f,o,v,pa,fs,ms,a=struct.unpack_from('<IIQQQQQQ',buf,p)
  if t==1 and f==5: rx=p;cave=(v+fs+15)&~15
  if t==1 and f==6: rw=p;rwva=v;assert fs==ms==0x80
 compiler='aarch64-linux-android24-clang' if abi=='arm64-v8a' else 'x86_64-linux-android24-clang'
 asm=work/(abi+'.S');obj=work/(abi+'.o');elf=work/(abi+'.elf');binary=work/(abi+'.bin')
 asm.write_text(arm_asm(s) if abi=='arm64-v8a' else x_asm(s))
 subprocess.run([str(Path(ndk)/compiler),'-c',str(asm),'-o',str(obj)],check=True)
 subprocess.run([str(Path(ndk)/'ld.lld'),'-Ttext='+hex(cave),'--defsym=title_buffer='+hex(s['buffer']),'--defsym=entry_resume='+hex(s['entry']+4),'--defsym=end_resume='+hex(s['end']+4),'-e','entry_copy',str(obj),'-o',str(elf)],check=True,stdout=subprocess.DEVNULL)
 subprocess.run([str(Path(ndk)/'llvm-objcopy'),'--only-section=.text','-O','binary',str(elf),str(binary)],check=True)
 code=binary.read_bytes();assert cave+len(code)<rwva and not any(buf[cave:cave+len(code)])
 nm=subprocess.check_output([str(Path(ndk)/'llvm-nm'),str(elf)],text=True)
 symbols={line.split()[2]:int(line.split()[0],16) for line in nm.splitlines() if len(line.split())==3}
 changes=[]
 def change(name,at,expected,replacement):
  assert data[at:at+len(expected)]==expected,(abi,name,data[at:at+len(expected)].hex(),expected.hex())
  assert len(expected)==len(replacement);buf[at:at+len(expected)]=replacement
  changes.append(dict(name=name,offset=at,before=expected.hex(),after=replacement.hex()))
 for key in ('entry','end'):
  before=bytes.fromhex(s[key+'_old']);jmp=branch(abi,s[key],symbols[key+'_copy']);change('copy_'+key,s[key],before,jmp+b'\x90'*(len(before)-len(jmp)))
 if abi=='arm64-v8a':
  change('skip_only_ad_counter_load',0x5f94bc,bytes.fromhex('017041f8'),bytes.fromhex('1f2003d5'))
  change('skip_only_ad_counter_gate',0x5f94c0,bytes.fromhex('410600b5'),bytes.fromhex('1f2003d5'))
 else:
  change('skip_only_ad_counter_load',0x6a370a,bytes.fromhex('488b4817'),b'\x90'*4)
  change('skip_only_ad_counter_gate',0x6a3712,bytes.fromhex('0f85ee000000'),b'\x90'*6)
 change('auto_skip_after_required_init_with_original_readiness_guards',s['ready'],branch(abi,s['ready'],s['setstate'],True),branch(abi,s['ready'],s['home'],True))
 if abi=='arm64-v8a':change('default_video',s['default'],bytes.fromhex('010080d2'),bytes.fromhex('210080d2'))
 else:change('default_video',s['default'],branch(abi,s['default'],0x6b25b0,True),branch(abi,s['default'],symbols['default_video'],True))
 if abi=='arm64-v8a':
  for at in (0x707bc0,0x707c48):change('initial_index_or_missing_tab_to_video',at,bytes.fromhex('000080d2'),bytes.fromhex('200080d2'))
 else:
  change('initial_index_to_video',0x5fc59a,branch(abi,0x5fc59a,0x5fc64d),branch(abi,0x5fc59a,0x5fc5c0))
  change('missing_tab_to_video',0x5fc63b,bytes.fromhex('0f850a000000'),b'\x0f\x85'+struct.pack('<i',0x5fc5c0-0x5fc641))
 end=cave+len(code);struct.pack_into('<QQ',buf,rx+32,end-0x340000,end-0x340000);struct.pack_into('<Q',buf,rw+40,0x6000)
 buf[cave:end]=code
 return bytes(buf),dict(changes=changes,cave=cave,code_size=len(code),buffer=s['buffer'],symbols=symbols,output_sha256=hashlib.sha256(buf).hexdigest())
