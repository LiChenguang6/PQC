from pathlib import Path
import zipfile,json,struct,hashlib
B=Path('/workspace/x2-analysis');info=json.loads((B/'output/build-info.json').read_text());changes={};preserved=[]
with zipfile.ZipFile(B/'input/app.apk') as old,zipfile.ZipFile(B/'output/X2-cache-export.apk') as new:
 for n in old.namelist():
  if not n.startswith('lib/') or not n.endswith('.so'):continue
  a,b=old.read(n),new.read(n)
  if a==b:preserved.append(n);continue
  abi=n.split('/')[1];s=info['related_scroll_patch'][abi];assert n.endswith('/libapp.so') and len(a)==len(b)
  length=4 if abi=='arm64-v8a' else 5
  ranges=[(s['call'],s['call']+length),(s['ret'],s['ret']+length),(s['cave'],s['cave']+s['initializer_size'])]
  for change in s['additional_ui_changes']:
   at=change['offset'];before=bytes.fromhex(change['before']);after=bytes.fromhex(change['after']);assert a[at:at+len(before)]==before and b[at:at+len(after)]==after;ranges.append((at,at+len(after)))
  phoff=struct.unpack_from('<Q',a,32)[0];ent,count=struct.unpack_from('<HH',a,54)
  for i in range(count):
   if struct.unpack_from('<II',a,phoff+i*ent)==(1,5):ranges.append((phoff+i*ent+32,phoff+i*ent+48))
  countdiff=0
  for index,(x,y) in enumerate(zip(a,b)):
   if x!=y:assert any(lo<=index<hi for lo,hi in ranges),(n,index);countdiff+=1
  assert hashlib.sha256(b).hexdigest()==s['output_sha256'];changes[n]={'changed_bytes':countdiff,'only_declared_UI_and_scroll_patches':True,'file_length_unchanged':True}
r={'preserved_original_native_libraries':len(preserved),'changed_original_native_libraries':changes,'output_sha256':info['output_sha256']};assert len(preserved)==19
(B/'export4-tests/payload-results.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
