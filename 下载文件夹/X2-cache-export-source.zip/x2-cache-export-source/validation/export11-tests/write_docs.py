from pathlib import Path
import subprocess,json
B=Path('/workspace/x2-analysis');R=B/'export11-tests';O=B/'output';sha=json.loads((O/'build-info.json').read_text())['output_sha256']
s=subprocess.check_output(['git','-C','/workspace/pqc-upload','show','9f9553a87444af84809c523b78d179277df9193d:下载文件夹/使用说明.md']).decode();s=s.replace('export10','export11').replace('版本码 18','版本码 19');a=s.index('APK SHA-256：');e=s.index('\n',a);s=s[:a]+'APK SHA-256：`'+sha+'`'+s[e:]
a=s.index('## 本次测试版');e=s.index('## 保留功能',a);s=s[:a]+'''## export11：定位真实设备20秒停止，并补强开关同步

已收到反馈：export10在红米Turbo4Pro / Android16开启测试后仍约20秒暂停／回退。此版没有认定真实播放限制已解除。

开发开关现在切换时立即同步到原生层，播放期间也会同步，不依赖主页是否有焦点或Flutter是否已显示首帧。保留原两处本地20秒控制补丁。

新增“管理 → 下载设置 → 播放诊断（复制）”。请按以下步骤记录：

1. 直接覆盖安装，不要卸载。在下载设置保持开发测试开启。
2. 重新打开禁区视频，观察约25秒，或等到暂停／回退出现。
3. 尽快打开“管理 → 下载设置 → 播放诊断（复制）”，点击“复制”，将文字发回分析。只保留最近45条数值记录，建议停止后立即操作。

诊断包含版本、运行架构、系统版本、配置与实际开关、暂停分支进入／跳过次数，以及播放器的进度、时长、暂停／结束／空闲标记。不包含视频地址、标题、请求头、账号或密钥，无需连接电脑、Root或USB调试。设置页支持滚动。

打开管理页本身可能使原播放器暂停，所以需要看之前的记录。bridge=unavailable 表示没有找到原生桥；pause_seen/pause_skipped 分别是超过20秒进入该补丁、以及测试开启时跳过暂停／回退的次数。计数不是实际完整播放证明。

**本版仍未验证真实禁区视频连续播放超过20秒。** 云端缺少可访问的真实平台流，诊断用于查明补丁实际命中与播放器状态，避免继续只凭指令测试发布“已解决”的结论。

'''+s[e:];(O/'使用说明.md').write_text(s)
text='# export11 诊断与同步验证\n\nAPK SHA-256：`'+sha+'`\n\n真实禁区视频 >20 秒：未验证。用户报告红米Turbo4Pro / Android16仍停止，本次增加开关独立同步与只含数值的本机诊断，不把受控MPV测试当作真实平台播放。云端API29 x86_64与用户Android16设备不是同一环境。\n\n'
for name in ['diagnostic-results.json','installed-results.json','flutter-startup-results.json','payload-results.json']:
 p=R/name
 if p.exists():text+='## '+name+'\n\n```json\n'+p.read_text()+'\n```\n\n'
text+='pause-results.json 覆盖40个完整回调及命中计数；getter-results.json保留Rx读取回归。诊断测试使用受控媒体验证原MPV数值读取、失焦时同步、隐私字段不泄漏、设置页滚动和复制；不是禁区内容验收。\n';(O/'VALIDATION.md').write_text(text)
