package org.x2.titletests;
import org.x2.capturetests.CaptureNative;
import org.x2.export.PlayerCapture;
import org.x2.export.VideoFilename;
public class PageTitleTest {
 private static native void seedSlot(String path,String uri,String title,int slot);
 private static native void seed(String path,String uri,String title,int odd);
 static void equal(String want,String got){if(!want.equals(got))throw new AssertionError("expected "+want+" got "+got);}
 public static void main(String[] a)throws Exception{
  System.load(a[0]+"/libtitlefixture.so");System.load(a[0]+"/libcapturetest.so");CaptureNative.load(a[0]+"/libmpv.so");
  long player=CaptureNative.create(a[1],"X2TitleTest/1.0","",new String[0],"wrong-server-name",false);PlayerCapture.register(player);
  long end=System.currentTimeMillis()+20000;PlayerCapture.Source source=null;
  while(System.currentTimeMillis()<end){try{source=PlayerCapture.snapshot();break;}catch(Exception e){Thread.sleep(100);}}
  if(source==null)throw new AssertionError("no playback");
  seed(a[0]+"/libapp.so",a[1],"中文页面标题😀 第1集",0);equal("中文页面标题😀 第1集",PlayerCapture.snapshot().title);System.out.println("PASS actual title snapshot selected");
  seed(a[0]+"/libapp.so",a[1]+"?different-video", "下一部视频",0);equal("wrong-server-name",PlayerCapture.snapshot().title);System.out.println("PASS wrong URL rejected");
  seed(a[0]+"/libapp.so",a[1],"正在变更的标题",1);equal("wrong-server-name",PlayerCapture.snapshot().title);System.out.println("PASS incomplete snapshot rejected");
  equal("中文标题😀.mp4",VideoFilename.mp4("中文标题😀"));equal("甲_乙_丙.mp4",VideoFilename.mp4("甲/乙:丙"));equal("标题.mp4",VideoFilename.mp4("标题.mp4"));equal("当前播放视频.mp4",VideoFilename.mp4("... "));
  String many="";for(int i=0;i<100;i++)many+="😀";String name=VideoFilename.mp4(many);if(name.getBytes("UTF-8").length>204||name.indexOf('\ufffd')>=0)throw new AssertionError("unicode limit");
  seedSlot(a[0]+"/libapp.so",a[1],"当前短视频中文标题",0);
  seedSlot(a[0]+"/libapp.so",a[1]+"?preload-next","预加载下一部",1);
  equal("当前短视频中文标题",PlayerCapture.snapshot().title);System.out.println("PASS preload does not overwrite matching current short title");
  if(!CaptureNative.requestManager()||!PlayerCapture.manageRequested(true)||PlayerCapture.manageRequested(false))throw new AssertionError("manager event consumption");
  System.out.println("PASS native navigation event consumed once and local test flag toggles");
  System.out.println("PASS filename Unicode, reserved characters, extension, fallback and length");PlayerCapture.unregister(player);CaptureNative.terminate(player);System.out.println("TITLE_TEST_SUCCESS cases=10");
 }
}
