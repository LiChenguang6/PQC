#!/usr/bin/env python3
"""Rebuild an independent-package copy with the local-cache MP4 exporter.

Requires the original APK and the tools under ../patch-tools. The input APK
and all original libapp/libflutter/libmpv bytes are left untouched.
"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from inject_player_capture import inject as inject_player_capture

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
TOOLS = Path(os.environ.get("X2_PATCH_TOOLS", str(BASE / "patch-tools")))
INPUT = Path(os.environ.get("X2_INPUT_APK", str(BASE / "input/app.apk")))
MEDIA = Path(os.environ.get("X2_FFMPEG_ROOT", str(BASE / "minimal-ffmpeg")))
BUILD = HERE / "build"
OUTPUT = BASE / "output"
DECODED = BUILD / "decoded"
OLD = "com.example.yinqishe_app"
PACKAGE = "com.example.yinqishe_export"
A = "{http://schemas.android.com/apk/res/android}"

def run(args):
    print("+", " ".join(str(x) for x in args), flush=True)
    subprocess.run([str(x) for x in args], check=True)

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    if sha(INPUT) != "c3ec3365df8f01016b0c48db25fd7a1a21bf50bb31ce969d2edddcaf5ea2e385":
        raise RuntimeError("This patch is pinned to the analyzed APK SHA-256; do not apply it to another version")
    BUILD.mkdir(exist_ok=True)
    OUTPUT.mkdir(exist_ok=True)
    run(["java", "-jar", TOOLS / "apktool-cli.jar", "d", "--force", "-p", TOOLS / "framework",
         INPUT, "-o", DECODED])
    manifest = DECODED / "AndroidManifest.xml"
    ET.register_namespace("android", "http://schemas.android.com/apk/res/android")
    tree = ET.parse(manifest)
    root = tree.getroot()
    assert root.get("package") == OLD
    root.set("package", PACKAGE)
    root.set(A + "versionCode", "10")
    root.set(A + "versionName", "9.9.9-export2")
    app = root.find("application")
    app.set(A + "label", "X2社·保存导出版")
    for node in root.iter():
        # Keep the original component class names intact. Only package-scoped
        # provider authorities and custom permission names need new identities.
        if node.tag in ("permission", "uses-permission"):
            value = node.get(A + "name", "")
            if value.startswith(OLD + "."):
                node.set(A + "name", PACKAGE + value[len(OLD):])
        if node.tag == "provider":
            value = node.get(A + "authorities", "")
            if OLD in value:
                node.set(A + "authorities", value.replace(OLD, PACKAGE))
    ET.SubElement(app, "activity", {
        A + "name": "org.x2.export.CacheExportActivity",
        A + "exported": "false",
        A + "label": "缓存导出 MP4",
        A + "theme": "@android:style/Theme.Material.Light.NoActionBar",
        A + "configChanges": "orientation|screenSize|keyboardHidden",
    })
    ET.SubElement(app, "activity", {
        A + "name": "org.x2.export.PlayingExportActivity",
        A + "exported": "false",
        A + "label": "保存当前视频",
        A + "theme": "@android:style/Theme.Material.Light.NoActionBar",
        A + "configChanges": "orientation|screenSize|keyboardHidden",
    })
    tree.write(manifest, encoding="utf-8", xml_declaration=True)
    metadata = DECODED / "apktool.yml"
    meta = metadata.read_text()
    assert "  versionCode: 9\n  versionName: 9.9.9\n" in meta
    metadata.write_text(meta.replace("  versionCode: 9\n  versionName: 9.9.9\n",
                                    "  versionCode: 10\n  versionName: 9.9.9-export2\n"))

    # The obfuscated FlutterActivity has final lifecycle methods; inject one
    # call after its existing onCreate implementation instead of overriding it.
    smali = DECODED / "smali/c9/d.smali"
    text = smali.read_text()
    begin = text.index(".method public final onCreate(Landroid/os/Bundle;)V")
    end = text.index(".end method", begin)
    block = text[begin:end]
    assert block.count("return-void") == 1
    block = block.replace("    return-void", "    invoke-static {p0}, Lorg/x2/export/ExportEntry;->install(Landroid/app/Activity;)V\n\n    return-void")
    smali.write_text(text[:begin] + block + text[end:])
    # The original launcher loads its remote wrapper configuration before
    # opening Flutter. Keep the export page reachable if that network request
    # is unavailable, while retaining the wrapper's existing routing logic.
    wrapper = DECODED / "smali_classes2/com/tencent/a/SetupInfoActivity.smali"
    text = wrapper.read_text()
    begin = text.index(".method protected onCreate(Landroid/os/Bundle;)V")
    end = text.index(".end method", begin)
    block = text[begin:end]
    assert block.count("return-void") == 1
    block = block.replace("    return-void", "    invoke-static {p0}, Lorg/x2/export/ExportEntry;->install(Landroid/app/Activity;)V\n\n    return-void")
    wrapper.write_text(text[:begin] + block + text[end:])
    inject_player_capture(DECODED)

    classes = BUILD / "classes"
    dex = BUILD / "dex"
    shutil.rmtree(classes, ignore_errors=True)
    shutil.rmtree(dex, ignore_errors=True)
    classes.mkdir(); dex.mkdir()
    android = TOOLS / "android-35/android.jar"
    sources = sorted((HERE / "src").rglob("*.java"))
    run(["java", "-jar", TOOLS / "ecj.jar", "-source", "1.8", "-target", "1.8", "-encoding", "UTF-8",
         "-bootclasspath", android, "-d", classes, *sources])
    run([TOOLS / "android-15/d8", "--min-api", "24", "--lib", android, "--output", dex,
         *sorted(classes.rglob("*.class"))])

    ndk = TOOLS / "android-ndk-r28c/toolchains/llvm/prebuilt/linux-x86_64/bin"
    abis = {"arm64-v8a": "aarch64-linux-android24-clang",
            "armeabi-v7a": "armv7a-linux-androideabi24-clang",
            "x86_64": "x86_64-linux-android24-clang"}
    libs = {}
    playerlibs = {}
    for abi, compiler in abis.items():
        capabilities = (MEDIA / abi / "config_components.h").read_text()
        for capability in ("MP4_MUXER", "MOV_MUXER", "HLS_DEMUXER", "MPEGTS_DEMUXER",
                           "MOV_DEMUXER", "CRYPTO_PROTOCOL", "AAC_ADTSTOASC_BSF",
                           "H264_DECODER", "HEVC_DECODER", "AAC_DECODER"):
            if "#define CONFIG_" + capability + " 1" not in capabilities:
                raise RuntimeError(abi + " media build lacks required capability " + capability)
        library = BUILD / ("libx2export-" + abi + ".so")
        run([ndk / compiler, "-shared", "-fPIC", "-O2", "-Wall", "-Wextra",
             "-Werror=implicit-function-declaration", "-I" + str(HERE / "third_party/ffmpeg-6.0"),
             HERE / "native/export_bridge.c", "-fvisibility=hidden",
             "-Wl,--start-group", MEDIA / abi / "lib/libavformat.a",
             MEDIA / abi / "lib/libavcodec.a", MEDIA / abi / "lib/libavutil.a", "-Wl,--end-group",
             "-lm", "-llog", "-Wl,--exclude-libs,ALL", "-Wl,-Bsymbolic",
             "-Wl,-soname,libx2export.so", "-Wl,-z,max-page-size=16384", "-o", library])
        libs[abi] = library
        player_library = BUILD / ("libx2player-" + abi + ".so")
        run([ndk / compiler, "-shared", "-fPIC", "-O2", "-Wall", "-Wextra",
             "-Werror=implicit-function-declaration", "-fvisibility=hidden",
             HERE / "native/player_capture.c", "-ldl",
             "-Wl,-soname,libx2player.so", "-Wl,-z,max-page-size=16384", "-o", player_library])
        playerlibs[abi] = player_library
    rebuilt = BUILD / "rebuilt-unsigned.apk"
    run(["java", "-jar", TOOLS / "apktool-cli.jar", "b", "-p", TOOLS / "framework", DECODED, "-o", rebuilt])
    unsigned = BUILD / "export-unsigned.apk"
    with zipfile.ZipFile(rebuilt) as original, zipfile.ZipFile(unsigned, "w", compression=zipfile.ZIP_DEFLATED) as out:
        for entry in original.infolist():
            upper = entry.filename.upper()
            is_signature = upper.startswith("META-INF/") and (
                upper == "META-INF/MANIFEST.MF" or upper.endswith((".SF", ".RSA", ".DSA", ".EC")))
            if not is_signature:
                out.writestr(entry, original.read(entry))
        out.write(dex / "classes.dex", "classes3.dex")
        for abi, library in libs.items():
            out.write(library, "lib/" + abi + "/libx2export.so")
        for abi, library in playerlibs.items():
            out.write(library, "lib/" + abi + "/libx2player.so")
    aligned = BUILD / "export-aligned.apk"
    run([TOOLS / "android-15/zipalign", "-P", "16", "-f", "4", unsigned, aligned])
    key = BUILD / "local-export-key.p12"
    if not key.exists():
        run(["keytool", "-genkeypair", "-keystore", key, "-storepass", "android", "-keypass", "android",
             "-alias", "x2-export", "-keyalg", "RSA", "-keysize", "3072", "-validity", "10000",
             "-dname", "CN=X2 local cache export, OU=User build, O=Local"])
    final = OUTPUT / "X2-cache-export.apk"
    run([TOOLS / "android-15/apksigner", "sign", "--ks", key, "--ks-pass", "pass:android",
         "--key-pass", "pass:android", "--ks-key-alias", "x2-export", "--out", final, aligned])
    cert = subprocess.check_output([str(TOOLS / "android-15/apksigner"), "verify", "--verbose", "--print-certs", str(final)], text=True)
    (OUTPUT / "signature-verification.txt").write_text(cert)
    with zipfile.ZipFile(INPUT) as inp, zipfile.ZipFile(final) as out:
        preserve = [n for n in inp.namelist() if n.startswith("lib/") and n.endswith(".so")]
        for name in preserve:
            assert inp.read(name) == out.read(name), name
    info = {
        "input_sha256": sha(INPUT), "output_sha256": sha(final), "package": PACKAGE,
        "abis": list(abis), "original_native_libraries_byte_identical": len(preserve),
        "tools": {"apktool": "2.11.1", "android_platform": 35, "android_build_tools": "35.0.0",
                  "ndk": "28.2.13676358", "java_compiler": "ECJ 3.41.0", "ffmpeg": "n6.0 minimal local-only static build"},
        "source_sha256": {str(p.relative_to(HERE)): sha(p) for p in sources + [HERE / "native/export_bridge.c",
                         HERE / "native/player_capture.c", HERE / "inject_player_capture.py", Path(__file__)]},
        "media_source_archive_sha256": "9a1fa94608300e835bf89bdfcd7d77deceba67bff3494f609816f84bd69a459e",
        "media_config_sha256": {abi: sha(MEDIA / abi / "config_components.h") for abi in abis},
        "jni_library_sha256": {abi: sha(path) for abi, path in libs.items()},
        "player_capture_library_sha256": {abi: sha(path) for abi, path in playerlibs.items()},
        "signature": cert,
    }
    (OUTPUT / "build-info.json").write_text(json.dumps(info, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps({"apk": str(final), "sha256": info["output_sha256"]}, indent=2), flush=True)

if __name__ == "__main__":
    main()
