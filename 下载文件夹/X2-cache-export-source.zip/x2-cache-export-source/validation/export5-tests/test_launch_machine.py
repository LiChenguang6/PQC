from prepare_machine import prepare
prepare()
from pathlib import Path
import struct,json,sys
from unicorn import *
from unicorn.arm64_const import *
from unicorn.x86_const import *
B=Path('/workspace/x2-analysis');sys.path.insert(0,str(B/'export-patch'))
from patch_launch_title import SPECS
from patch_scroll import branch
R=B/'export5-tests';results=[]
for abi,s in SPECS.items():
 arm=abi=='arm64-v8a';d=(R/'asm'/f'{abi}-patched.so').read_bytes();old=(B/'extracted/lib'/abi/'libapp.so').read_bytes()
 lo=0x5b1ac8 if arm else 0x65f454;hi=s['ready'];assert d[lo:hi]==old[lo:hi],'network/login/init path changed'
 assert d[hi:hi+(4 if arm else 5)]==branch(abi,hi,s['home'],True)
 guardlo=0x5f94c4 if arm else 0x6a3718;guardhi=0x5f9598 if arm else 0x6a381c
 assert d[guardlo:guardhi]==old[guardlo:guardhi],'original skip initialization guards changed'
 for selected,want in [(1,1),(2,1),(3,2),(4,3),(5,4),(0,1)]:
  u=Uc(UC_ARCH_ARM64 if arm else UC_ARCH_X86,UC_MODE_ARM if arm else UC_MODE_64);u.mem_map(0,0x900000);u.mem_write(0,d);u.mem_map(0x1000000,0x40000);u.mem_map(0x2000000,0x10000)
  fp=0x2008000;sp=fp-0x100;null=0x2000081
  regs={UC_ARM64_REG_X29:fp,UC_ARM64_REG_X15:sp,UC_ARM64_REG_X27:0x1000000,UC_ARM64_REG_X22:null} if arm else {UC_X86_REG_RBP:fp,UC_X86_REG_RSP:sp,UC_X86_REG_R15:0x1000000,UC_X86_REG_R14:0x2001000}
  for r,v in regs.items():u.reg_write(r,v)
  count=[0];value=[]
  def hook(uc,at,size,unused):
   if at==(0x591fb4 if arm else 0x5fc944):
    value.append(uc.reg_read(UC_ARM64_REG_X2 if arm else UC_X86_REG_RSI)//2);uc.emu_stop()
   if at!=(0x820184 if arm else 0x8a5c54):return
   count[0]+=1;v=null+(0x20 if count[0]==selected else 0x30)
   if arm:uc.reg_write(UC_ARM64_REG_X0,v);uc.reg_write(UC_ARM64_REG_PC,uc.reg_read(UC_ARM64_REG_X30))
   else:
    rsp=uc.reg_read(UC_X86_REG_RSP);ret=struct.unpack('<Q',uc.mem_read(rsp,8))[0];uc.reg_write(UC_X86_REG_RSP,rsp+8);uc.reg_write(UC_X86_REG_RAX,v);uc.reg_write(UC_X86_REG_RIP,ret)
  u.hook_add(UC_HOOK_CODE,hook);u.emu_start(0x707bac if arm else 0x5fc57b,0x300000,count=200);assert value==[want],(abi,selected,value,want)
  results.append(dict(abi=abi,route_match=selected,selected_tab=want))
(R/'launch-machine-results.json').write_text(json.dumps(dict(default_tab_paths=results,required_network_login_ads_fetch_and_network_initialization_bytes_preserved=True,completion_calls_original_skip_action_without_countdown=True,original_skip_readiness_checks_preserved=True),indent=2));print('PASS 12 tab paths; original awaited launch prerequisites preserved')
