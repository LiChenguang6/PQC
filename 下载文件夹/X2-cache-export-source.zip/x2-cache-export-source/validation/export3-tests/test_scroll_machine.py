from pathlib import Path
import sys,json,struct
sys.path.insert(0,'/workspace/x2-analysis/export-patch')
from patch_scroll import apply,SPECS,branch
from unicorn import *
from unicorn.arm64_const import *
from unicorn.x86_const import *
B=Path('/workspace/x2-analysis');results={}
for abi in SPECS:
 data=(B/'extracted/lib'/abi/'libapp.so').read_bytes();patched,r=apply(data,abi,B/'patch-tools/android-ndk-r28c/toolchains/llvm/prebuilt/linux-x86_64/bin',B/'export-patch/build/scroll');s=SPECS[abi]
 arm=abi=='arm64-v8a';u=Uc(UC_ARCH_ARM64 if arm else UC_ARCH_X86,UC_MODE_ARM if arm else UC_MODE_64)
 u.mem_map(0x300000,0x600000);u.mem_write(0x300000,patched[0x300000:0x900000]);u.mem_map(0x1000000,0x40000);u.mem_map(0x2000000,0x4000)
 obj=0x2000001;fp=0x2002000;pool=0x1000000;thr=0x2003000;null=0x44440001
 constants=[0x11001101,0x22002201,0x33003301,0x44004401,0x55005501];offsets=[0xa2c0,0xc5c8,0x3840,0x13998,0x17f68] if arm else [0xa357,0xc72f,0x3877,0x13ae7,0x180d7]
 for off,v in zip(offsets,constants):u.mem_write(pool+off,struct.pack('<Q',v))
 u.mem_write(fp-0x28,struct.pack('<Q',0x66006601));u.mem_write(fp-8,struct.pack('<Q',0x77007701));u.mem_write(thr+0x88,struct.pack('<Q',null+0x30))
 regs={UC_ARM64_REG_X0:obj,UC_ARM64_REG_X27:pool,UC_ARM64_REG_X22:null,UC_ARM64_REG_X29:fp,UC_ARM64_REG_SP:fp-0x40} if arm else {UC_X86_REG_RAX:obj,UC_X86_REG_R15:pool,UC_X86_REG_R14:thr,UC_X86_REG_RBP:fp,UC_X86_REG_RSP:fp-0x40}
 for reg,v in regs.items():u.reg_write(reg,v)
 u.emu_start(s['ret'],s['end'],count=60)
 expected={0xb:constants[0],0xf:null+0x30,0x13:0x66006601,0x23:0x77007701,0x27:constants[1],0x2b:constants[2],0x2f:constants[3],0x37:constants[4]}
 for off,v in expected.items():assert struct.unpack('<I',u.mem_read(obj+off,4))[0]==v,(abi,off)
 for reg,v in regs.items():assert u.reg_read(reg)==v,(abi,reg)
 assert patched[s['call']:s['call']+len(branch(abi,s['call'],s['alloc'],True))]==branch(abi,s['call'],s['alloc'],True)
 results[abi]={'initializer_executed':True,'all_8_fields_correct':True,'pinned_registers_and_stack_unchanged':True,'allocation_call_return_PC_unchanged':True,'no_call_in_initializer':True,**r}
(B/'export3-tests/scroll-machine-results.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
