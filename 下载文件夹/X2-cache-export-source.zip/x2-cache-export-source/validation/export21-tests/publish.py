from pathlib import Path
import hashlib,json,zipfile,subprocess,shutil,urllib.request,urllib.parse
B=Path('/workspace/x2-analysis');P=B/'export-patch';R=B/'export21-tests';O=B/'output';G=Path('/workspace/pqc-upload');F='下载文件夹'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(*a):return subprocess.check_output(a,text=True).strip()
h=sha(O/'X2-cache-export.apk');ui=json.loads((R/'ui-results.json').read_text());assert ui['apk_sha256']==h and all(ui[k]['passed'] for k in ['controls21','controls21Reload'])
for n in ['payload-results.json','ad-route-results.json','permission-results.json']:
 d=json.loads((R/n).read_text());assert d['passed'] and d['apk_sha256']==h
assert len(json.loads((R/'pause-results.json').read_text())['cases'])==96
assert json.loads((R/'getter-results.json').read_text())['passed']
usage='# X2 export21：播放器本地许可状态实验\n\n本版以 export20 和用户确认能播放的原版回归逻辑为基础。比较发现：“视频”和“禁区”共用按视频 ID 获取详情的接口、播放地址字段和播放器。禁区多一个本地会员入口检查；能否正常播放还受详情中的 canWatch 和返回视频源影响，不存在可直接复制的另一套免费 VIP 账号权限。\n\n## 使用\n\n直接覆盖安装，然后进入 管理 → 下载设置：\n\n1. 开启“开发测试：禁区入口（仅本地）”。\n2. 开启新增的“开发测试：播放器许可状态（实验）”。\n3. 退出当前视频并重新打开禁区视频。开启或关闭许可实验均需重新打开视频，才会重新传递许可状态。\n\n新开关默认关闭，开关保存后重启保留。若出现异常，关闭“播放器许可状态（实验）”并重新进入视频，即恢复 export20 的原版可播放状态传递。\n\n## 实现与范围\n\n许可实验在详情数据传给播放器的位置，只把两个本地状态（VideoPlayByVideoIdController.field_5f 和 PlayerController.field_47）设为正常可播放的布尔值。关闭时按原样读取详情值，已是可播放的免费视频开启后仍传递同样值。\n\n保留初始化、全部进度回调、播放进度记录、广告开关、源去重及文件管理。不同于旧版直接跳过试看回调，不改详情解析结果、不改账号、令牌、服务器请求或播放地址；原模型 canWatch 仍保留服务器值。\n\n这是用于“服务器已提供完整源、但客户端本地许可限制”情况的实验。服务器仅提供十几秒清单、缺少后续分片或拒绝访问时，本地状态修改不能提供完整内容。尚未验证真实禁区完整播放，不代表已开通账号 VIP。\n\nAPK SHA-256：`'+h+'`\n'
(O/'使用说明.md').write_text(usage)
(O/'VALIDATION.md').write_text('# export21 验证\n\n交付 APK SHA-256：`'+h+'`\n\n- 96 组两架构实际交付指令测试：不同压缩堆基址、原详情为 true/false/null、许可/广告/入口开关组合。关闭许可实验保持原值，开启仅改变两个播放器状态，原始详情模型不变。\n- 原进度和暂停函数逐字节保持 export20；另 96 组回调测试、20 组会员入口 getter 测试和 8 组独立广告路径测试通过。\n- 云端 API29 x86_64 安装交付 APK 并核对 SHA；设置界面验证许可实验默认关闭、真实 JNI 标记与另两个设置独立。结束进程重新打开后设置及 JNI 初始化保持，关闭实验能清除标记。\n- 下载、队列、源去重、预览 Java 代码与 export20 一致；原 libflutter/libmpv 未变，测试辅助库不包含在用户 APK。\n\n以上是指令与模拟器验证；未取得真实平台新响应，未验证禁区完整播放。短源不会因本地许可标记变成长源。\n')
f=P/'README.md';t=f.read_text().replace('源码（export20）','源码（export21）',1).replace('版本码 28','版本码 29',1);i=t.index('## export20');t=t[:i]+'## export21：许可状态传递实验\n\n新增独立 0x4938 标记和只写该标记的 JNI 接口；在 updateVideoDetail 传递 canWatch 的读取点，用无调用跳板按默认原样或显式实验可播放状态赋给 controller.field_5f / player.field_47。原 JSON 模型、URL、账号、请求和原进度/暂停函数不修改。默认关闭；设置持久化并在诊断初始化恢复标记。只适用于源本身完整时的本地许可实验，未验证禁区完整播放，不代表服务器 VIP 权限。验证见 validation/export21-tests。\n\n'+t[i:];f.write_text(t)
subprocess.run(['python3',str(P/'package_source.py')],check=True)
with zipfile.ZipFile(O/'X2-cache-export-source.zip') as z:assert z.testzip() is None and not any(n.endswith(('.apk','.p12')) for n in z.namelist());assert z.read('x2-cache-export-source/export-patch/restore_original_playback.py')==(P/'restore_original_playback.py').read_bytes()
assert not run('git','-C',str(G),'status','--porcelain')
subprocess.run(['git','-C',str(G),'fetch','origin','main'],check=True);subprocess.run(['git','-C',str(G),'merge','--ff-only','origin/main'],check=True)
names=['X2-cache-export.apk','X2-cache-export-source.zip','使用说明.md','VALIDATION.md']
for n in names:shutil.copy2(O/n,G/F/n)
subprocess.run(['git','-C',str(G),'add','--',*[F+'/'+n for n in names]],check=True)
assert set(run('git','-C',str(G),'-c','core.quotepath=false','diff','--cached','--name-only').splitlines())=={F+'/'+n for n in names}
subprocess.run(['git','-C',str(G),'commit','-m','X2 export21: optional local permit-state experiment with original player callbacks preserved'],check=True);subprocess.run(['git','-C',str(G),'push','origin','HEAD:main'],check=True)
c=run('git','-C',str(G),'rev-parse','HEAD');url='https://raw.githubusercontent.com/LiChenguang6/PQC/'+c+'/'+urllib.parse.quote(F+'/X2-cache-export.apk')
with urllib.request.urlopen(url,timeout=60) as response:assert hashlib.sha256(response.read()).hexdigest()==h
result={'commit':c,'url':url,'sha256':h,'real_forbidden_full_playback_verified':False};(R/'published-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False))
