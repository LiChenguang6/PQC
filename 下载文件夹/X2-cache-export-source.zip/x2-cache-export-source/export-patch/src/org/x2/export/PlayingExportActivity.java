package org.x2.export;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.UUID;

/** Saves the playback source captured before leaving the original player. */
public final class PlayingExportActivity extends Activity {
    private static PlayerCapture.Source pending;
    private PlayerCapture.Source source;
    private final Handler main = new Handler(Looper.getMainLooper());
    private TextView status;
    private ProgressBar progress;
    private Button save;
    private volatile boolean busy, cancelled;
    private static final int SAVE = 1202;

    public static void open(Activity activity, PlayerCapture.Source captured) {
        synchronized (PlayingExportActivity.class) { pending = captured; }
        activity.startActivity(new Intent(activity, PlayingExportActivity.class));
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        synchronized (PlayingExportActivity.class) { source = pending; pending = null; }
        setTitle("保存当前视频");
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = (int)(16 * getResources().getDisplayMetrics().density);
        root.setPadding(pad, pad, pad, pad);
        TextView intro = new TextView(this);
        intro.setText(source == null ? "请返回播放页面，开始播放后重新选择“保存当前视频”。"
                : "已选中点击保存入口时正在播放的视频。\n" + displayTitle(source.title)
                  + "\n\n选择保存位置后开始下载，完成后合并为 MP4。请保持本页打开，并预留下载和合并所需空间。");
        root.addView(intro);
        save = new Button(this); save.setText("选择位置并下载 MP4"); root.addView(save);
        save.setEnabled(source != null);
        save.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) { choose(); }
        });
        status = new TextView(this); root.addView(status);
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100); root.addView(progress);
        setContentView(root);
    }

    private static String displayTitle(String title) {
        // A player may derive a title from a signed URL. Never display that URL.
        if (title == null || title.contains("://") || title.contains("?") || title.contains("="))
            return "当前播放视频";
        title = title.replaceAll("[\\p{Cntrl}]", " ").trim();
        if (title.length() == 0) return "当前播放视频";
        return title.length() > 100 ? title.substring(0, 100) : title;
    }

    private void choose() {
        if (busy || source == null) return;
        Intent pick = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.setType("video/mp4");
        pick.putExtra(Intent.EXTRA_TITLE, "X2_video_" + System.currentTimeMillis() + ".mp4");
        try { startActivityForResult(pick, SAVE); }
        catch (Exception e) { showError("无法打开系统文件保存窗口。"); }
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == SAVE && result == RESULT_OK && data != null && data.getData() != null) {
            if (source == null) {
                try { android.provider.DocumentsContract.deleteDocument(getContentResolver(), data.getData()); }
                catch (Exception ignored) { }
                showError("播放信息已失效，未开始下载。请返回播放页面重新选择视频。");
            } else download(data.getData());
        }
    }

    private void download(final Uri destination) {
        busy = true; cancelled = false; save.setEnabled(false);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        status.setText("正在读取播放源…"); progress.setProgress(0);
        new Thread(new Runnable() {
            @Override public void run() {
                final File work = new File(getCacheDir(), "playback-saves/" + UUID.randomUUID().toString());
                final File output = new File(work, "output.mp4");
                try {
                    if (!work.mkdirs()) throw new IOException("无法创建下载目录，请检查可用空间。");
                    MediaDownloader.Result result = MediaDownloader.download(source.uri, source.userAgent,
                            source.referrer, source.headers, work, new MediaDownloader.Progress() {
                        @Override public boolean cancelled() { return cancelled; }
                        @Override public void update(final String stage, final double fraction) {
                            main.post(new Runnable() { @Override public void run() {
                                status.setText(stage);
                                progress.setProgress((int)(Math.max(0, Math.min(1, fraction)) * 80));
                            }});
                        }
                    });
                    if (cancelled) throw new IOException("已取消");
                    setStatus("下载完成，正在合并和验证 MP4…");
                    String error = NativeRemux.run(result.input.getAbsolutePath(), output.getAbsolutePath(),
                            result.durationSeconds, new NativeRemux.Progress() {
                        @Override public boolean cancelled() { return cancelled; }
                        @Override public void update(final double value) {
                            main.post(new Runnable() { @Override public void run() {
                                progress.setProgress(80 + (int)(Math.max(0, Math.min(1, value)) * 15));
                            }});
                        }
                    });
                    if (!error.isEmpty()) throw new IOException("合并或验证失败：" + error);
                    if (cancelled) throw new IOException("已取消");
                    if (output.length() < 64) throw new IOException("合并后的 MP4 无有效内容。");
                    setStatus("MP4 已验证，正在保存…");
                    try (FileInputStream input = new FileInputStream(output);
                         OutputStream target = getContentResolver().openOutputStream(destination, "wt")) {
                        if (target == null) throw new IOException("无法写入所选位置。");
                        byte[] buffer = new byte[1024 * 1024]; int count;
                        while ((count = input.read(buffer)) != -1) {
                            if (cancelled) throw new IOException("已取消");
                            target.write(buffer, 0, count);
                        }
                        target.flush();
                    }
                    main.post(new Runnable() { @Override public void run() {
                        progress.setProgress(100); status.setText("已保存 MP4。可在所选目录中播放或分享。");
                    }});
                } catch (final Exception | LinkageError error) {
                    try { android.provider.DocumentsContract.deleteDocument(getContentResolver(), destination); }
                    catch (Exception ignored) { }
                    final String detail = safeMessage(error);
                    main.post(new Runnable() { @Override public void run() { showError(detail); }});
                } finally {
                    deleteWork(work);
                    main.post(new Runnable() { @Override public void run() {
                        busy = false; save.setEnabled(source != null);
                        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    }});
                }
            }
        }, "X2-playback-save").start();
    }

    private static String safeMessage(Throwable error) {
        if (error instanceof LinkageError) return "当前设备无法启动视频保存功能（"
                + error.getClass().getSimpleName() + "）。";
        String message = error.getMessage();
        if (message == null || message.contains("://")) return "保存失败（" + error.getClass().getSimpleName()
                + "）。请重试；如果播放地址已过期，请返回重新播放后再保存。";
        return message;
    }

    private void setStatus(final String text) {
        main.post(new Runnable() { @Override public void run() { status.setText(text); }});
    }

    private void showError(String message) {
        status.setText(message);
        if (!isFinishing()) new AlertDialog.Builder(this).setTitle("未能保存视频")
                .setMessage(message).setPositiveButton("知道了", null).show();
    }

    private static void deleteWork(File file) {
        File[] children = file.listFiles();
        if (children != null) for (File child : children) deleteWork(child);
        file.delete();
    }

    @Override public void onBackPressed() {
        if (!busy) { super.onBackPressed(); return; }
        new AlertDialog.Builder(this).setTitle("正在保存")
                .setMessage("是否取消本次下载和保存？")
                .setPositiveButton("继续保存", null)
                .setNegativeButton("取消保存", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int which) {
                        cancelled = true; status.setText("正在取消…");
                    }
                }).show();
    }

    @Override protected void onDestroy() {
        cancelled = true;
        super.onDestroy();
    }
}
