from pathlib import Path
import subprocess,time,json
B=Path('/workspace/x2-analysis');R=B/'export9-tests';A=str(B/'android-sdk/platform-tools/adb');P='com.example.yinqishe_export'
for n in range(60):
 p=subprocess.run([A,'shell','getprop','sys.boot_completed'],capture_output=True,text=True,timeout=15)
 if p.stdout.strip()=='1':break
 time.sleep(10)
else:raise RuntimeError('emulator boot not ready')
subprocess.run([A,'root'],check=True)
subprocess.run([A,'wait-for-device'],check=True,timeout=30)
subprocess.run(['python3',str(R/'install_startup.py')],check=True,timeout=300)
subprocess.run([A,'shell','am','force-stop',P],check=True)
log=subprocess.check_output([A,'shell','am','instrument','-w','-e','mode','entry8','-e','activity','com.example.yinqishe_app.MainActivity','org.x2.uitests/org.x2.uitests.DownloadInstrumentation'],text=True,timeout=180)
(R/'entry-runtime.log').write_text(log);print(log,flush=True);assert 'PRODUCTION_TWO_BUTTON_MANAGER_AND_SETTINGS_PASS' in log
(R/'entry-results.json').write_text(json.dumps(dict(passed=True,production_manager_and_settings_open=True,apk_sha256=json.loads((B/'output/build-info.json').read_text())['output_sha256']),indent=2))
