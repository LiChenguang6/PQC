from pathlib import Path
import subprocess,json,hashlib,http.server,threading,re,sys
B=Path('/workspace/x2-analysis');R=B/'export12-tests';A=str(B/'android-sdk/platform-tools/adb');P='com.example.yinqishe_export';apk=B/'output/X2-cache-export.apk'
def run(*args,timeout=60):return subprocess.check_output([A,*args],timeout=timeout,text=True)
reuse='--reuse' in sys.argv
if not reuse:
 print(run('push',str(apk),'/data/local/tmp/X2-export12.apk'),flush=True)
 try:print(run('shell','pm','install','-r','/data/local/tmp/X2-export12.apk',timeout=180),flush=True)
 except subprocess.TimeoutExpired:print('Checking installed payload after install response timeout',flush=True)
p=run('shell','pm','path',P).strip().split('package:')[1];sha=run('exec-out','sha256sum',p).split()[0];assert sha==hashlib.sha256(apk.read_bytes()).hexdigest();(R/'installed-results.json').write_text(json.dumps(dict(installed_sha256=sha,matches_delivery=True),indent=2))
if not reuse:subprocess.run(['python3',str(B/'ui-download-tests/build_test_apk.py')],check=True,stdout=(R/'test-build.log').open('w'),stderr=subprocess.STDOUT,timeout=180)
class Handler(http.server.BaseHTTPRequestHandler):
 def do_GET(self):
  data=(B/'capture-tests/fixture/capture-fixture.mp4').read_bytes();self.send_response(200);self.send_header('Content-Length',str(len(data)));self.end_headers()
  try:self.wfile.write(data)
  except OSError:pass
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',18781),Handler);server.daemon_threads=True;threading.Thread(target=server.serve_forever,daemon=True).start()
try:
 run('reverse','tcp:18781','tcp:18781')
 modes=[('delete12','RECORD_ONLY_KEEP_BATCH_FILE_DELETE_FAILURE_RETENTION_AND_UI_OPTIONS_PASS',[]),('appearance12','APPEARANCE_IMPORT_VALIDATION_ENTRY_COVER_RESET_AND_SHORTCUT_PASS',[]),('diagnostic11','DIAGNOSTIC_SYNC_WITHOUT_MAIN_FOCUS_MPV_METRICS_PRIVACY_AND_CLIPBOARD_PASS',['-e','fixture','http://127.0.0.1:18781/media.mp4?DO_NOT_REPORT_URI','-e','activity','com.example.yinqishe_app.MainActivity'])]
 results={}
 for mode,expected,extra in modes:
  run('shell','am','force-stop',P)
  log=run('shell','am','instrument','-w','-e','mode',mode,*extra,'org.x2.uitests/org.x2.uitests.DownloadInstrumentation',timeout=240)
  (R/(mode+'-runtime.log')).write_text(log);print(log,flush=True);assert expected in log,mode
  results[mode]=dict(passed=True,properties=dict(re.findall(r'INSTRUMENTATION_RESULT: (launcher_pin_supported|launcher_pinned_and_updated|numeric_state)=(.*)',log)))
  results['apk_sha256']=sha;results['real_forbidden_video_over_20_seconds_verified']=False;(R/'ui-results.json').write_text(json.dumps(results,indent=2))
finally:server.shutdown();server.server_close();run('reverse','--remove','tcp:18781')
