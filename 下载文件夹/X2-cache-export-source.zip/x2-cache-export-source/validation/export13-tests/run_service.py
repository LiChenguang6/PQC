from pathlib import Path
import subprocess,time,threading,http.server,json
B=Path('/workspace/x2-analysis');R=B/'export13-tests';A=str(B/'android-sdk/platform-tools/adb');P='com.example.yinqishe_export'
class Handler(http.server.BaseHTTPRequestHandler):
 def do_GET(self):
  data=(B/'capture-tests/fixture/capture-fixture.mp4').read_bytes();self.send_response(200);self.send_header('Content-Length',str(len(data)));self.end_headers()
  try:
   for i in range(0,len(data),128):self.wfile.write(data[i:i+128]);self.wfile.flush();time.sleep(.1)
  except (BrokenPipeError,ConnectionResetError,OSError):pass
 def log_message(self,*a):pass
(R/'service-results.json').unlink(missing_ok=True)
server=http.server.ThreadingHTTPServer(('127.0.0.1',18770),Handler);server.daemon_threads=True;threading.Thread(target=server.serve_forever,daemon=True).start()
try:
 subprocess.run([A,'shell','am','force-stop',P],check=True,timeout=15)
 p=subprocess.Popen([A,'shell','am','instrument','-w','-e','mode','service6','org.x2.uitests/org.x2.uitests.DownloadInstrumentation'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 log,_=p.communicate(timeout=140);(R/'service-runtime.log').write_text(log);print(log);assert p.returncode==0 and 'PAUSE_RESUME_CANCEL_REMOVE_PROCESS_SURVIVED' in log
 for mode,expected in [('pauseSeed6','PAUSED_RECORD_SAVED'),('pauseVerify6','PAUSED_RECORD_RESTORED_AND_RESUMED')]:
  check=subprocess.run([A,'shell','am','instrument','-w','-e','mode',mode,'org.x2.uitests/org.x2.uitests.DownloadInstrumentation'],capture_output=True,text=True,timeout=80)
  (R/(mode+'.log')).write_text(check.stdout+check.stderr);print(check.stdout,flush=True);assert check.returncode==0 and expected in check.stdout
 result=dict(passed=True,paused_progress_stable=True,paused_state_persists_across_process_restart=True,paused_task_frees_parallel_slot=True,resume_waits_for_parallel_slot=True,cancel_other_task_resumes_waiting_task=True,delete_while_paused_completes=True,rapid_idle_cancel_commands=25,process_survived_more_than_foreground_deadline=True,apk_sha256=json.loads((B/'output/build-info.json').read_text())['output_sha256'])
 (R/'service-results.json').write_text(json.dumps(result,indent=2))
finally:server.shutdown();server.server_close()
