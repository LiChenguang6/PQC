from pathlib import Path
import subprocess,json,time,http.server,threading,hashlib,shlex
B=Path('/workspace/x2-analysis');R=B/'export5-tests';A=str(B/'android-sdk/platform-tools/adb');P='com.example.yinqishe_export';folder='/sdcard/Download/X2_export3_B'
def adb(*args,timeout=60):return subprocess.check_output([A,*args],timeout=timeout)
def files():return set(adb('exec-out','find',folder,'-type','f').decode().splitlines())
class Handler(http.server.BaseHTTPRequestHandler):
 def do_GET(self):
  body=(B/'capture-tests/fixture/capture-fixture.mp4').read_bytes();time.sleep(5);self.send_response(200);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
 def log_message(self,*a):pass
server=http.server.ThreadingHTTPServer(('0.0.0.0',18769),Handler);threading.Thread(target=server.serve_forever,daemon=True).start()
try:
 before=files();adb('shell','am','force-stop',P)
 command=['am','instrument','-w','-e','mode','seed','-e','jobs','Title1,Title2','-e','title','中文命名测试😀/第一集','-e','server','http://10.0.2.2:18769','org.x2.uitests/org.x2.uitests.DownloadInstrumentation']
 seed=adb('shell',' '.join(shlex.quote(x) for x in command)).decode();(R/'filename-seed.log').write_text(seed);assert 'SEEDED_ENCRYPTED_QUEUE' in seed
 adb('shell','am','start','-n',P+'/org.x2.export.DownloadTasksActivity');time.sleep(2);adb('shell','input','keyevent','3')
 end=time.monotonic()+80;new=set()
 while time.monotonic()<end:
  new=files()-before
  if len(new)==2:
   time.sleep(3)
   try:
    for i,path in enumerate(sorted(new)):
     local=R/f'title-download-{i}.mp4';adb('pull',path,str(local));subprocess.run(['ffmpeg','-v','error','-i',str(local),'-f','null','-'],check=True,capture_output=True)
    break
   except subprocess.CalledProcessError:pass
  time.sleep(2)
 else:raise AssertionError('two completed MP4 outputs missing: '+str(new))
 assert all(Path(p).name.startswith('中文命名测试😀_第一集') and p.endswith('.mp4') for p in new),new
 assert len(new)==2
 r=dict(passed=True,two_same_title_jobs_saved_separately=True,both_MP4_decode=True,continued_after_HOME=True,output_names=[Path(p).name for p in sorted(new)],output_sha256=json.loads((B/'output/build-info.json').read_text())['output_sha256'])
 (R/'filename-download-results.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print(json.dumps(r,ensure_ascii=False,indent=2))
finally:server.shutdown();server.server_close()
