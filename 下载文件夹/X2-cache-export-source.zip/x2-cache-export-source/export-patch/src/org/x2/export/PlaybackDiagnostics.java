package org.x2.export;

import android.content.Context;
import android.os.Build;
import android.os.SystemClock;
import java.util.ArrayDeque;
import java.util.concurrent.atomic.AtomicBoolean;

/** Bounded numeric-only history; no media paths, titles, account IDs or credentials. */
final class PlaybackDiagnostics {
    private static final AtomicBoolean started=new AtomicBoolean();
    private static final ArrayDeque<String> history=new ArrayDeque<String>();
    static final class SourceSample {final PlayerCapture.Source source;final long at;SourceSample(PlayerCapture.Source source){this.source=source;this.at=SystemClock.elapsedRealtime();}}
    private static volatile SourceSample lastSource;
    static void rememberSource(){try{lastSource=new SourceSample(PlayerCapture.snapshot());}catch(Exception ignored){SourceSample value=lastSource;if(value!=null&&SystemClock.elapsedRealtime()-value.at>30000)lastSource=null;}}
    static SourceSample recentSource(){SourceSample value=lastSource;return value!=null&&SystemClock.elapsedRealtime()-value.at<=30000?value:null;}
    static void start(Context context){if(!started.compareAndSet(false,true))return;final Context app=context.getApplicationContext();
        Thread thread=new Thread(()->{while(true){try{
            boolean enabled=app.getSharedPreferences("x2-development",0).getBoolean("forbidden-entry",false);
            String bridge=PlayerCapture.testState(enabled);
            if(enabled){rememberSource();String line="t="+(SystemClock.elapsedRealtime()/1000)+" "+bridge+" "+PlayerCapture.playbackState();synchronized(history){history.addLast(line);while(history.size()>45)history.removeFirst();}}
            if(!enabled)lastSource=null;Thread.sleep(1000);
        }catch(InterruptedException e){Thread.currentThread().interrupt();return;}catch(Throwable ignored){try{Thread.sleep(1000);}catch(InterruptedException e){return;}}}},"X2-playback-diagnostic");thread.setDaemon(true);thread.start();
    }
    static String report(Context c){start(c);String version="unknown";try{version=c.getPackageManager().getPackageInfo(c.getPackageName(),0).versionName;}catch(Exception ignored){}
        boolean enabled=c.getSharedPreferences("x2-development",0).getBoolean("forbidden-entry",false);
        StringBuilder text=new StringBuilder("version=").append(version).append("\nprocess=").append(android.os.Process.is64Bit()?"64-bit":"32-bit").append(" abis=").append(java.util.Arrays.toString(Build.SUPPORTED_ABIS)).append("\nAndroid=").append(Build.VERSION.RELEASE).append(" SDK=").append(Build.VERSION.SDK_INT).append("\nconfigured=").append(enabled).append(" ").append(PlayerCapture.testState(enabled)).append("\n");
        synchronized(history){if(history.isEmpty())text.append("尚无记录；开启开发测试后返回播放页观察 25 秒，再打开此页。\n");for(String line:history)text.append(line).append('\n');}
        text.append("记录只含本地状态；不表示真实视频已通过 20 秒验证。");return text.toString();
    }
    private PlaybackDiagnostics(){}
}
