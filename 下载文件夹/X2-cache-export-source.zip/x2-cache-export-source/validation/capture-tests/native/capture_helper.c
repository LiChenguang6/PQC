#include <jni.h>
#include <dlfcn.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mpv-client.h"

static void *library;
static mpv_handle *(*p_create)(void);
static int (*p_initialize)(mpv_handle *);
static int (*p_set_option_string)(mpv_handle *, const char *, const char *);
static int (*p_set_option)(mpv_handle *, const char *, mpv_format, void *);
static int (*p_set_property)(mpv_handle *, const char *, mpv_format, void *);
static char *(*p_get_property_string)(mpv_handle *, const char *);
static int (*p_command)(mpv_handle *, const char **);
static void (*p_terminate_destroy)(mpv_handle *);
static void (*p_free)(void *);
static const char *(*p_error_string)(int);

static void fail(JNIEnv *env, const char *message) {
    jclass cls = (*env)->FindClass(env, "java/lang/IllegalStateException");
    if (cls) (*env)->ThrowNew(env, cls, message);
}

static int checked(JNIEnv *env, int code, const char *operation) {
    if (code >= 0) return 1;
    char message[512];
    snprintf(message, sizeof(message), "%s failed: %s (%d)", operation, p_error_string(code), code);
    fail(env, message);
    return 0;
}

#define RESOLVE(name) do { \
    *(void **)(&p_##name) = dlsym(library, "mpv_" #name); \
    if (!p_##name) { fail(env, "missing mpv_" #name); return; } \
} while (0)

JNIEXPORT void JNICALL Java_org_x2_capturetests_CaptureNative_load(JNIEnv *env, jclass cls,
        jstring path) {
    (void)cls;
    const char *name = (*env)->GetStringUTFChars(env, path, NULL);
    if (!name) return;
    library = dlopen(name, RTLD_NOW | RTLD_GLOBAL);
    (*env)->ReleaseStringUTFChars(env, path, name);
    if (!library) { fail(env, dlerror()); return; }
    RESOLVE(create);
    RESOLVE(initialize);
    RESOLVE(set_option_string);
    RESOLVE(set_option);
    RESOLVE(set_property);
    RESOLVE(get_property_string);
    RESOLVE(command);
    RESOLVE(terminate_destroy);
    RESOLVE(free);
    RESOLVE(error_string);
}

static int option(JNIEnv *env, mpv_handle *handle, const char *name, const char *value) {
    return checked(env, p_set_option_string(handle, name, value), name);
}

static int joption(JNIEnv *env, mpv_handle *handle, const char *name, jstring value) {
    if (!value) return 1;
    /* String.getBytes uses real UTF-8, unlike JNI's modified UTF-8 for emoji. */
    jclass type = (*env)->FindClass(env, "java/lang/String");
    if (!type) return 0;
    jmethodID get_bytes = (*env)->GetMethodID(env, type, "getBytes", "(Ljava/lang/String;)[B");
    jstring encoding = (*env)->NewStringUTF(env, "UTF-8");
    if (!get_bytes || !encoding) return 0;
    jbyteArray bytes = (jbyteArray)(*env)->CallObjectMethod(env, value, get_bytes, encoding);
    (*env)->DeleteLocalRef(env, encoding);
    (*env)->DeleteLocalRef(env, type);
    if (!bytes || (*env)->ExceptionCheck(env)) return 0;
    jsize size = (*env)->GetArrayLength(env, bytes);
    char *text = malloc((size_t)size + 1);
    if (!text) { (*env)->DeleteLocalRef(env, bytes); fail(env, "out of memory for UTF-8 option"); return 0; }
    (*env)->GetByteArrayRegion(env, bytes, 0, size, (jbyte *)text);
    (*env)->DeleteLocalRef(env, bytes);
    text[size] = 0;
    int success = option(env, handle, name, text);
    free(text);
    return success;
}

JNIEXPORT jlong JNICALL Java_org_x2_capturetests_CaptureNative_create(JNIEnv *env, jclass cls,
        jstring uri, jstring user_agent, jstring referrer, jobjectArray headers,
        jstring title, jboolean paused) {
    (void)cls;
    if (!p_create) { fail(env, "mpv library not loaded"); return 0; }
    mpv_handle *handle = p_create();
    if (!handle) { fail(env, "mpv_create returned null"); return 0; }
    const char *options[][2] = {
        {"config", "no"}, {"vo", "null"}, {"ao", "null"}, {"hwdec", "no"},
        {"terminal", "no"}, {"load-scripts", "no"}, {"idle", "yes"},
        {"keep-open", "yes"}, {"loop-file", "inf"}, {"network-timeout", "8"},
        {"pause", paused ? "yes" : "no"}
    };
    for (size_t i = 0; i < sizeof(options) / sizeof(options[0]); i++) {
        if (!option(env, handle, options[i][0], options[i][1])) goto failed;
    }
    if (!joption(env, handle, "user-agent", user_agent) ||
        !joption(env, handle, "referrer", referrer) ||
        !joption(env, handle, "force-media-title", title)) goto failed;
    if (headers) {
        jsize count = (*env)->GetArrayLength(env, headers);
        mpv_node *values = calloc((size_t)count, sizeof(*values));
        if (count && !values) { fail(env, "out of memory for test headers"); goto failed; }
        for (jsize i = 0; i < count; i++) {
            jstring item = (jstring)(*env)->GetObjectArrayElement(env, headers, i);
            const char *utf = (*env)->GetStringUTFChars(env, item, NULL);
            values[i].format = MPV_FORMAT_STRING;
            values[i].u.string = utf ? strdup(utf) : NULL;
            if (utf) (*env)->ReleaseStringUTFChars(env, item, utf);
            (*env)->DeleteLocalRef(env, item);
        }
        mpv_node_list list = {.num = count, .values = values, .keys = NULL};
        mpv_node node = {.u.list = &list, .format = MPV_FORMAT_NODE_ARRAY};
        int code = p_set_option(handle, "http-header-fields", MPV_FORMAT_NODE, &node);
        for (jsize i = 0; i < count; i++) free(values[i].u.string);
        free(values);
        if (!checked(env, code, "http-header-fields NODE_ARRAY")) goto failed;
    }
    if (!checked(env, p_initialize(handle), "mpv_initialize")) goto failed;
    if (uri) {
        const char *text = (*env)->GetStringUTFChars(env, uri, NULL);
        if (!text) goto failed;
        const char *args[] = {"loadfile", text, NULL};
        int code = p_command(handle, args);
        (*env)->ReleaseStringUTFChars(env, uri, text);
        if (!checked(env, code, "loadfile")) goto failed;
    }
    return (jlong)(intptr_t)handle;
failed:
    p_terminate_destroy(handle);
    return 0;
}

JNIEXPORT void JNICALL Java_org_x2_capturetests_CaptureNative_pause(JNIEnv *env, jclass cls,
        jlong handle, jboolean paused) {
    (void)cls;
    int value = paused ? 1 : 0;
    checked(env, p_set_property((mpv_handle *)(intptr_t)handle, "pause", MPV_FORMAT_FLAG, &value), "pause");
}

JNIEXPORT jstring JNICALL Java_org_x2_capturetests_CaptureNative_property(JNIEnv *env,
        jclass cls, jlong handle, jstring property) {
    (void)cls;
    const char *name = (*env)->GetStringUTFChars(env, property, NULL);
    if (!name) return NULL;
    char *value = p_get_property_string((mpv_handle *)(intptr_t)handle, name);
    (*env)->ReleaseStringUTFChars(env, property, name);
    jstring result = value ? (*env)->NewStringUTF(env, value) : NULL;
    p_free(value);
    return result;
}

JNIEXPORT void JNICALL Java_org_x2_capturetests_CaptureNative_terminate(JNIEnv *env,
        jclass cls, jlong handle) {
    (void)env; (void)cls;
    if (handle) p_terminate_destroy((mpv_handle *)(intptr_t)handle);
}
