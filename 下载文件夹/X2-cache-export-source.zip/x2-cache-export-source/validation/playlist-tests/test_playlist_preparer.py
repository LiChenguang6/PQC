from pathlib import Path
import json
import shutil
import subprocess

BASE = Path('/workspace/x2-analysis')
TESTS = BASE / 'playlist-tests'
CLASSES = BASE / 'export-patch/classes'
CASES = TESTS / 'cases'
CASES.mkdir(exist_ok=True)


def prepare(name, mutate=None, ok=True, encrypted=False):
    folder = CASES / name
    if folder.exists():
        shutil.rmtree(folder)
    shutil.copytree(BASE / 'test-cache' / ('encrypted' if encrypted else 'clear'), folder)
    if mutate:
        mutate(folder)
    work = TESTS / 'work' / name
    p = subprocess.run(['java', '-cp', str(CLASSES), 'PrepareMain', str(folder), str(work)], text=True, capture_output=True)
    assert (p.returncode == 0) == ok, (name, p.stdout, p.stderr)
    result = {'name': name, 'accepted': p.returncode == 0}
    if ok:
        lines = p.stdout.splitlines()
        manifest = Path(lines[0]).read_text()
        assert 'http://' not in manifest and 'https://' not in manifest
        assert int(lines[1]) == 2
        assert float(lines[2]) == 2
        if encrypted:
            assert 'IV=0x1234567890abcdef1234567890abcdef' in manifest
            assert '#EXT-X-MEDIA-SEQUENCE:0' in manifest
        result['source'] = lines[3]
        output = work / 'result.mp4'
        subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y', '-allowed_extensions', 'ALL', '-protocol_whitelist', 'file,crypto,data', '-i', lines[0], '-c', 'copy', '-movflags', '+faststart', str(output)], check=True, capture_output=True)
        ref = BASE / 'test-cache/reference' / ('encrypted.mp4' if encrypted else 'clear.mp4')
        def hashes(path):
            q = subprocess.run(['ffmpeg', '-v', 'error', '-i', str(path), '-map', '0:v:0', '-f', 'framemd5', '-'], check=True, text=True, capture_output=True)
            return [line.split(',')[-1].strip() for line in q.stdout.splitlines() if line and not line.startswith('#')]
        assert hashes(output) == hashes(ref)
        result['decoded_video_matches_reference'] = True
    return result


def change_raw(folder, transform):
    manifest = folder / 'index.raw.m3u8'
    manifest.write_text(transform(manifest.read_text()))


cases = [
    prepare('clear'),
    prepare('encrypted_iv', encrypted=True),
    prepare('fallback', lambda d: (d / 'index.raw.m3u8').unlink()),
    prepare('encrypted_fallback_missing_iv', lambda d: (d / 'index.raw.m3u8').unlink(), ok=False, encrypted=True),
    prepare('missing_marker', lambda d: (d / 'index.m3u8').unlink(), ok=False),
    prepare('missing_segment', lambda d: (d / 'seg001.ts').unlink(), ok=False),
    prepare('empty_segment', lambda d: (d / 'seg001.ts').write_bytes(b''), ok=False),
    prepare('missing_key', lambda d: (d / 'enc.key').unlink(), ok=False, encrypted=True),
    prepare('short_key', lambda d: (d / 'enc.key').write_bytes(b'bad'), ok=False, encrypted=True),
    prepare('unsupported_crypto', lambda d: change_raw(d, lambda s: s.replace('AES-128', 'SAMPLE-AES')), ok=False, encrypted=True),
    prepare('invalid_iv', lambda d: change_raw(d, lambda s: s.replace('IV=0x1234567890abcdef1234567890abcdef', 'IV=oops')), ok=False, encrypted=True),
    prepare('rotation', lambda d: change_raw(d, lambda s: s.replace('#EXTINF:', '#EXT-X-KEY:METHOD=AES-128,URI="https://fixture.invalid/rotated.key"\n#EXTINF:', 1)), ok=False, encrypted=True),
    prepare('collision', lambda d: change_raw(d, lambda s: s.replace('https://fixture.invalid/media/seg001.ts', 'https://other.invalid/other/seg000.ts')), ok=False),
    prepare('traversal', lambda d: change_raw(d, lambda s: s.replace('https://fixture.invalid/media/seg001.ts', '../seg001.ts')), ok=False),
    prepare('encoded_traversal', lambda d: change_raw(d, lambda s: s.replace('https://fixture.invalid/media/seg001.ts', 'https://fixture.invalid/%2e%2e/seg001.ts')), ok=False),
    prepare('encoded_separator', lambda d: change_raw(d, lambda s: s.replace('https://fixture.invalid/media/seg001.ts', 'https://fixture.invalid/media/path%2fseg001.ts')), ok=False),
    prepare('file_escape', lambda d: change_raw(d, lambda s: s.replace('https://fixture.invalid/media/seg001.ts', 'file:///etc/seg001.ts')), ok=False),
    prepare('symlink_escape', lambda d: ((d / 'seg001.ts').unlink(), (d / 'seg001.ts').symlink_to(BASE / 'test-cache/clear/seg001.ts')), ok=False),
    prepare('byterange', lambda d: change_raw(d, lambda s: s.replace('#EXTINF:', '#EXT-X-BYTERANGE:100@0\n#EXTINF:', 1)), ok=False),
    prepare('master', lambda d: change_raw(d, lambda s: '#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1000\nother.m3u8\n'), ok=False),
    prepare('unknown_external_tag', lambda d: change_raw(d, lambda s: s.replace('#EXTINF:', '#EXT-X-UNKNOWN:URI="https://fixture.invalid/remote"\n#EXTINF:', 1)), ok=False),
]
(TESTS / 'results.json').write_text(json.dumps(cases, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'passed': len(cases), 'accepted_valid': sum(case['accepted'] for case in cases), 'rejected_invalid': sum(not case['accepted'] for case in cases)}))
