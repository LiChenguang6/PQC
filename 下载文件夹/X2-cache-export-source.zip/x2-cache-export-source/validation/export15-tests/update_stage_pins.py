from pathlib import Path
import sys,zipfile,hashlib,json
B=Path('/workspace/x2-analysis');sys.path.insert(0,str(B/'export-patch'));import patch_scroll,patch_ui,patch_launch_title,patch_tasks_short
R=B/'export15-tests';W=R/'asm';W.mkdir(exist_ok=True);N=B/'patch-tools/android-ndk-r28c/toolchains/llvm/prebuilt/linux-x86_64/bin';pins={}
for abi in patch_launch_title.SPECS:
 with zipfile.ZipFile(B/'input/app.apk') as z:d=z.read('lib/'+abi+'/libapp.so')
 d,_=patch_scroll.apply(d,abi,N,W);d,_=patch_ui.apply(d,abi);d,r=patch_launch_title.apply(d,abi,N,W);pins[abi]=hashlib.sha256(d).hexdigest()
(R/'launch-stage-pins.json').write_text(json.dumps(pins,indent=2))
p=B/'export-patch/patch_tasks_short.py';s=p.read_text()
for abi,new in pins.items():s=s.replace(patch_tasks_short.PINS[abi],new)
p.write_text(s);print(pins)
