from pathlib import Path
import hashlib,json,zipfile,subprocess,shutil,urllib.request,urllib.parse
B=Path('/workspace/x2-analysis');P=B/'export-patch';R=B/'export19-tests';O=B/'output';G=Path('/workspace/pqc-upload');F='下载文件夹'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(*a):return subprocess.check_output(a,text=True).strip()
h=sha(O/'X2-cache-export.apk');baseline=json.loads((R/'baseline-results.json').read_text());ui=json.loads((R/'ui-results.json').read_text());machine=json.loads((R/'pause-results.json').read_text());assert baseline['passed'] and baseline['apk_sha256']==ui['apk_sha256']==h and ui['gallery16']['passed'] and machine['passed'] and len(machine['cases'])==96
stable={n:sha(G/F/n) for n in ['X2-cache-export.apk','X2-cache-export-source.zip','使用说明.md','VALIDATION.md']}
usage='''# 原版播放回归测试包 export19-baseline

这是按最初上传的 X2 原始 APK 恢复客户端播放行为的回归测试包，不是已通过真实平台完整播放验收的修复版。原始 APK SHA-256：c3ec3365df8f01016b0c48db25fd7a1a21bf50bb31ce969d2edddcaf5ea2e385。

恢复 ARM64 和 x86_64 的四处原始指令：进入播放器时原广告初始化调用、VIP getter、播放进度回调调用、超过 20 秒暂停判断分支。原版仍会根据服务器返回的 canWatch 及 videoUrl 运行；没有制造完整视频、修改账户凭据或声明 VIP 解锁。

可能恢复原版广告弹窗、VIP 入口限制及试看提示。设置中的原开发测试开关更名为“记录播放状态”，不再改变播放判断。下载、去重、文件管理、预览及系统导航栏的业务代码保留 export18。

与导出版包名和签名相同，可覆盖安装并保留数据。文件名称与稳定版分开，GitHub 中 export18 的四个稳定文件保持原样。此测试包版本码 27；系统通常不允许直接覆盖回退到版本码更低的 export18，卸载会丢失应用私有配置和任务记录。

云端当前无法访问平台真实播放接口，不能保证该包解决十几秒问题，更不能保证所有 VIP 内容完整播放。若服务端仅返回短源，恢复客户端代码不能补出缺失内容。

APK SHA-256：`'''+h+'`\n'
validation='''# 原版播放回归验证

交付 APK SHA-256：`'''+h+'''`

- ARM64 与 x86_64 四处恢复点（共 8 处）逐字节匹配最初上传的原始 APK。
- ARM64 视频详情加载、详情请求、详情解析、进度回调和播放器位置回调五个完整函数逐字节匹配原始 APK。
- 实际交付库上执行两架构 96 组回调指令测试，0、12、19、20、21、25、65、120 秒均与原版许可判断一致。关闭或打开旧诊断标记均不再绕过原版暂停判断。这是指令模拟，不是实际网络视频播放。
- 云端 API29 x86_64 安装交付 APK，校验安装 SHA 与交付一致；设置持久化、预览列数、关闭图片及本地播放请求界面测试通过。
- 除下载设置的诊断开关说明外，下载、管理、预览和去重 Java 文件与 export18 源码一致；构建及签名检查通过。
- 未验证真实平台免费视频或禁区视频超过 20 秒，禁止据此宣称已完成真实内容修复或解锁 VIP。
'''
(O/'原版播放回归说明.md').write_text(usage);(O/'原版播放回归验证.md').write_text(validation)
f=P/'README.md';t=f.read_text().replace('源码（export18）','源码（export19-baseline）',1).replace('版本码 26','版本码 27',1);i=t.index('## export18');t=t[:i]+'''## export19-baseline：单独发布的原版播放回归实验

restore_original_playback.py 在原补丁执行后，按修改报告验证 before-image，精确恢复原始 APK 的 8 处指令。恢复播放器广告初始化、VIP getter、进度回调与暂停判断。此包保留其余功能，但可能恢复原版广告、入口限制和试看行为。不存在真实平台完整播放成功的证据，不能称作已验收修复。验证见 validation/export19-tests；export18 稳定文件保留。

'''+t[i:];f.write_text(t)
subprocess.run(['python3',str(P/'package_source.py')],check=True)
with zipfile.ZipFile(O/'X2-cache-export-source.zip') as z:assert z.testzip() is None and not any(n.endswith(('.apk','.p12')) for n in z.namelist());assert z.read('x2-cache-export-source/export-patch/restore_original_playback.py')==(P/'restore_original_playback.py').read_bytes()
assert not run('git','-C',str(G),'status','--porcelain')
subprocess.run(['git','-C',str(G),'fetch','origin','main'],check=True);subprocess.run(['git','-C',str(G),'merge','--ff-only','origin/main'],check=True)
files={'X2-original-playback-test.apk':'X2-cache-export.apk','X2-original-playback-test-source.zip':'X2-cache-export-source.zip','原版播放回归说明.md':'原版播放回归说明.md','原版播放回归验证.md':'原版播放回归验证.md'}
for dest,src in files.items():shutil.copy2(O/src,G/F/dest)
for n,v in stable.items():assert sha(G/F/n)==v
subprocess.run(['git','-C',str(G),'add','--',*[F+'/'+n for n in files]],check=True)
assert set(run('git','-C',str(G),'-c','core.quotepath=false','diff','--cached','--name-only').splitlines())=={F+'/'+n for n in files}
subprocess.run(['git','-C',str(G),'commit','-m','Add separate original-playback baseline experiment; retain export18 stable'],check=True);subprocess.run(['git','-C',str(G),'push','origin','HEAD:main'],check=True)
c=run('git','-C',str(G),'rev-parse','HEAD');url='https://raw.githubusercontent.com/LiChenguang6/PQC/'+c+'/'+urllib.parse.quote(F+'/X2-original-playback-test.apk')
with urllib.request.urlopen(url,timeout=60) as response:assert hashlib.sha256(response.read()).hexdigest()==h
result={'commit':c,'url':url,'sha256':h,'stable_export18_files_preserved':True,'real_platform_full_playback_verified':False};(R/'published-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False))
