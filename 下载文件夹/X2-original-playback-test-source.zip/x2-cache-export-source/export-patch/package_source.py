#!/usr/bin/env python3
"""Package the reproducible patch and LGPL media sources, excluding keys/builds."""
from pathlib import Path
import zipfile

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
OUTPUT = BASE / "output"
PREFIX = "x2-cache-export-source/"

def main():
    OUTPUT.mkdir(exist_ok=True)
    destination = OUTPUT / "X2-cache-export-source.zip"
    items = []
    for directory in ("src", "native", "third_party", "tools"):
        items += [(p, "export-patch/" + str(p.relative_to(HERE)))
                  for p in (HERE / directory).rglob("*") if p.is_file()]
    for name in ("README.md", "build_patch.py", "bootstrap_tools.py", "package_source.py", "inject_player_capture.py", "patch_scroll.py", "patch_ui.py", "patch_launch_title.py", "patch_tasks_short.py", "restore_original_playback.py"):
        items.append((HERE / name, "export-patch/" + name))
    media = BASE / "minimal-ffmpeg"
    for name in ("README.md", "build.sh", "fetch-source.sh", "source/FFmpeg-n6.0.tar.gz"):
        items.append((media / name, "minimal-ffmpeg/" + name))
    for name in ("build-info.json", "signature-verification.txt"):
        items.append((OUTPUT / name, name))
    for name in ("native-tests/android-results.json", "native-tests/NativeTest.java",
                 "playlist-tests/results.json", "playlist-tests/test_playlist_preparer.py",
                 "playlist-tests/PrepareMain.java", "download-tests/README.md",
                 "download-tests/results.json", "download-tests/DownloadMain.java", "download-tests/test_downloader.py",
                 "capture-tests/run_capture_tests.py", "capture-tests/native/capture_helper.c",
                 "capture-tests/src/org/x2/capturetests/CaptureNative.java",
                 "capture-tests/src/org/x2/capturetests/CaptureTest.java", "capture-tests/results/results.json",
                 "ui-download-tests/AndroidManifest.xml", "ui-download-tests/build_test_apk.py",
                 "ui-download-tests/fixture_server.py", "ui-download-tests/run_ui.py",
                 "ui-download-tests/verify_media.py", "ui-download-tests/cache_regression.py",
                 "ui-download-tests/src/org/x2/uitests/DownloadInstrumentation.java",
                 "ui-download-tests/results/ui-results.json", "ui-download-tests/results/media-results.json",
                 "ui-download-tests/results/cache-regression.json"):
        path = BASE / name
        if path.is_file():
            items.append((path, "validation/" + name))
    for name in ("fixture_server.py", "background_test.py", "verify_background.py", "folder_retry_test.py",
                 "remembered_folder_test.py", "verify_remembered.py", "flutter_startup_test.py", "first_folder.py", "finish_first_folder.py", "test_scroll_machine.py"):
        path=BASE / "export3-tests" / name
        items.append((path, "validation/export3-tests/" + path.name))
    items.append((BASE / "export3-tests/background-candidate-build-info.json", "validation/export3-tests/background-candidate-build-info.json"))
    for path in (BASE / "export3-tests").glob("*-results.json"):
        items.append((path, "validation/export3-tests/" + path.name))
    for name in ("fixture_server.py", "parallel_test.py", "position_after_restart.py", "flutter_startup_test.py", "test_ui_patch.py", "audit_payload.py"):
        path=BASE / "export4-tests" / name
        items.append((path, "validation/export4-tests/" + name))
    for path in (BASE / "export4-tests").glob("*-results.json"):
        items.append((path, "validation/export4-tests/" + path.name))
    items.append((BASE / "export4-tests/recommendations-analysis.json", "validation/export4-tests/recommendations-analysis.json"))
    for path in (BASE / "export5-tests").glob("*"):
        if path.is_file() and path.suffix in (".py", ".java", ".json", ".md", ".c", ".h"):
            items.append((path, "validation/export5-tests/" + path.name))
    for path in (BASE / "export6-tests").glob("*"):
        if path.is_file() and path.suffix in (".py", ".java", ".json", ".md", ".c", ".h", ".txt") and not path.name.endswith("-before.java"):
            items.append((path, "validation/export6-tests/" + path.name))
    for path in (BASE / "export7-tests").glob("*"):
        if path.is_file() and path.suffix in (".py", ".json", ".md", ".java"):
            items.append((path, "validation/export7-tests/" + path.name))
    for path in (BASE / "export8-tests").glob("*"):
        if path.is_file() and path.suffix in (".py", ".json", ".md", ".java"):
            items.append((path, "validation/export8-tests/" + path.name))
    for path in (BASE / "export9-tests").glob("*"):
        if path.is_file() and path.suffix in (".py", ".json", ".md") and not path.name.endswith("-before.py"):
            items.append((path, "validation/export9-tests/" + path.name))
    for path in (BASE / "export10-tests").glob("*"):
        if path.is_file() and path.suffix in (".py", ".json", ".md"):
            items.append((path, "validation/export10-tests/" + path.name))
    for path in (BASE / "export11-tests").glob("*"):
        if path.is_file() and path.suffix in (".py", ".json", ".md"):
            items.append((path, "validation/export11-tests/" + path.name))
    for path in (BASE / "export12-tests").glob("*"):
        if path.is_file() and path.suffix in (".py", ".json", ".md"):
            items.append((path, "validation/export12-tests/" + path.name))
    for path in (BASE / "export13-tests").glob("*"):
        if path.is_file() and path.suffix in (".py", ".json", ".md"):
            items.append((path, "validation/export13-tests/" + path.name))
    for path in (BASE / "export14-tests").glob("*"):
        if path.is_file() and path.suffix in (".py", ".java", ".json", ".md"):
            items.append((path, "validation/export14-tests/" + path.name))
    for path in (BASE / "export15-tests").glob("*"):
        if path.is_file() and path.suffix in (".py", ".java", ".json", ".md"):
            items.append((path, "validation/export15-tests/" + path.name))
    for path in (BASE / "export16-tests").glob("*"):
        if path.is_file() and path.suffix in (".py", ".java", ".json", ".md"):
            items.append((path, "validation/export16-tests/" + path.name))
    for path in (BASE / "export18-tests").glob("*"):
        if path.is_file() and path.suffix in (".py", ".java", ".json", ".md"):
            items.append((path, "validation/export18-tests/" + path.name))
    for path in (BASE / "export19-tests").glob("*"):
        if path.is_file() and path.suffix in (".py", ".java", ".json", ".md"):
            items.append((path, "validation/export19-tests/" + path.name))
    with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for source, target in items:
            if not source.is_file():
                raise RuntimeError("Missing source artifact: " + str(source))
            archive.write(source, PREFIX + target)
    with zipfile.ZipFile(destination) as archive:
        assert archive.testzip() is None
        assert not any("key.p12" in name or "/build/" in name or name.endswith(".apk")
                       for name in archive.namelist())
    print(destination)

if __name__ == "__main__":
    main()
