from prepare_machine import prepare
prepare()
from pathlib import Path
import json,struct
from unicorn import *
from unicorn.arm64_const import *
from unicorn.x86_const import *
R=Path('/workspace/x2-analysis/export5-tests');result=[]
for abi in ['arm64-v8a','x86_64']:
 for token_ok,config_ok in [(True,True),(False,True),(True,False)]:
  arm=abi=='arm64-v8a';u=Uc(UC_ARCH_ARM64 if arm else UC_ARCH_X86,UC_MODE_ARM if arm else UC_MODE_64);d=(R/'asm'/f'{abi}-patched.so').read_bytes();u.mem_map(0,0x900000);u.mem_write(0,d);u.mem_map(0x1000000,0x40000);u.mem_map(0x2000000,0x10000)
  null=0x2000081;thr=0x2001000;table=0x2003000;token=0x2005001;config=0x2006001
  for at,v,fmt in [(thr+0x68,table,'Q'),(thr+0x78,null,'Q'),(thr+0x88,null+0x30,'Q'),(thr+0x80,null+0x20,'Q'),(table+0x2478,config,'Q'),(token+7,2 if token_ok else 0,'I'),(config+7,2 if config_ok else 0,'I')]:u.mem_write(at,struct.pack('<'+fmt,v))
  regs={UC_ARM64_REG_X0:token,UC_ARM64_REG_X22:null,UC_ARM64_REG_X26:thr,UC_ARM64_REG_X27:0x1000000,UC_ARM64_REG_X15:0x2009000} if arm else {UC_X86_REG_RAX:token,UC_X86_REG_R14:thr,UC_X86_REG_R15:0x1000000,UC_X86_REG_RSP:0x2009000}
  for r,v in regs.items():u.reg_write(r,v)
  seen=[]
  def hook(uc,at,size,arg):
   if at in ((0x5f9598,0x4f71a4) if arm else (0x6a381c,0x56bbbc)):
    seen.append('home' if at==(0x5f9598 if arm else 0x6a381c) else 'initialization_failure');uc.emu_stop()
  u.hook_add(UC_HOOK_CODE,hook);u.emu_start(0x5f952c if arm else 0x6a3798,0x300000,count=100)
  expected='home' if token_ok and config_ok else 'initialization_failure';assert seen==[expected],(abi,token_ok,config_ok,seen)
  result.append(dict(abi=abi,nonempty_stored_value=token_ok,nonempty_initial_configuration=config_ok,outcome=expected))
(R/'skip-guard-results.json').write_text(json.dumps(result,indent=2));print('PASS 6 original skip-readiness guard paths')
