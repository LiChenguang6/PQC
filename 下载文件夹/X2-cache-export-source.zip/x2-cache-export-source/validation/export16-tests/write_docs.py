from pathlib import Path
import json,hashlib
B=Path('/workspace/x2-analysis');R=B/'export16-tests';O=B/'output';sha=hashlib.sha256((O/'X2-cache-export.apk').read_bytes()).hexdigest()
(O/'使用说明.md').write_text('''# X2 保存导出版 export16

在“管理 → 下载设置”可开关“显示视频预览图”，并选择“预览每行数量”：1、2、3 或 4 个。配置自动保存，同时作用于“下载完成”和“视频预览”。关闭预览图后仍显示标题并可点击播放，不提取新封面。

“管理”顶部原“导出已有缓存”已替换为“视频预览”。新页面仅展示下载完成的本地视频封面与标题，隐藏管理按钮和状态栏，支持滑动浏览；点击视频交给本机支持 MP4 的播放器播放。系统返回手势回到管理页。它不是自动连续播放的短视频播放器。

原“导出已有缓存”移到“下载设置”中。管理页的下载、暂停、批量操作与两种删除方式保留。视频预览页不执行删除等管理操作。

沿用原签名，可覆盖安装 export15，保留任务、文件夹配置与文件。请勿先卸载；文件权限失效时需重新选目录。

本版停止排查先前的播放时长问题，没有修改账户权限或平台视频来源。

APK SHA-256：`'''+sha+'`\n',encoding='utf-8')
ui=json.loads((R/'ui-results.json').read_text());compare=json.loads((R/'comparison-results.json').read_text());startup=json.loads((R/'flutter-startup-results.json').read_text())
assert ui['apk_sha256']==compare['apk_sha256']==startup['final_apk_sha256']==sha
(O/'VALIDATION.md').write_text('''# export16 验证

交付 APK SHA-256：`'''+sha+'''`

云端 Android 10/API29 x86_64 模拟器测试（非用户 Android16 真机）：

- 通过设置界面关闭预览图、选择每行 2 个，重新进入设置后配置保持。
- 管理页与独立视频预览页均应用配置；4 列和重新显示预览图通过。
- 预览页没有多选、下载设置等管理控件；点击已完成视频发送带读取权限的本地 MP4 播放请求。
- 实际 SAF MP4 封面、0:02 时长、16:9 比例、磁盘缓存、无效文件占位、多选不误播放通过。
- 仅删记录保留文件、批量删 MP4、删除失败保留记录及管理页删除选项通过。
- 原 Flutter 主界面首次启动测试出现 native 渲染线程崩溃；重新启动后库加载与进程存活检查通过。Native 库与上一版一致，未在本次预览改动中修改该部分。
- 与 export15 对比：27 个 native 库完全一致；下载服务、记录存储、下载器、封面提取器和封装器源码未变。

未测试真实平台 VIP 播放，也未对该问题做修改。历史版本验证材料仅作历史参考。
''',encoding='utf-8')
