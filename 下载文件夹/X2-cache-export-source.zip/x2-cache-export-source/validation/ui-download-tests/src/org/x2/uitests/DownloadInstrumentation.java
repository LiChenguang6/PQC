package org.x2.uitests;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.x2.capturetests.CaptureNative;
import org.x2.export.DownloadConfig;
import org.x2.export.DownloadStore;
import org.x2.export.ExportEntry;
import org.x2.export.PlayerCapture;

/** Test APK only. No test entry points or fixture credentials are in the user APK. */
public final class DownloadInstrumentation extends Instrumentation {
    private Bundle options;
    @Override public void onCreate(Bundle args){options=args;start();}
    @Override public void onStart(){long handle=0;try{
        String mode=options.getString("mode","capture");
        if(mode.equals("source14")){
            getUiAutomation();final Activity settings=startActivitySync(new Intent().setClassName(getTargetContext(),"org.x2.export.DownloadSettingsActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));System.loadLibrary("capturetest");CaptureNative.load(getTargetContext().getApplicationInfo().nativeLibraryDir+"/libmpv.so");handle=CaptureNative.create(options.getString("fixture"),"DO_NOT_REPORT_AGENT","",new String[]{"X-Fixture: DO_NOT_REPORT_HEADER"},"DO_NOT_REPORT_TITLE",true);PlayerCapture.register(handle);
            long end=System.currentTimeMillis()+15000;String duration="";while(System.currentTimeMillis()<end){duration=CaptureNative.property(handle,"duration");if(duration!=null&&duration.startsWith("12"))break;Thread.sleep(100);}if(duration==null||!duration.startsWith("12"))throw new AssertionError("HLS fixture unavailable");
            CaptureNative.pause(handle,false);Class<?> history=Class.forName("org.x2.export.PlaybackDiagnostics");java.lang.reflect.Method startHistory=history.getDeclaredMethod("start",android.content.Context.class);startHistory.setAccessible(true);getTargetContext().getSharedPreferences("x2-development",0).edit().putBoolean("forbidden-entry",true).commit();startHistory.invoke(null,getTargetContext());Thread.sleep(1600);CaptureNative.pause(handle,true);
            final View probe=findText(settings.findViewById(android.R.id.content),"检查当前播放源（复制）");if(probe==null||!hasScroll(settings.findViewById(android.R.id.content)))throw new AssertionError("source inspection setting unavailable");runOnMainSync(()->probe.performClick());if(!clickAccessible("复制",20000))throw new AssertionError("inspection result not available");Thread.sleep(300);
            android.content.ClipboardManager cb=(android.content.ClipboardManager)getTargetContext().getSystemService(android.content.Context.CLIPBOARD_SERVICE);String text=cb.getPrimaryClip().getItemAt(0).getText().toString();if(!text.contains("version=9.9.9-export14")||!text.contains("manifest_seconds=12.000")||!text.contains("segments=3")||!text.contains("endlist=1")||!text.contains("source_id=")||!text.contains("snapshot=recent_cached"))throw new AssertionError("manifest result incomplete "+text);if(text.contains("DO_NOT_REPORT")||text.contains("http://")||text.contains("auth_key")||text.contains("X-Fixture"))throw new AssertionError("inspection report leaked captured credentials");
            PlayerCapture.unregister(handle);CaptureNative.terminate(handle);handle=0;Bundle result=new Bundle();result.putString("result","PHONE_SOURCE_CAPTURE_HLS_DURATION_ENDLIST_PRIVACY_AND_COPY_PASS");result.putString("manifest_seconds","12.000");result.putBoolean("real_platform_video",false);finish(Activity.RESULT_OK,result);return;
        }
        if(mode.equals("offline28")){
            System.loadLibrary("capturetest");CaptureNative.load(getTargetContext().getApplicationInfo().nativeLibraryDir+"/libmpv.so");
            handle=CaptureNative.create(options.getString("fixture"),"X2OfflineFixture","",new String[0],"Synthetic offline 28-second fixture",false);PlayerCapture.register(handle);
            double max=0,duration=0;long until=SystemClock.elapsedRealtime()+45000;String endProperty="";java.lang.reflect.Method metrics=PlayerCapture.class.getDeclaredMethod("playbackState");metrics.setAccessible(true);String state="";
            while(SystemClock.elapsedRealtime()<until){String pos=CaptureNative.property(handle,"time-pos"),dur=CaptureNative.property(handle,"duration");try{if(pos!=null)max=Math.max(max,Double.parseDouble(pos));if(dur!=null)duration=Double.parseDouble(dur);}catch(NumberFormatException ignored){}if(max>=23){state=(String)metrics.invoke(null);endProperty=CaptureNative.property(handle,"end");break;}Thread.sleep(200);}
            if(max<23||duration<27||!state.contains("players=1"))throw new AssertionError("original MPV/observer did not cross23seconds: max="+max+" duration="+duration+" state="+state);
            PlayerCapture.unregister(handle);CaptureNative.terminate(handle);handle=0;Bundle result=new Bundle();result.putString("result","ORIGINAL_MPV_OBSERVER_CONTINUOUS_LOCAL_PLAYBACK_OVER23_SECONDS_PASS");result.putString("numeric_state",state);result.putDouble("max_position_seconds",max);result.putDouble("duration_seconds",duration);result.putString("end_property",endProperty);result.putBoolean("real_platform_video",false);finish(Activity.RESULT_OK,result);return;
        }
        if(mode.equals("delete12")){
            getUiAutomation();final DownloadStore store=DownloadStore.get(getTargetContext());for(DownloadStore.Job old:store.all())if(old.title.startsWith("删除回归12"))store.remove(old);
            final android.net.Uri keep=createDeleteFixture("删除回归12 保留"),one=createDeleteFixture("删除回归12 A"),two=createDeleteFixture("删除回归12 B"),ui=createDeleteFixture("删除回归12 界面");
            final DownloadStore.Job k=savedJob(store,"删除回归12 保留",keep),a=savedJob(store,"删除回归12 A",one),b=savedJob(store,"删除回归12 B",two),unselected=savedJob(store,"删除回归12 界面",ui),bad=savedJob(store,"删除回归12 失败",android.net.Uri.parse("content://invalid.x2.test/no-permission"));
            runOnMainSync(()->org.x2.export.DownloadService.command(getTargetContext(),"remove",k.id));awaitRemoved(store,k.id);if(!documentExists(keep))throw new AssertionError("record-only action deleted MP4");
            final java.util.ArrayList<String> ids=new java.util.ArrayList<String>();ids.add(a.id);ids.add(b.id);ids.add(bad.id);runOnMainSync(()->org.x2.export.DownloadService.commandBatch(getTargetContext(),"remove_file",ids));awaitRemoved(store,a.id);awaitRemoved(store,b.id);
            long end=System.currentTimeMillis()+15000;while(bad.state.equals("deleting")&&System.currentTimeMillis()<end)Thread.sleep(100);if(store.find(bad.id)==null||!bad.state.equals("success")||!bad.stage.contains("无法删除"))throw new AssertionError("failed file deletion lost record");
            if(documentExists(one)||documentExists(two)||!documentExists(ui)||store.find(unselected.id)==null)throw new AssertionError("batch deleted wrong files");
            final Activity manager=startActivitySync(new Intent().setClassName(getTargetContext(),"org.x2.export.DownloadTasksActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));final android.widget.ListView list=(android.widget.ListView)field(manager,"list");
            runOnMainSync(()->((View)fieldUnchecked(manager,"completed")).performClick());end=System.currentTimeMillis()+15000;while(position(list,"删除回归12 界面")<0&&System.currentTimeMillis()<end)Thread.sleep(100);if(position(list,"删除回归12 界面")<0)throw new AssertionError("completed fixture missing");
            runOnMainSync(()->list.getOnItemLongClickListener().onItemLongClick(list,null,position(list,"删除回归12 界面"),0));if(!clickAccessible("删除记录及 MP4 文件",15000))throw new AssertionError("single-file delete option absent");sendKeyDownUpSync(android.view.KeyEvent.KEYCODE_BACK);
            runOnMainSync(()->{((View)fieldUnchecked(manager,"multi")).performClick();int pos=position(list,"删除回归12 界面");list.performItemClick(null,pos,pos);findText(manager.findViewById(android.R.id.content),"删除").performClick();});
            if(!clickAccessible("删除记录及 MP4 文件",15000)||!clickAccessible("删除",15000))throw new AssertionError("batch file-delete confirmation missing");awaitRemoved(store,unselected.id);if(documentExists(ui))throw new AssertionError("UI batch left MP4 behind");
            if(!documentExists(keep))throw new AssertionError("unselected retained file disappeared");android.provider.DocumentsContract.deleteDocument(getTargetContext().getContentResolver(),keep);store.remove(bad);Thread.sleep(7000);
            Bundle result=new Bundle();result.putString("result","RECORD_ONLY_KEEP_BATCH_FILE_DELETE_FAILURE_RETENTION_AND_UI_OPTIONS_PASS");result.putInt("pid",android.os.Process.myPid());finish(Activity.RESULT_OK,result);return;
        }
        if(mode.equals("cover13")){
            final Class<?> appearance=Class.forName("org.x2.export.Appearance");final java.lang.reflect.Method image=appearance.getDeclaredMethod("importImage",android.content.Context.class,android.net.Uri.class,boolean.class),reset=appearance.getDeclaredMethod("reset",android.content.Context.class);image.setAccessible(true);reset.setAccessible(true);
            java.io.File source=new java.io.File(getTargetContext().getFilesDir(),"cover13-test.png");android.graphics.Bitmap fixture=android.graphics.Bitmap.createBitmap(40,20,android.graphics.Bitmap.Config.ARGB_8888);fixture.eraseColor(0xff3388cc);try(java.io.FileOutputStream out=new java.io.FileOutputStream(source)){fixture.compress(android.graphics.Bitmap.CompressFormat.PNG,100,out);}fixture.recycle();image.invoke(null,getTargetContext(),android.net.Uri.fromFile(source),false);
            final Activity main=startActivitySync(new Intent().setClassName(getTargetContext(),"com.example.yinqishe_app.MainActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));System.loadLibrary("capturetest");
            long end=System.currentTimeMillis()+15000;while(!CaptureNative.setHomeReady(0)&&System.currentTimeMillis()<end)Thread.sleep(100);Thread.sleep(1500);
            final View cover=main.findViewById(android.R.id.content).findViewWithTag("x2-custom-cover");if(cover==null)throw new AssertionError("production startup cover disappeared before home-ready signal");
            if(!CaptureNative.setHomeReady(1))throw new AssertionError("test home marker unavailable");end=System.currentTimeMillis()+3000;while(cover.getParent()!=null&&System.currentTimeMillis()<end)Thread.sleep(100);if(cover.getParent()!=null)throw new AssertionError("production cover did not consume home-ready signal");Thread.sleep(300);if(cover.getParent()!=null)throw new AssertionError("removed cover reattached");reset.invoke(null,getTargetContext());source.delete();
            Bundle result=new Bundle();result.putString("result","PRODUCTION_COVER_WAITS_FOR_HOME_MARKER_AND_REMOVES_PASS");result.putBoolean("home_marker_synthetic",true);finish(Activity.RESULT_OK,result);return;
        }
        if(mode.equals("appearance12")){
            getUiAutomation();final Class<?> appearance=Class.forName("org.x2.export.Appearance");final java.lang.reflect.Method setName=appearance.getDeclaredMethod("setName",android.content.Context.class,String.class),name=appearance.getDeclaredMethod("name",android.content.Context.class),image=appearance.getDeclaredMethod("importImage",android.content.Context.class,android.net.Uri.class,boolean.class),file=appearance.getDeclaredMethod("file",android.content.Context.class,boolean.class),shortcut=appearance.getDeclaredMethod("shortcut",android.content.Context.class),reset=appearance.getDeclaredMethod("reset",android.content.Context.class),cover=appearance.getDeclaredMethod("installCover",Activity.class);for(java.lang.reflect.Method method:new java.lang.reflect.Method[]{setName,name,image,file,shortcut,reset,cover})method.setAccessible(true);
            java.io.File source=new java.io.File(getTargetContext().getFilesDir(),"appearance12-test.png"),invalid=new java.io.File(getTargetContext().getFilesDir(),"appearance12-invalid.txt"),untouched=new java.io.File(getTargetContext().getFilesDir(),"appearance12-unrelated.mp4");android.graphics.Bitmap fixture=android.graphics.Bitmap.createBitmap(40,20,android.graphics.Bitmap.Config.ARGB_8888);fixture.eraseColor(0xff3388cc);try(java.io.FileOutputStream out=new java.io.FileOutputStream(source)){fixture.compress(android.graphics.Bitmap.CompressFormat.PNG,100,out);}fixture.recycle();try(java.io.FileOutputStream out=new java.io.FileOutputStream(invalid)){out.write(new byte[]{1,2,3});}try(java.io.FileOutputStream out=new java.io.FileOutputStream(untouched)){out.write(new byte[]{7,8,9});}
            setName.invoke(null,getTargetContext(),"云影😀");image.invoke(null,getTargetContext(),android.net.Uri.fromFile(source),true);image.invoke(null,getTargetContext(),android.net.Uri.fromFile(source),false);java.io.File iconFile=(java.io.File)file.invoke(null,getTargetContext(),true),splashFile=(java.io.File)file.invoke(null,getTargetContext(),false);android.graphics.Bitmap decoded=android.graphics.BitmapFactory.decodeFile(iconFile.getPath());if(decoded==null||decoded.getWidth()!=256||decoded.getHeight()!=256)throw new AssertionError("custom icon not normalized");decoded.recycle();long validLength=iconFile.length();boolean rejected=false;try{image.invoke(null,getTargetContext(),android.net.Uri.fromFile(invalid),true);}catch(java.lang.reflect.InvocationTargetException expected){rejected=true;}if(!rejected||iconFile.length()!=validLength)throw new AssertionError("invalid image replaced saved icon");
            final Activity settings=startActivitySync(new Intent().setClassName(getTargetContext(),"org.x2.export.DownloadSettingsActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));ActivityMonitor monitor=addMonitor("org.x2.export.AppearanceActivity",null,false);runOnMainSync(()->findText(settings.findViewById(android.R.id.content),"名称、图标与开屏").performClick());final Activity page=waitForMonitorWithTimeout(monitor,15000);removeMonitor(monitor);if(page==null||findText(page.findViewById(android.R.id.content),"选择应用开屏图片")==null||!hasScroll(page.findViewById(android.R.id.content)))throw new AssertionError("appearance settings entry missing");
            final Throwable[] failure={null};runOnMainSync(()->{try{cover.invoke(null,page);}catch(Throwable e){failure[0]=e;}});if(failure[0]!=null)throw new AssertionError(failure[0]);View custom=page.findViewById(android.R.id.content).findViewWithTag("x2-custom-cover");if(custom==null)throw new AssertionError("custom startup cover missing");final View close=findText(custom,"关闭封面");runOnMainSync(()->close.performClick());Thread.sleep(500);if(custom.getParent()!=null)throw new AssertionError("startup cover cannot close or reappeared");
            android.content.pm.ShortcutManager shortcuts=getTargetContext().getSystemService(android.content.pm.ShortcutManager.class);boolean supported=shortcuts!=null&&shortcuts.isRequestPinShortcutSupported();boolean pinned=false;
            if(supported){runOnMainSync(()->{try{shortcut.invoke(null,getTargetContext());}catch(Throwable e){failure[0]=e;}});if(failure[0]!=null)throw new AssertionError(failure[0]);long end=System.currentTimeMillis()+20000;while(System.currentTimeMillis()<end){for(android.content.pm.ShortcutInfo item:shortcuts.getPinnedShortcuts())if(item.getId().equals("x2-custom-entry"))pinned=true;if(pinned)break;for(String label:new String[]{"Add automatically","ADD AUTOMATICALLY","Add","ADD","添加","自动添加"})if(clickAccessible(label,200))break;Thread.sleep(200);}if(!pinned)throw new AssertionError("launcher did not pin custom shortcut");
                setName.invoke(null,getTargetContext(),"新名称😀");runOnMainSync(()->{try{shortcut.invoke(null,getTargetContext());}catch(Throwable e){failure[0]=e;}});boolean updated=false;for(android.content.pm.ShortcutInfo item:shortcuts.getPinnedShortcuts())if(item.getId().equals("x2-custom-entry")&&"新名称😀".contentEquals(item.getShortLabel()))updated=true;if(!updated)throw new AssertionError("pinned shortcut label did not update");}
            reset.invoke(null,getTargetContext());if(iconFile.exists()||splashFile.exists()||!untouched.exists()||"新名称😀".equals(name.invoke(null,getTargetContext())))throw new AssertionError("appearance reset damaged unrelated data or retained custom files");if(pinned)runOnMainSync(()->{try{shortcut.invoke(null,getTargetContext());}catch(Throwable ignored){}});source.delete();invalid.delete();untouched.delete();
            Bundle result=new Bundle();result.putString("result","APPEARANCE_IMPORT_VALIDATION_ENTRY_COVER_RESET_AND_SHORTCUT_PASS");result.putBoolean("launcher_pin_supported",supported);result.putBoolean("launcher_pinned_and_updated",pinned);finish(Activity.RESULT_OK,result);return;
        }
        if(mode.equals("ui8")){
            getUiAutomation();
            final DownloadStore store=DownloadStore.get(getTargetContext());
            for(DownloadStore.Job old:store.all()){if(old.title.startsWith("分区回归"))store.remove(old);else if(old.active()){old.state="paused";old.paused=true;}}
            org.x2.export.DownloadConfig.setParallel(getTargetContext(),2);
            final DownloadStore.Job a=DownloadStore.playback(getTargetContext(),new PlayerCapture.Source("http://10.0.2.2:18770/slow/A.mp4","X2BatchTest","",new String[0],"分区回归 A"));
            final DownloadStore.Job b=DownloadStore.playback(getTargetContext(),new PlayerCapture.Source("http://10.0.2.2:18770/slow/B.mp4","X2BatchTest","",new String[0],"分区回归 B"));
            final DownloadStore.Job c=DownloadStore.playback(getTargetContext(),new PlayerCapture.Source("http://10.0.2.2:18770/slow/C.mp4","X2BatchTest","",new String[0],"分区回归 完成"));c.state="success";c.stage="已保存 MP4";c.document="content://com.android.externalstorage.documents/document/primary%3ADownload%2Ftest.mp4";c.source=null;
            store.add(a);store.add(b);store.add(c);store.save();
            long started=SystemClock.uptimeMillis();final Activity manager=startActivitySync(new Intent().setClassName(getTargetContext(),"org.x2.export.DownloadTasksActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));long opened=SystemClock.uptimeMillis()-started;
            final android.widget.ListView list=(android.widget.ListView)field(manager,"list");long end=System.currentTimeMillis()+15000;
            while(position(list,"分区回归 B")<0&&System.currentTimeMillis()<end)Thread.sleep(100);
            if(position(list,"分区回归 A")<0)throw new AssertionError("async queue not loaded");
            runOnMainSync(()->((View)fieldUnchecked(manager,"multi")).performClick());
            runOnMainSync(()->{int pa=position(list,"分区回归 A"),pb=position(list,"分区回归 B");list.performItemClick(null,pa,pa);list.performItemClick(null,pb,pb);});
            Thread.sleep(1200);if(((java.util.Set)field(manager,"selected")).size()!=2)throw new AssertionError("selection lost across refresh");
            final View pause=findText(manager.findViewById(android.R.id.content),"暂停");runOnMainSync(()->pause.performClick());awaitState(a,"paused");awaitState(b,"paused");
            runOnMainSync(()->{int pa=position(list,"分区回归 A"),pb=position(list,"分区回归 B");list.performItemClick(null,pa,pa);list.performItemClick(null,pb,pb);findText(manager.findViewById(android.R.id.content),"继续").performClick();});awaitState(a,"running");awaitState(b,"running");
            runOnMainSync(()->{int pa=position(list,"分区回归 A"),pb=position(list,"分区回归 B");list.performItemClick(null,pa,pa);list.performItemClick(null,pb,pb);pause.performClick();});awaitState(a,"paused");awaitState(b,"paused");
            runOnMainSync(()->{int pa=position(list,"分区回归 A"),pb=position(list,"分区回归 B");list.performItemClick(null,pa,pa);list.performItemClick(null,pb,pb);findText(manager.findViewById(android.R.id.content),"删除").performClick();});Thread.sleep(500);
            boolean clicked=false;long dialogEnd=System.currentTimeMillis()+20000;while(!clicked&&System.currentTimeMillis()<dialogEnd){android.view.accessibility.AccessibilityNodeInfo window=getUiAutomation().getRootInActiveWindow();if(window!=null){java.util.List<android.view.accessibility.AccessibilityNodeInfo> nodes=window.findAccessibilityNodeInfosByText("删除");for(android.view.accessibility.AccessibilityNodeInfo node:nodes)if("删除".contentEquals(node.getText())&&node.isClickable()){clicked=node.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK);break;}}if(!clicked)Thread.sleep(300);}if(!clicked)throw new AssertionError("remove confirmation missing");
            end=System.currentTimeMillis()+15000;while((store.find(a.id)!=null||store.find(b.id)!=null)&&System.currentTimeMillis()<end)Thread.sleep(100);if(store.find(a.id)!=null||store.find(b.id)!=null||store.find(c.id)==null)throw new AssertionError("batch remove affected wrong records");
            runOnMainSync(()->{((View)fieldUnchecked(manager,"multi")).performClick();((View)fieldUnchecked(manager,"completed")).performClick();});Thread.sleep(800);
            final Intent[] playback={null};ActivityMonitor player=new ActivityMonitor(){@Override public ActivityResult onStartActivity(Intent i){if(Intent.ACTION_VIEW.equals(i.getAction())){playback[0]=i;return new ActivityResult(Activity.RESULT_OK,null);}return null;}};addMonitor(player);
            runOnMainSync(()->{int pos=position(list,"分区回归 完成");if(pos<0)throw new AssertionError("completed partition missing");list.performItemClick(null,pos,pos);});Thread.sleep(400);removeMonitor(player);
            if(playback[0]==null||!"video/mp4".equals(playback[0].getType())||(playback[0].getFlags()&Intent.FLAG_GRANT_READ_URI_PERMISSION)==0||playback[0].getClipData()==null)throw new AssertionError("completed click did not grant playback URI");
            runOnMainSync(()->manager.finish());waitForIdleSync();long warm=SystemClock.uptimeMillis();final Activity again=startActivitySync(new Intent().setClassName(getTargetContext(),"org.x2.export.DownloadTasksActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));long warmMs=SystemClock.uptimeMillis()-warm;
            final android.widget.ListView warmList=(android.widget.ListView)field(again,"list");if(warmList.getAdapter().getCount()==0)throw new AssertionError("warm open did not display cached records");
            Bundle report=new Bundle();report.putString("result","ASYNC_CACHE_PARTITIONS_MULTISELECT_BATCH_PAUSE_RESUME_REMOVE_AND_PLAY_PASS");report.putLong("cold_activity_ms",opened);report.putLong("warm_activity_ms",warmMs);report.putInt("warm_rows",warmList.getAdapter().getCount());runOnMainSync(()->again.finish());finish(Activity.RESULT_OK,report);return;
        }
        if(mode.equals("pauseSeed6")||mode.equals("pauseVerify6")){
            DownloadStore store=DownloadStore.get(getTargetContext());DownloadStore.Job selected=null;
            if(mode.equals("pauseSeed6")){
                for(DownloadStore.Job old:store.all())if(old.title.equals("回归持久暂停"))store.remove(old);
                selected=DownloadStore.playback(getTargetContext(),new PlayerCapture.Source("http://10.0.2.2:18770/slow/Persist.mp4","X2PausePersist/1.0","",new String[0],"回归持久暂停"));store.add(selected);
                final String id=selected.id;runOnMainSync(()->org.x2.export.DownloadService.command(getTargetContext(),"pause",id));awaitState(selected,"paused");Thread.sleep(1500);
            } else {
                for(DownloadStore.Job job:store.all())if(job.title.equals("回归持久暂停"))selected=job;
                if(selected==null||!selected.paused||!selected.state.equals("paused"))throw new AssertionError("paused record not restored: "+(selected==null?"missing":selected.state+"/"+selected.paused));
                final String id=selected.id;runOnMainSync(()->org.x2.export.DownloadService.start(getTargetContext()));Thread.sleep(1200);
                if(!selected.state.equals("paused"))throw new AssertionError("paused task restarted automatically");
                runOnMainSync(()->org.x2.export.DownloadService.command(getTargetContext(),"resume",id));awaitState(selected,"running");
                runOnMainSync(()->org.x2.export.DownloadService.command(getTargetContext(),"cancel",id));awaitState(selected,"cancelled");
                store.remove(selected);
            }
            Bundle report=new Bundle();report.putString("result",mode.equals("pauseSeed6")?"PAUSED_RECORD_SAVED":"PAUSED_RECORD_RESTORED_AND_RESUMED");finish(Activity.RESULT_OK,report);return;
        }
        if(mode.equals("service6")){
            final DownloadStore store=DownloadStore.get(getTargetContext());
            for(DownloadStore.Job old:store.all())if(old.title.startsWith("回归暂停 ")||old.title.equals("回归持久暂停"))store.remove(old);
            org.x2.export.DownloadConfig.setParallel(getTargetContext(),1);
            final DownloadStore.Job a=DownloadStore.playback(getTargetContext(),new PlayerCapture.Source("http://10.0.2.2:18770/slow/A.mp4","X2ServiceRegression/1.0","",new String[0],"回归暂停 A"));
            final DownloadStore.Job b=DownloadStore.playback(getTargetContext(),new PlayerCapture.Source("http://10.0.2.2:18770/slow/B.mp4","X2ServiceRegression/1.0","",new String[0],"回归暂停 B"));
            store.add(a);store.add(b);
            runOnMainSync(()->org.x2.export.DownloadService.start(getTargetContext()));
            awaitState(a,"running");Thread.sleep(1200);
            runOnMainSync(()->org.x2.export.DownloadService.command(getTargetContext(),"pause",a.id));
            awaitState(a,"paused");awaitState(b,"running");int progress=a.progress;Thread.sleep(1500);if(a.progress!=progress)throw new AssertionError("paused progress changed");
            runOnMainSync(()->org.x2.export.DownloadService.command(getTargetContext(),"resume",a.id));Thread.sleep(600);
            if(!a.state.equals("paused")||!a.resumeRequested)throw new AssertionError("resume exceeded parallel limit");
            runOnMainSync(()->org.x2.export.DownloadService.command(getTargetContext(),"cancel",b.id));awaitState(b,"cancelled");awaitState(a,"running");
            runOnMainSync(()->org.x2.export.DownloadService.command(getTargetContext(),"pause",a.id));awaitState(a,"paused");
            runOnMainSync(()->org.x2.export.DownloadService.command(getTargetContext(),"remove",a.id));
            long end=System.currentTimeMillis()+15000;while(store.find(a.id)!=null&&System.currentTimeMillis()<end)Thread.sleep(100);
            if(store.find(a.id)!=null)throw new AssertionError("paused removal failed");
            for(int i=0;i<25;i++){runOnMainSync(()->org.x2.export.DownloadService.command(getTargetContext(),"cancel",b.id));Thread.sleep(50);}
            Thread.sleep(8000);
            if(!b.state.equals("cancelled"))throw new AssertionError("cancel state lost");
            Bundle report=new Bundle();report.putString("result","PAUSE_RESUME_CANCEL_REMOVE_PROCESS_SURVIVED");report.putInt("pid",android.os.Process.myPid());finish(Activity.RESULT_OK,report);return;
        }
        if(mode.equals("reset")){
            DownloadStore store=DownloadStore.get(getTargetContext());
            for(DownloadStore.Job job:store.all())if(job.title.startsWith("任务 ")||job.title.equals("受控测试视频"))store.remove(job);
            Bundle report=new Bundle();report.putString("result","TEST_RECORDS_RESET");finish(Activity.RESULT_OK,report);return;
        }
        if(mode.equals("seed")){
            DownloadStore store=DownloadStore.get(getTargetContext());
            for(String label:options.getString("jobs","A,B,C,D").split(",")){
                String kind=label.equals("E")?"retry":"slow";
                PlayerCapture.Source source=new PlayerCapture.Source(options.getString("server","http://127.0.0.1:18766")+"/"+kind+"/"+label+".mp4?fixture_nonce=BACKGROUND_TEST","X2ControlledBgTest/1.0","",new String[0],options.getString("title","任务 "+label));
                store.add(DownloadStore.playback(getTargetContext(),source));
            }
            Bundle report=new Bundle();report.putString("result","SEEDED_ENCRYPTED_QUEUE");report.putInt("parallel",DownloadConfig.parallel(getTargetContext()));finish(Activity.RESULT_OK,report);return;
        }
        if(mode.equals("diagnostic11"))getUiAutomation();
        Intent launch=new Intent();launch.setClassName(getTargetContext(),options.getString("activity","com.tencent.a.SetupInfoActivity"));launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        final Activity activity=startActivitySync(launch);
        if(mode.equals("diagnostic11")){
            final Class<?> capture=Class.forName("org.x2.export.PlayerCapture");final java.lang.reflect.Method bridge=capture.getDeclaredMethod("testState",boolean.class),metrics=capture.getDeclaredMethod("playbackState");bridge.setAccessible(true);metrics.setAccessible(true);
            String initial=(String)bridge.invoke(null,false);if(!initial.contains("bridge=ready")||!initial.contains("flag=0"))throw new AssertionError("bridge not ready "+initial);
            final Activity settings=startActivitySync(new Intent().setClassName(getTargetContext(),"org.x2.export.DownloadSettingsActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            final View toggle=findText(settings.findViewById(android.R.id.content),"开发测试：禁区入口与本地试看计时");if(!(toggle instanceof android.widget.Switch))throw new AssertionError("development toggle missing");
            runOnMainSync(()->((android.widget.Switch)toggle).setChecked(false));runOnMainSync(()->((android.widget.Switch)toggle).setChecked(true));
            String state=(String)bridge.invoke(null,true);if(!state.contains("flag=1"))throw new AssertionError("setting did not synchronize flag "+state);
            if(activity.hasWindowFocus())throw new AssertionError("main still focused during settings test");
            System.loadLibrary("capturetest");CaptureNative.load(getTargetContext().getApplicationInfo().nativeLibraryDir+"/libmpv.so");
            handle=CaptureNative.create(options.getString("fixture"),"DO_NOT_REPORT_AGENT","",new String[]{"X-Diagnostic-Secret: DO_NOT_REPORT_HEADER"},"DO_NOT_REPORT_TITLE",true);PlayerCapture.register(handle);
            String props="";long end=System.currentTimeMillis()+20000;
            while(System.currentTimeMillis()<end){props=(String)metrics.invoke(null);if(props.contains("pause=1")&&!props.contains("dur=-1"))break;Thread.sleep(100);}
            if(!props.contains("players=1")||!props.contains("pause=1")||props.contains("dur=-1"))throw new AssertionError("MPV numeric state unavailable: "+props);
            Thread.sleep(1600);Class<?> diagnostic=Class.forName("org.x2.export.PlaybackDiagnostics");java.lang.reflect.Method report=diagnostic.getDeclaredMethod("report",android.content.Context.class);report.setAccessible(true);String text=(String)report.invoke(null,getTargetContext());
            if(!text.contains("version=9.9.9-export14")||!text.contains("process=64-bit")||!text.contains("flag=1")||!text.contains("players=1"))throw new AssertionError("diagnostic report incomplete "+text);
            if(text.contains("DO_NOT_REPORT")||text.contains("http://")||text.contains("auth_key")||text.contains("X-Diagnostic-Secret"))throw new AssertionError("diagnostic leaked source data");
            final View copy=findText(settings.findViewById(android.R.id.content),"播放诊断（复制）");if(copy==null)throw new AssertionError("diagnostic button missing");
            final View root=settings.findViewById(android.R.id.content);if(!hasScroll(root))throw new AssertionError("settings must scroll");runOnMainSync(()->copy.performClick());
            boolean clicked=false;end=System.currentTimeMillis()+15000;while(!clicked&&System.currentTimeMillis()<end){android.view.accessibility.AccessibilityNodeInfo window=getUiAutomation().getRootInActiveWindow();if(window!=null)for(android.view.accessibility.AccessibilityNodeInfo node:window.findAccessibilityNodeInfosByText("复制"))if("复制".contentEquals(node.getText())&&node.isClickable()){clicked=node.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK);break;}if(!clicked)Thread.sleep(200);}
            if(!clicked)throw new AssertionError("copy confirmation unavailable");Thread.sleep(300);
            android.content.ClipboardManager clipboard=(android.content.ClipboardManager)getTargetContext().getSystemService(android.content.Context.CLIPBOARD_SERVICE);if(clipboard.getPrimaryClip()==null||!clipboard.getPrimaryClip().getItemAt(0).getText().toString().contains("version=9.9.9-export14"))throw new AssertionError("report not copied");
            PlayerCapture.unregister(handle);CaptureNative.terminate(handle);handle=0;
            Bundle result=new Bundle();result.putString("result","DIAGNOSTIC_SYNC_WITHOUT_MAIN_FOCUS_MPV_METRICS_PRIVACY_AND_CLIPBOARD_PASS");result.putString("numeric_state",props);finish(Activity.RESULT_OK,result);return;
        }
        if(mode.equals("entry8")){
            final View row=activity.findViewById(android.R.id.content).findViewWithTag("x2-download-buttons");
            if(!(row instanceof LinearLayout)||((LinearLayout)row).getChildCount()!=2)throw new AssertionError("production lifecycle missing two buttons");
            ActivityMonitor monitor=addMonitor("org.x2.export.DownloadTasksActivity",null,false);runOnMainSync(()->((LinearLayout)row).getChildAt(1).performClick());Activity manager=waitForMonitorWithTimeout(monitor,30000);removeMonitor(monitor);if(manager==null)throw new AssertionError("production manage button did not open page");
            final View settings=findText(manager.findViewById(android.R.id.content),"下载设置");monitor=addMonitor("org.x2.export.DownloadSettingsActivity",null,false);runOnMainSync(()->settings.performClick());Activity config=waitForMonitorWithTimeout(monitor,15000);removeMonitor(monitor);if(config==null||findText(config.findViewById(android.R.id.content),"更改下载文件夹")==null)throw new AssertionError("folder settings unavailable");
            Bundle report=new Bundle();report.putString("result","PRODUCTION_TWO_BUTTON_MANAGER_AND_SETTINGS_PASS");finish(Activity.RESULT_OK,report);return;
        }
        if(mode.equals("entry7")){
            ActivityMonitor managerMonitor=addMonitor("org.x2.export.DownloadTasksActivity",null,false);
            System.loadLibrary("capturetest");long until=System.currentTimeMillis()+30000;boolean requested=false;
            while(System.currentTimeMillis()<until){if(CaptureNative.requestManager()){requested=true;break;}Thread.sleep(200);}
            if(!requested)throw new AssertionError("libapp not mapped");
            Activity manager=waitForMonitorWithTimeout(managerMonitor,15000);removeMonitor(managerMonitor);
            if(manager==null)throw new AssertionError("initial lifecycle navigation listener missing");
            View row=activity.findViewById(android.R.id.content).findViewWithTag("x2-download-buttons");
            if(row==null||((LinearLayout)row).getChildCount()!=1)throw new AssertionError("initial single download overlay missing");
            final View settingsButton=findText(manager.findViewById(android.R.id.content),"下载设置");
            if(settingsButton==null)throw new AssertionError("manager settings button missing");
            ActivityMonitor settingsMonitor=addMonitor("org.x2.export.DownloadSettingsActivity",null,false);
            runOnMainSync(()->settingsButton.performClick());Activity settings=waitForMonitorWithTimeout(settingsMonitor,10000);removeMonitor(settingsMonitor);
            if(settings==null||findText(settings.findViewById(android.R.id.content),"更改下载文件夹")==null)throw new AssertionError("settings page not shown");
            final Activity closeSettings=settings,closeManager=manager;runOnMainSync(()->{closeSettings.finish();closeManager.finish();});waitForIdleSync();Thread.sleep(800);
            final View firstRow=activity.findViewById(android.R.id.content).findViewWithTag("x2-download-buttons");
            final boolean[] menu={false};runOnMainSync(()->menu[0]=((LinearLayout)firstRow).getChildAt(0).performLongClick());waitForIdleSync();Thread.sleep(300);
            if(!menu[0]||firstRow.hasWindowFocus())throw new AssertionError("long press backup menu not shown");
            settingsMonitor=addMonitor("org.x2.export.DownloadSettingsActivity",null,false);
            sendKeyDownUpSync(android.view.KeyEvent.KEYCODE_DPAD_DOWN);sendKeyDownUpSync(android.view.KeyEvent.KEYCODE_DPAD_DOWN);sendKeyDownUpSync(android.view.KeyEvent.KEYCODE_ENTER);
            Activity backupSettings=waitForMonitorWithTimeout(settingsMonitor,10000);removeMonitor(settingsMonitor);
            if(backupSettings==null||findText(backupSettings.findViewById(android.R.id.content),"更改下载文件夹")==null)throw new AssertionError("long press settings item failed");
            final Activity closeBackup=backupSettings;runOnMainSync(()->closeBackup.finish());waitForIdleSync();Thread.sleep(400);
            runOnMainSync(()->((android.view.ViewGroup)firstRow.getParent()).removeView(firstRow));Thread.sleep(1000);
            managerMonitor=addMonitor("org.x2.export.DownloadTasksActivity",null,false);CaptureNative.requestManager();
            manager=waitForMonitorWithTimeout(managerMonitor,12000);removeMonitor(managerMonitor);
            if(manager==null)throw new AssertionError("navigation stopped after overlay detached");
            final Activity detachedManager=manager;runOnMainSync(()->detachedManager.finish());waitForIdleSync();Thread.sleep(600);
            if(activity.findViewById(android.R.id.content).findViewWithTag("x2-download-buttons")==null)throw new AssertionError("onResume did not restore overlay");
            Bundle report=new Bundle();report.putString("result","INITIAL_ENTRY_SETTINGS_LONG_PRESS_AND_DETACHED_RECOVERY_PASS");finish(Activity.RESULT_OK,report);return;
        }
        if(mode.equals("controls6")){
            runOnMainSync(()->content(activity));
            long until=System.currentTimeMillis()+30000;boolean mapped=false;
            System.loadLibrary("capturetest");while(System.currentTimeMillis()<until){if(CaptureNative.requestManager()){mapped=true;break;}Thread.sleep(200);}
            if(!mapped)throw new AssertionError("libapp not mapped");
            PlayerCapture.manageRequested(false);
            runOnMainSync(()->{content(activity);ExportEntry.install(activity);});waitForIdleSync();Thread.sleep(500);
            View row=activity.findViewById(android.R.id.content).findViewWithTag("x2-download-buttons");
            if(((LinearLayout)row).getChildCount()!=1)throw new AssertionError("floating manager still present");
            ActivityMonitor monitor=addMonitor("org.x2.export.DownloadTasksActivity",null,false);
            CaptureNative.requestManager();Activity manager=waitForMonitorWithTimeout(monitor,15000);removeMonitor(monitor);
            if(manager==null)throw new AssertionError("left tab event did not open manager");
            Bundle report=new Bundle();report.putString("result","SINGLE_DOWNLOAD_AND_MANAGER_BRIDGE_PASS");finish(Activity.RESULT_OK,report);return;
        }
        if(mode.equals("drag")){
            getTargetContext().getSharedPreferences("x2-overlay-position",0).edit().clear().commit();
            final ScrollView[] scroll=new ScrollView[1];
            runOnMainSync(()->{scroll[0]=content(activity);ExportEntry.install(activity);});
            waitForIdleSync();Thread.sleep(500);
            View row=activity.findViewById(android.R.id.content).findViewWithTag("x2-download-buttons");int[] location=new int[2];row.getLocationOnScreen(location);
            float oldX=row.getX(),oldY=row.getY();float x=location[0]+row.getWidth()/4f,y=location[1]+row.getHeight()/2f;
            swipe(x,y,x-100,y+250);waitForIdleSync();Thread.sleep(300);
            float newX=row.getX(),newY=row.getY();
            if(Math.abs(newX-oldX)<50||Math.abs(newY-oldY)<100)throw new AssertionError("buttons did not drag");
            if(scroll[0].getScrollY()!=0)throw new AssertionError("drag scrolled underlying page");
            if(!row.hasWindowFocus())throw new AssertionError("drag triggered a click/dialog");
            runOnMainSync(()->{scroll[0]=content(activity);ExportEntry.install(activity);});waitForIdleSync();Thread.sleep(500);
            row=activity.findViewById(android.R.id.content).findViewWithTag("x2-download-buttons");
            if(Math.abs(newX-row.getX())>2||Math.abs(newY-row.getY())>2)throw new AssertionError("position not restored");
            swipe(30,620,30,280);waitForIdleSync();Thread.sleep(200);int after=scroll[0].getScrollY();if(after<=0)throw new AssertionError("uncovered page cannot scroll");
            ActivityMonitor monitor=addMonitor("org.x2.export.DownloadTasksActivity",null,false);
            row.getLocationOnScreen(location);tap(location[0]+row.getWidth()*3f/4,location[1]+row.getHeight()/2f);
            Activity manager=waitForMonitorWithTimeout(monitor,15000);removeMonitor(monitor);if(manager==null)throw new AssertionError("management tap after drag did not open manager");
            Bundle report=new Bundle();report.putString("result","DRAG_PERSIST_AND_MANAGE_PASS");report.putFloat("x",newX);report.putFloat("y",newY);report.putInt("uncovered_page_scroll",after);finish(Activity.RESULT_OK,report);return;
        }
        System.loadLibrary("capturetest");CaptureNative.load(getTargetContext().getApplicationInfo().nativeLibraryDir+"/libmpv.so");String uri=options.getString("fixture");
        handle=CaptureNative.create(uri,"X2ControlledUiTest/1.0","",new String[0],"受控测试视频",false);PlayerCapture.register(handle);
        long deadline=System.currentTimeMillis()+30000;boolean ready=false;
        while(System.currentTimeMillis()<deadline){try{if(uri.equals(PlayerCapture.snapshot().uri)){ready=true;break;}}catch(java.io.IOException e){}Thread.sleep(100);}
        if(!ready)throw new IllegalStateException("controlled playback not ready");
        Bundle report=new Bundle();report.putString("result","CONTROLLED_PLAYER_READY");sendStatus(1,report);Thread.sleep(240000);
        PlayerCapture.unregister(handle);CaptureNative.terminate(handle);handle=0;finish(Activity.RESULT_OK,report);
    }catch(Throwable error){if(handle!=0){PlayerCapture.unregister(handle);CaptureNative.terminate(handle);}Bundle report=new Bundle();report.putString("failure",error.getClass().getSimpleName()+": "+error.getMessage());finish(Activity.RESULT_CANCELED,report);}}
    private boolean clickAccessible(String label,long timeout)throws Exception{long end=System.currentTimeMillis()+timeout;do{android.view.accessibility.AccessibilityNodeInfo window=getUiAutomation().getRootInActiveWindow();if(window!=null)for(android.view.accessibility.AccessibilityNodeInfo node:window.findAccessibilityNodeInfosByText(label))if(label.contentEquals(node.getText())){android.view.accessibility.AccessibilityNodeInfo click=node;while(click!=null&&!click.isClickable())click=click.getParent();if(click!=null&&click.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK))return true;}Thread.sleep(100);}while(System.currentTimeMillis()<end);return false;}
    private android.net.Uri createDeleteFixture(String title)throws Exception{android.net.Uri tree=android.net.Uri.parse(DownloadConfig.folder(getTargetContext()));android.net.Uri parent=android.provider.DocumentsContract.buildDocumentUriUsingTree(tree,android.provider.DocumentsContract.getTreeDocumentId(tree));android.net.Uri uri=android.provider.DocumentsContract.createDocument(getTargetContext().getContentResolver(),parent,"video/mp4",title+"-"+System.nanoTime()+".mp4");try(java.io.OutputStream out=getTargetContext().getContentResolver().openOutputStream(uri)){out.write(new byte[]{0,0,0,24,102,116,121,112,109,112,52,50});}return uri;}
    private DownloadStore.Job savedJob(DownloadStore store,String title,android.net.Uri document)throws Exception{DownloadStore.Job job=DownloadStore.playback(getTargetContext(),new PlayerCapture.Source("https://fixture.invalid/not-requested.mp4","","",new String[0],title));job.state="success";job.stage="已保存 MP4";job.document=document.toString();job.source=null;store.add(job);return job;}
    private boolean documentExists(android.net.Uri uri)throws Exception{try(java.io.InputStream in=getTargetContext().getContentResolver().openInputStream(uri)){return in!=null;}catch(java.io.FileNotFoundException e){return false;}}
    private void awaitRemoved(DownloadStore store,String id)throws Exception{long end=System.currentTimeMillis()+20000;while(store.find(id)!=null&&System.currentTimeMillis()<end)Thread.sleep(100);if(store.find(id)!=null)throw new AssertionError("record removal timed out "+store.find(id).stage);}
    private boolean hasScroll(View root){if(root instanceof ScrollView)return true;if(root instanceof android.view.ViewGroup){android.view.ViewGroup g=(android.view.ViewGroup)root;for(int i=0;i<g.getChildCount();i++)if(hasScroll(g.getChildAt(i)))return true;}return false;}
    private Object field(Object target,String name)throws Exception{java.lang.reflect.Field f=target.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(target);}
    private Object fieldUnchecked(Object target,String name){try{return field(target,name);}catch(Exception e){throw new RuntimeException(e);}}
    private int position(android.widget.ListView list,String title){for(int i=0;i<list.getAdapter().getCount();i++)try{if(title.equals(field(list.getAdapter().getItem(i),"title")))return i;}catch(Exception ignored){}return -1;}
    private View findText(View root,String text){if(root instanceof TextView&&text.contentEquals(((TextView)root).getText()))return root;if(root instanceof android.view.ViewGroup){android.view.ViewGroup g=(android.view.ViewGroup)root;for(int i=0;i<g.getChildCount();i++){View found=findText(g.getChildAt(i),text);if(found!=null)return found;}}return null;}
    private void awaitState(DownloadStore.Job job,String expected)throws Exception {long end=System.currentTimeMillis()+20000;while(System.currentTimeMillis()<end){if(job.state.equals(expected))return;Thread.sleep(100);}throw new AssertionError("expected "+expected+" got "+job.state+" / "+job.stage);}
    private ScrollView content(Activity activity){ScrollView view=new ScrollView(activity);LinearLayout column=new LinearLayout(activity);column.setOrientation(1);
        for(int i=0;i<100;i++){TextView text=new TextView(activity);text.setText("相关测试视频 "+i);text.setTextSize(20);text.setHeight(110);column.addView(text);}view.addView(column);activity.setContentView(view);return view;}
    private void tap(float x,float y){long now=SystemClock.uptimeMillis();MotionEvent event=MotionEvent.obtain(now,now,MotionEvent.ACTION_DOWN,x,y,0);event.setSource(android.view.InputDevice.SOURCE_TOUCHSCREEN);sendPointerSync(event);event.recycle();event=MotionEvent.obtain(now,now+60,MotionEvent.ACTION_UP,x,y,0);event.setSource(android.view.InputDevice.SOURCE_TOUCHSCREEN);sendPointerSync(event);event.recycle();}
    private void swipe(float x,float y,float endX,float endY){long down=SystemClock.uptimeMillis();MotionEvent event=MotionEvent.obtain(down,down,MotionEvent.ACTION_DOWN,x,y,0);event.setSource(android.view.InputDevice.SOURCE_TOUCHSCREEN);sendPointerSync(event);event.recycle();
        for(int i=1;i<=8;i++){SystemClock.sleep(25);long now=SystemClock.uptimeMillis();event=MotionEvent.obtain(down,now,i==8?MotionEvent.ACTION_UP:MotionEvent.ACTION_MOVE,x+(endX-x)*i/8,y+(endY-y)*i/8,0);event.setSource(android.view.InputDevice.SOURCE_TOUCHSCREEN);sendPointerSync(event);event.recycle();}}
}
