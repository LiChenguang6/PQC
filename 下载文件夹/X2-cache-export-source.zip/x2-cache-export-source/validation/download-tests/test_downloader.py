from pathlib import Path
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
import collections
import contextlib
import hashlib
import json
import shutil
import ssl
import subprocess
import threading
import time
import urllib.parse

BASE = Path('/workspace/x2-analysis')
ROOT = BASE / 'download-tests'
WORK = ROOT / 'work'
WORK.mkdir(exist_ok=True)
CLASSES = ROOT / 'classes'
SEG = [(BASE / f'test-cache/clear/seg00{i}.ts').read_bytes() for i in range(2)]
ENC = [(BASE / f'test-cache/encrypted/seg00{i}.ts').read_bytes() for i in range(2)]
MP4 = (BASE / 'test-cache/reference/clear.mp4').read_bytes()
KEY = (BASE / 'test-cache/encrypted/enc.key').read_bytes()
requests = []
counts = collections.Counter()


def playlist(prefix='', encrypted=False, extra='', end=True, same_names=False):
    key = '#EXT-X-KEY:METHOD=AES-128,URI="../keys/key?sig=K%2Bv",IV=0x1234567890abcdef1234567890abcdef\n' if encrypted else ''
    names = ['a/chunk.ts', 'b/chunk.ts'] if same_names else ['seg000.ts?path=a%2Fb&token=T%2Bv', 'seg001.ts?token=T%2Bv']
    return (' \n\t#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-MEDIA-SEQUENCE:7\n#EXT-X-TARGETDURATION:1\n'
            + extra + key + '#EXTINF:1.000,\n' + prefix + names[0] + '\n#EXTINF:1.000,\n' + prefix + names[1] + '\n'
            + ('#EXT-X-ENDLIST\n' if end else '')).encode()


class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    def log_message(self, *args):
        pass
    def send(self, body=b'', status=200, headers=None, length=None):
        self.send_response(status)
        self.send_header('Content-Length', str(len(body) if length is None else length))
        self.send_header('Connection', 'close')
        for k, v in (headers or {}).items(): self.send_header(k, v)
        self.end_headers()
        if body:
            with contextlib.suppress(BrokenPipeError, ConnectionResetError): self.wfile.write(body)
        self.close_connection = True
    def do_GET(self):
        requests.append({'path': self.path, 'host': self.headers.get('Host'), 'headers': dict(self.headers)})
        parsed = urllib.parse.urlsplit(self.path)
        path = parsed.path
        counts[path] += 1
        if path == '/redirect-start':
            return self.send(status=302, headers={'Location': '/final/authPath?auth_key=AUTHSECRET'})
        if path == '/queryredirect':
            if 'phase=final' not in parsed.query:
                return self.send(status=302, headers={'Location': '?auth_key=AUTHSECRET&phase=final'})
            return self.send(MP4)
        if path == '/crossredirect':
            return self.send(status=302, headers={'Location': f'http://localhost:{self.server.server_port}/cross-direct?auth_key=AUTHSECRET',
                                                 'Set-Cookie': 'samehost=JARSECRET; Path=/'})
        if path == '/cross-direct':
            return self.send(MP4)
        if path == '/final/authPath':
            return self.send(playlist(), headers={'Content-Type': 'application/octet-stream',
                                                  'Set-Cookie': 'hls_session=JARSECRET; Path=/final; HttpOnly'})
        if path.startswith('/final/seg'):
            if self.headers.get('Authorization') != 'Bearer AUTHSECRET' or 'hls_session=JARSECRET' not in self.headers.get('Cookie', ''):
                return self.send(status=403)
            return self.send(SEG[0 if path.endswith('000.ts') else 1])
        if path == '/encrypted/authPath': return self.send(playlist(encrypted=True))
        if path == '/keys/key': return self.send(KEY)
        if path.startswith('/encrypted/seg'): return self.send(ENC[0 if path.endswith('000.ts') else 1])
        if path == '/same/authPath': return self.send(playlist(same_names=True))
        if path == '/same/a/chunk.ts': return self.send(SEG[0])
        if path == '/same/b/chunk.ts': return self.send(SEG[1])
        if path == '/direct': return self.send(MP4, headers={'Content-Type': 'video/mp4'})
        if path == '/master':
            return self.send(b'#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=100,CODECS="avc1.42E01E,mp4a.40.2"\nlow.m3u8\n#EXT-X-STREAM-INF:BANDWIDTH=1000,CODECS="avc1.42E01E,mp4a.40.2"\nmaster-high/authPath?auth_key=AUTHSECRET\n')
        if path == '/master-high/authPath': return self.send(playlist(prefix='../same/', same_names=True))
        if path == '/master-separate':
            return self.send(b'#EXTM3U\n#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="audio",URI="never-audio.m3u8"\n#EXT-X-STREAM-INF:BANDWIDTH=1000,AUDIO="audio"\nnever-video.m3u8\n')
        if path == '/live': return self.send(playlist(prefix='/never/', end=False))
        if path == '/range': return self.send(playlist(prefix='/never/', extra='#EXT-X-BYTERANGE:10@0\n'))
        if path == '/map': return self.send(playlist(prefix='/never/', extra='#EXT-X-MAP:URI="init.mp4"\n'))
        if path == '/drm': return self.send(playlist(prefix='/never/', extra='#EXT-X-KEY:METHOD=SAMPLE-AES,URI="https://invalid/key"\n'))
        if path == '/bad-key':
            return self.send(playlist(prefix='/never/', extra='#EXT-X-KEY:METHOD=AES-128,URI="bad-key-data"\n'))
        if path == '/bad-key-data': return self.send(b'X' * 17)
        if path == '/file-key':
            return self.send(playlist(prefix='/never/', extra='#EXT-X-KEY:METHOD=AES-128,URI="file:///etc/passwd"\n'))
        if path == '/forbidden': return self.send(b'private', status=403)
        if path == '/partial': return self.send(MP4[:100], status=206)
        if path == '/truncated': return self.send(MP4[:100], length=1000)
        if path == '/html': return self.send(b'<!DOCTYPE html><html>login</html>', headers={'Content-Type': 'text/html'})
        if path == '/retry': return self.send(playlist(prefix='/retry-segs/'))
        if path.startswith('/retry-segs/'):
            if counts[path] == 1: return self.send(status=503)
            return self.send(SEG[0 if path.endswith('000.ts') else 1])
        if path == '/slow':
            self.send_response(200); self.send_header('Content-Length', '10485760'); self.end_headers()
            for _ in range(160):
                try: self.wfile.write(b'x' * 65536); self.wfile.flush()
                except (BrokenPipeError, ConnectionResetError): break
                time.sleep(.02)
            self.close_connection = True
            return
        if path == '/stall':
            self.send_response(200); self.send_header('Content-Length', '100000'); self.end_headers()
            time.sleep(3)
            self.close_connection = True
            return
        return self.send(status=404)


def run_case(server, name, path, success=True, mode='normal', https=False):
    folder = WORK / name
    shutil.rmtree(folder, ignore_errors=True)
    url = f'{"https" if https else "http"}://127.0.0.1:{server.server_port}{path}'
    start = time.monotonic()
    run = subprocess.run(['java', '-cp', str(CLASSES), 'DownloadMain', mode, url, str(folder)], text=True, capture_output=True, timeout=25)
    elapsed = time.monotonic() - start
    assert (run.returncode == 0) == success, (name, run.stdout, run.stderr)
    assert 'AUTHSECRET' not in run.stdout + run.stderr and 'REFSECRET' not in run.stdout + run.stderr and 'HEADERSECRET' not in run.stdout + run.stderr
    result = {'case': name, 'success': success, 'seconds': round(elapsed, 3)}
    if success:
        fields = run.stdout.strip().split('\t')
        target = Path(fields[2])
        assert target.is_file() and not target.name.endswith('.part')
        result['duration'] = float(fields[1])
        result['input'] = str(target.relative_to(ROOT))
        result['_target'] = target
    else:
        result['error'] = run.stdout.strip()
        assert not list(folder.rglob('*.part')), name
    return result


server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
threading.Thread(target=server.serve_forever, daemon=True).start()
results = []
try:
    direct = run_case(server, 'direct-mp4', '/direct')
    assert direct['_target'].read_bytes() == MP4 and direct['duration'] == -1
    results.append(direct)
    redirect = run_case(server, 'redirect-final-base-cookie-query', '/redirect-start?auth_key=AUTHSECRET')
    local = redirect['_target'].read_text()
    assert '#EXT-X-MEDIA-SEQUENCE:7' in local and 'http://' not in local and 'https://' not in local
    assert any(r['path'] == '/final/seg000.ts?path=a%2Fb&token=T%2Bv' for r in requests)
    results.append(redirect)
    results.append(run_case(server, 'query-only-redirect', '/queryredirect?old=1'))
    assert any(r['path'] == '/queryredirect?auth_key=AUTHSECRET&phase=final' for r in requests)
    cross = run_case(server, 'cross-origin-credentials-stripped', '/crossredirect')
    request = next(r for r in requests if r['path'].startswith('/cross-direct'))
    lowered = {k.lower(): v for k, v in request['headers'].items()}
    assert 'authorization' not in lowered and 'x-auth' not in lowered and 'cookie' not in lowered
    assert lowered['user-agent'] == 'X2-Test-UA' and 'REFSECRET' not in lowered.get('referer', '')
    results.append(cross)
    encrypted = run_case(server, 'aes128-explicit-iv', '/encrypted/authPath?auth_key=AUTHSECRET')
    text = encrypted['_target'].read_text()
    assert 'IV=0x1234567890abcdef1234567890abcdef' in text and '#EXT-X-MEDIA-SEQUENCE:7' in text
    output = encrypted['_target'].parent / 'verified.mp4'
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-allowed_extensions', 'ALL', '-protocol_whitelist', 'file,crypto,data', '-i', str(encrypted['_target']), '-c', 'copy', str(output)], check=True)
    def frame_hash(path):
        out = subprocess.check_output(['ffmpeg', '-v', 'error', '-i', str(path), '-map', '0:v:0', '-f', 'framemd5', '-'], text=True)
        return [line.split(',')[-1].strip() for line in out.splitlines() if line and not line.startswith('#')]
    assert frame_hash(output) == frame_hash(BASE / 'test-cache/reference/encrypted.mp4')
    encrypted['decoded_frames_match_reference'] = True
    results.append(encrypted)
    same = run_case(server, 'same-basename-unique-files', '/same/authPath')
    assert len(set(line for line in same['_target'].read_text().splitlines() if line.startswith('file:'))) == 2
    results.append(same)
    results.append(run_case(server, 'simple-muxed-master', '/master'))
    assert counts['/low.m3u8'] == 0
    for name, path in [('separate-tracks-rejected', '/master-separate'), ('live-rejected', '/live'),
                       ('byterange-rejected', '/range'), ('map-rejected', '/map'), ('drm-rejected', '/drm'),
                       ('wrong-key-length', '/bad-key'), ('file-key-rejected', '/file-key'),
                       ('http403-redacted', '/forbidden?auth_key=AUTHSECRET'), ('http206-rejected', '/partial'),
                       ('truncated-direct', '/truncated'), ('html-rejected', '/html')]:
        results.append(run_case(server, name, path, False))
    assert sum(count for path, count in counts.items() if path.startswith('/never/')) == 0
    assert counts['/never-audio.m3u8'] == counts['/never-video.m3u8'] == 0
    results.append(run_case(server, 'retry-once-503', '/retry'))
    assert counts['/retry-segs/seg000.ts'] == counts['/retry-segs/seg001.ts'] == 2
    results.append(run_case(server, 'header-injection-rejected', '/direct', False, mode='bad-header'))
    results.append(run_case(server, 'cancel-stream-cleanup', '/slow', False, mode='cancel'))
    stall = run_case(server, 'cancel-stalled-read', '/stall', False, mode='cancel-stall')
    assert stall['seconds'] < 5
    results.append(stall)
    cert = ROOT / 'tls-cert.pem'; key = ROOT / 'tls-key.pem'
    subprocess.run(['openssl', 'req', '-x509', '-newkey', 'rsa:2048', '-nodes', '-keyout', str(key), '-out', str(cert), '-days', '1', '-subj', '/CN=localhost'], check=True, capture_output=True)
    tls = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER); context.load_cert_chain(cert, key)
    tls.socket = context.wrap_socket(tls.socket, server_side=True)
    threading.Thread(target=tls.serve_forever, daemon=True).start()
    try: results.append(run_case(tls, 'untrusted-tls-rejected', '/direct?auth_key=AUTHSECRET', False, https=True))
    finally: tls.shutdown(); tls.server_close()
finally:
    server.shutdown(); server.server_close()
for result in results: result.pop('_target', None)
(ROOT / 'results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'passed': len(results), 'results': str(ROOT / 'results.json')}, ensure_ascii=False))
