from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit, parse_qs
import json

BASE = Path('/workspace/x2-analysis')
ROOT = BASE / 'ui-download-tests'
STATE = ROOT / 'failure-mode'
LOG = ROOT / 'results/http-requests.jsonl'
SIGN = 'fixture%2B%2F%3D'


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_GET(self):
        split = urlsplit(self.path)
        case = split.path.split('/')[1]
        query = parse_qs(split.query)
        with LOG.open('a') as output:
            output.write(json.dumps({'path': split.path, 'query': split.query,
                                     'ua': self.headers.get('User-Agent')}) + '\n')
        if STATE.exists() and STATE.read_text().strip() == case:
            self.send_error(403)
            return
        if case not in ('clear', 'aes', 'direct'):
            self.send_error(404)
            return
        if split.path.endswith('/entry'):
            if query.get('auth_key') != ['fixture+/=']:
                self.send_error(401)
                return
            self.send_response(302)
            self.send_header('Location', '/' + case + '/real/' + ('movie' if case == 'direct' else 'manifest')
                             + '?sign=' + SIGN)
            self.end_headers()
            return
        if query.get('sign') != ['fixture+/=']:
            self.send_error(401)
            return
        if case == 'direct':
            body = (BASE / 'capture-tests/fixture/capture-fixture.mp4').read_bytes()
            content_type = 'video/mp4'
        elif split.path.endswith('/manifest'):
            key = '#EXT-X-KEY:METHOD=AES-128,URI="key?sign=' + SIGN + '",IV=0x1234567890abcdef1234567890abcdef\n' if case == 'aes' else ''
            body = ('#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-TARGETDURATION:1\n#EXT-X-MEDIA-SEQUENCE:0\n'
                    + key + '#EXTINF:1.0,\nseg000.ts?sign=' + SIGN + '\n#EXTINF:1.0,\nseg001.ts?sign='
                    + SIGN + '\n#EXT-X-ENDLIST\n').encode()
            # Deliberately omit both the .m3u8 suffix and HLS Content-Type.
            content_type = 'application/octet-stream'
        else:
            filename = split.path.rsplit('/', 1)[-1]
            directory = BASE / 'test-cache' / ('encrypted' if case == 'aes' else 'clear')
            target = directory / ('enc.key' if filename == 'key' else filename)
            if filename not in ('key', 'seg000.ts', 'seg001.ts') or not target.is_file():
                self.send_error(404)
                return
            body = target.read_bytes()
            content_type = 'application/octet-stream'
        self.send_response(200)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass


if __name__ == '__main__':
    STATE.unlink(missing_ok=True)
    LOG.write_text('')
    ThreadingHTTPServer(('127.0.0.1', 18765), Handler).serve_forever()
