from pathlib import Path
import importlib.util
import json
import subprocess
import time

BASE = Path('/workspace/x2-analysis')
ROOT = BASE / 'ui-download-tests'
RESULTS = ROOT / 'results'
spec = importlib.util.spec_from_file_location('ui', BASE / 'runtime-logs/final_ui_test.py')
ui = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ui)
ui.ROOT = RESULTS
SIGN = 'fixture%2B%2F%3D'


def wait_ready(log):
    deadline = time.monotonic() + 60
    while time.monotonic() < deadline:
        text = log.read_text(errors='replace')
        if 'CONTROLLED_PLAYER_READY' in text:
            return
        if 'failure=' in text or 'INSTRUMENTATION_FAILED' in text or 'shortMsg=' in text:
            raise RuntimeError(text)
        time.sleep(1)
    raise RuntimeError('player instrumentation not ready: ' + log.read_text(errors='replace'))


def save_current(case, expire=False):
    ui.adb('shell', 'am', 'force-stop', ui.PKG)
    (ROOT / 'failure-mode').unlink(missing_ok=True)
    log = RESULTS / (case + ('-expired' if expire else '') + '-instrumentation.log')
    with log.open('wb') as output:
        process = subprocess.Popen([ui.ADB, '-s', 'emulator-5554', 'shell', 'am', 'instrument', '-w',
                                    '-e', 'fixture', 'http://127.0.0.1:18765/' + case + '/entry?auth_key=' + SIGN,
                                    'org.x2.uitests/org.x2.uitests.DownloadInstrumentation'], stdout=output, stderr=output)
        try:
            wait_ready(log)
            label = case + ('-expired' if expire else '')
            ui.tap(ui.wait_node(label + '-entry', lambda n: n.get('text') == '保存/导出'))
            ui.tap(ui.wait_node(label + '-menu', lambda n: n.get('text') == '保存当前播放视频'))
            choose = ui.wait_node(label + '-selected', lambda n: n.get('text') == '选择位置并下载 MP4')
            ui.shot(label + '-selected')
            if expire:
                (ROOT / 'failure-mode').write_text(case)
            ui.tap(choose)
            save = ui.wait_node(label + '-document', lambda n: n.get('resource-id') == 'android:id/button1'
                                and n.get('text', '').upper() == 'SAVE')
            nodes = ui.dump(label + '-document')
            filename = next(n.get('text') for n in nodes if n.get('class') == 'android.widget.EditText')
            ui.tap(save)
            outcome = ui.wait_node(label + '-outcome', lambda n: '已保存 MP4' in n.get('text', '')
                                   or ('HTTP ' in n.get('text', '')) or '保存失败' in n.get('text', '')
                                   or '未能保存视频' == n.get('text'), seconds=120)
            ui.shot(label + '-outcome')
            status = outcome.get('text', '')
            remote = '/sdcard/Download/' + filename
            if expire:
                nodes = ui.dump(label + '-failure')
                assert any('HTTP 403' in n.get('text', '') for n in nodes), [n.get('text') for n in nodes]
                absent = ui.adb('shell', 'test', '!', '-e', remote, check=False)
                assert absent.returncode == 0, 'partial SAF document remains'
                temps = ui.adb('shell', 'find', '/data/user/0/' + ui.PKG + '/cache/playback-saves', '-mindepth', '1')
                assert not temps.stdout.strip(), 'private media or keys left behind'
                result = {'case': label, 'rejected': True, 'status': status, 'destination_deleted': True,
                          'temporary_files_deleted': True}
            else:
                assert '已保存 MP4' in status, status
                local = RESULTS / (case + '-downloaded.mp4')
                ui.adb('pull', remote, str(local))
                result = {'case': label, 'saved': True, 'status': status, 'file': local.name,
                          'bytes': local.stat().st_size, 'destination': remote}
            print(json.dumps(result, ensure_ascii=False), flush=True)
            return result
        finally:
            ui.adb('shell', 'am', 'force-stop', ui.PKG)
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.terminate()
                process.wait(timeout=10)
            (ROOT / 'failure-mode').unlink(missing_ok=True)


def main():
    ui.adb('reverse', 'tcp:18765', 'tcp:18765')
    records = []
    for case in ('clear', 'aes', 'direct'):
        records.append(save_current(case))
        (RESULTS / 'ui-results.json').write_text(json.dumps(records, ensure_ascii=False, indent=2))
    records.append(save_current('clear', expire=True))
    (RESULTS / 'ui-results.json').write_text(json.dumps(records, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
