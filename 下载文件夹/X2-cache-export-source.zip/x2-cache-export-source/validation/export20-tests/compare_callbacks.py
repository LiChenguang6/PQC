from pathlib import Path
import sys,json,struct,zipfile
from unicorn import *
from unicorn.arm64_const import *
from unicorn.x86_const import *
B=Path('/workspace/x2-analysis');R=B/'export20-tests';sys.path.insert(0,str(B/'export-patch'))
import patch_scroll,patch_ui,patch_launch_title,patch_tasks_short
N=B/'patch-tools/android-ndk-r28c/toolchains/llvm/prebuilt/linux-x86_64/bin';W=R/'asm';W.mkdir(exist_ok=True);results=[]
for release in ['original','export20']:
 for abi,s in patch_tasks_short.S.items():
  arm=abi=='arm64-v8a'
  with zipfile.ZipFile(B/'input/app.apk') as z:d=z.read('lib/'+abi+'/libapp.so')
  if release=='export20':
   with zipfile.ZipFile(B/'output/X2-cache-export.apk') as z:d=z.read('lib/'+abi+'/libapp.so')
  for enabled in ([0,1] if release=='export20' else [0]):
   for canwatch in [False,True]:
    for seconds in [0,12,19,20,21,25,65,120]:
     u=Uc(UC_ARCH_ARM64 if arm else UC_ARCH_X86,UC_MODE_ARM if arm else UC_MODE_64);u.mem_map(0,0x900000);u.mem_write(0,d);u.mem_map(0x1000000,0x40000);u.mem_map(0x2000000,0x10000)
     heap=0x1000000;stack=0x2008000;controller=heap+0x101;duration=heap+0x1001;player=heap+0x501;null=heap+0x81;thr=heap+0x8000;pool=heap+0x10000;sentinel=0x200f000
     def put(at,v,fmt='Q'):u.mem_write(at,struct.pack('<'+fmt,v))
     put(controller+0x57,null,'I');put(controller+0x47,null+(0x20 if canwatch else 0x30),'I');put(controller+0x1b,player,'I');put(duration+7,seconds*1000000);put(s['buffer']+0x4904,enabled,'I');put(thr+0x48,0);put(thr+0x38,0);put(thr+0x78,null);put(thr+0x80,null+0x20);put(thr+0x88,null+0x30);put(pool+0x3fbf,0x431bde82d7b634db)
     regs={UC_ARM64_REG_X1:controller,UC_ARM64_REG_X2:duration,UC_ARM64_REG_X15:stack,UC_ARM64_REG_X29:stack+0x100,UC_ARM64_REG_X30:sentinel,UC_ARM64_REG_X22:null,UC_ARM64_REG_X26:thr,UC_ARM64_REG_X27:pool,UC_ARM64_REG_X28:0} if arm else {UC_X86_REG_RDI:controller,UC_X86_REG_RSI:duration,UC_X86_REG_RSP:stack,UC_X86_REG_RBP:stack+0x100,UC_X86_REG_R14:thr,UC_X86_REG_R15:pool}
     for k,v in regs.items():u.reg_write(k,v)
     if not arm:put(stack,sentinel)
     funcs={0x397d4c:'pause',0x5d70c4:'seek',0x4ddc2c:'notify'} if arm else {0x399d90:'pause',0x61b494:'seek',0x5523b0:'notify'};calls=[]
     def hook(emu,pc,size,data):
      if pc not in funcs:return
      calls.append(funcs[pc]);emu.reg_write(UC_ARM64_REG_X0 if arm else UC_X86_REG_RAX,null)
      if arm:emu.reg_write(UC_ARM64_REG_PC,emu.reg_read(UC_ARM64_REG_X30))
      else:
       sp=emu.reg_read(UC_X86_REG_RSP);ret=struct.unpack('<Q',emu.mem_read(sp,8))[0];emu.reg_write(UC_X86_REG_RSP,sp+8);emu.reg_write(UC_X86_REG_RIP,ret)
     u.hook_add(UC_HOOK_CODE,hook);u.emu_start(0x70ca18 if arm else 0x620e44,sentinel,count=500)
     expected=['pause','seek','notify'] if seconds>20 and not canwatch else ['notify'];assert calls==expected,(abi,enabled,canwatch,seconds,calls)
     assert struct.unpack('<I',u.mem_read(controller+0x37,4))[0]==duration
     seen,skipped=struct.unpack('<II',u.mem_read(s['buffer']+0x4920,8));assert seen==0 and skipped==0
     results.append(dict(release=release,abi=abi,enabled=enabled,can_watch=canwatch,seconds=seconds,calls=calls))
(R/'pause-results.json').write_text(json.dumps(dict(passed=True,cases=results,real_forbidden_video_over_20_seconds_verified=False),indent=2));print('PASS original/export20 ARM64 and x86_64 playback callbacks: no 12-second timer, permitted playback continues beyond 20 seconds through 120 seconds. Real media not verified.')
