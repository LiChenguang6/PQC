#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")" && pwd)"
ndk="${X2_NDK_ROOT:-$root/../patch-tools/android-ndk-r28c}"
llvm="$ndk/toolchains/llvm/prebuilt/linux-x86_64/bin"
src="$root/source/FFmpeg-n6.0"
abis=("${@:-x86_64}")
for abi in "${abis[@]}"; do
 case "$abi" in
 x86_64) arch=x86_64; cc=x86_64-linux-android24-clang; cpu=x86-64 ;;
 arm64-v8a) arch=aarch64; cc=aarch64-linux-android24-clang; cpu=armv8-a ;;
 armeabi-v7a) arch=arm; cc=armv7a-linux-androideabi24-clang; cpu=armv7-a ;;
 *) echo "Unsupported ABI $abi" >&2; exit 1 ;;
 esac
 mkdir -p "$root/build-$abi" "$root/$abi"
 cd "$root/build-$abi"
 "$src/configure" \
  --prefix="$root/$abi" --arch="$arch" --cpu="$cpu" --target-os=android \
  --enable-cross-compile --cc="$llvm/$cc" --cxx="$llvm/${cc/clang/clang++}" \
  --ar="$llvm/llvm-ar" --ranlib="$llvm/llvm-ranlib" --nm="$llvm/llvm-nm" \
  --strip="$llvm/llvm-strip" --sysroot="$ndk/toolchains/llvm/prebuilt/linux-x86_64/sysroot" \
  --disable-everything --disable-autodetect --disable-network --disable-programs \
  --disable-doc --disable-avdevice --disable-avfilter --disable-swscale \
  --disable-swresample --disable-postproc --disable-asm --disable-debug \
  --disable-shared --enable-static --enable-pic --enable-small \
  --enable-avformat --enable-avcodec --enable-avutil \
  --enable-demuxer=hls,mpegts,mov,aac,h264,hevc \
  --enable-muxer=mp4,mov \
  --enable-decoder=h264,hevc,aac,aac_latm \
  --enable-protocol=file,crypto,data \
  --enable-parser=h264,hevc,aac,aac_latm,ac3,mpegaudio,mpegvideo \
  --enable-bsf=aac_adtstoasc,extract_extradata,h264_mp4toannexb,hevc_mp4toannexb \
  --extra-cflags='-O2 -fvisibility=hidden -ffunction-sections -fdata-sections' \
  --extra-ldflags='-Wl,--gc-sections'
 make -j2
 make install
 cp config.h config_components.h ffbuild/config.mak "$root/$abi/"
done
