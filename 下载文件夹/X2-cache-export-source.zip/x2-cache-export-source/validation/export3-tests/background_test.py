exec(open('/workspace/x2-analysis/export3-tests/first_folder.py').read().split("end=time.monotonic()+60")[0])
import subprocess,hashlib

ui.adb('shell','am','force-stop',ui.PKG)
seed=ui.adb('shell','am','instrument','-w','-e','mode','seed','org.x2.uitests/org.x2.uitests.DownloadInstrumentation',timeout=60).stdout.decode()
(ROOT/'seed.log').write_text(seed);assert 'SEEDED_ENCRYPTED_QUEUE' in seed,seed
ui.adb('shell','am','start','-n',ui.PKG+'/org.x2.export.DownloadTasksActivity')
row=ui.wait_node('queue-D',lambda n:'任务 D ·' in n.get('text',''))
ui.shot('four-tasks')
service=ui.adb('shell','dumpsys','activity','services',ui.PKG).stdout.decode();(ROOT/'foreground-service.txt').write_text(service)
assert 'isForeground=true' in service,service
power=ui.adb('shell','dumpsys','power').stdout.decode();(ROOT/'wake-lock.txt').write_text(power);assert ':downloads' in power
ui.tap(row)
ui.tap(ui.wait_node('remove-queued-D',lambda n:n.get('text')=='删除任务并清理未完成文件'))
ui.tap(ui.wait_node('confirm-remove-D',lambda n:n.get('text')=='删除' and n.get('resource-id')=='android:id/button1'))
ui.tap(ui.wait_node('active-A',lambda n:'任务 A ·' in n.get('text','')))
ui.tap(ui.wait_node('cancel-A',lambda n:n.get('text')=='取消下载'))
ui.wait_node('cancelled-A',lambda n:'任务 A ·' in n.get('text','') and '已取消' in n.get('text',''),seconds=40)
ui.tap(ui.wait_node('remove-active-A-row',lambda n:'任务 A ·' in n.get('text','')))
ui.tap(ui.wait_node('remove-active-A',lambda n:n.get('text')=='删除任务并清理未完成文件'))
ui.tap(ui.wait_node('confirm-remove-A',lambda n:n.get('text')=='删除' and n.get('resource-id')=='android:id/button1'))
ui.adb('shell','input','keyevent','3');ui.adb('shell','input','keyevent','223')
power=ui.adb('shell','dumpsys','power').stdout.decode();(ROOT/'background-screen-state.txt').write_text(power)
assert 'mWakefulness=Asleep' in power or 'mWakefulness=Dozing' in power,power[:1000]
print('HOME_AND_SCREEN_OFF_WITH_FOREGROUND_SERVICE',flush=True)
for label in ['B','C']:(ROOT/('release-'+label)).touch()
end=time.monotonic()+150
while time.monotonic()<end:
 files=ui.adb('shell','find','/sdcard/Download/X2_export3_A','-type','f').stdout.decode().splitlines()
 if len(files)>=3:break
 time.sleep(5)
else:raise RuntimeError('background output files missing: '+str(files))
ui.adb('shell','input','keyevent','224');ui.adb('shell','wm','dismiss-keyguard')
ui.adb('shell','am','start','-n',ui.PKG+'/org.x2.export.DownloadTasksActivity')
for label in ['B','C']:ui.wait_node('done-'+label,lambda n,l=label:'任务 '+l+' ·' in n.get('text','') and '已保存 MP4' in n.get('text',''),seconds=30)
nodes=ui.dump('completed-queue');texts=[n.get('text','') for n in nodes]
assert not any('任务 A ·' in s or '任务 D ·' in s for s in texts),texts
ui.shot('background-completed')
server=json.loads((ROOT/'server-results.json').read_text())
# Server notices a cancelled TCP socket only after its buffered writes fail.
# A brief A/B/C overlap is teardown of A, not a third active worker.
assert server['max_active'] in (2,3),server
starts={e['job']:e['time'] for e in server['events'] if e['kind']=='start'}
finishes={e['job']:e['time'] for e in server['events'] if e['kind']=='finish'}
assert set(starts)=={'A','B','C'} and abs(starts['A']-starts['B'])<2,server
if server['max_active']==3:assert 0<=finishes['A']-starts['C']<5,server
assert not any(e['job']=='D' for e in server['events']),server
for index,remote in enumerate(files):
 local=ROOT/('background-'+str(index)+'.mp4');ui.adb('pull',remote,str(local));subprocess.run(['ffmpeg','-v','error','-i',str(local),'-f','null','-'],check=True,capture_output=True)
raw=ui.adb('exec-out','cat','/data/user/0/'+ui.PKG+'/files/download-queue.enc').stdout
assert raw[:2]==bytes([1,12]) and len(raw)>30
assert b'BACKGROUND_TEST' not in raw and b'127.0.0.1' not in raw
result={'parallel_limit':2,'two_initial_concurrent_transfers':True,'peak_server_connections_including_cancel_teardown':server['max_active'],'queued_task_D_never_fetched':True,'active_A_cancelled_and_removed':True,'B_and_C_completed_with_screen_off':True,'folder_A_mp4_files':len(files),'all_mp4_fully_decode':True,'queue_encrypted':True,'no_instrumentation_during_background_transfer':True}
(ROOT/'background-results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
