from pathlib import Path
import subprocess,json,hashlib,shutil,urllib.request,urllib.parse,time,zipfile
B=Path('/workspace/x2-analysis');R=B/'export10-tests';O=B/'output';G=Path('/workspace/pqc-upload');F='下载文件夹'
def run(*args):return subprocess.check_output(args,text=True).strip()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
info=json.loads((O/'build-info.json').read_text());expected=sha(O/'X2-cache-export.apk');assert expected==info['output_sha256']
for name,key in [('comparison-results.json','apk_sha256'),('flutter-startup-results.json','final_apk_sha256'),('payload-results.json','output_sha256')]:
 d=json.loads((R/name).read_text());assert d[key]==expected,(name,'wrong APK');assert d.get('passed',True)
assert json.loads((R/'getter-results.json').read_text())['passed']
assert json.loads((R/'pause-results.json').read_text())['passed']
subprocess.run(['python3',str(R/'write_docs.py')],check=True)
subprocess.run(['python3',str(B/'export-patch/package_source.py')],check=True)
with zipfile.ZipFile(O/'X2-cache-export-source.zip') as z:
 assert z.testzip() is None
 assert not any(n.endswith('.p12') or n.endswith('.apk') for n in z.namelist())
 assert z.read('x2-cache-export-source/export-patch/patch_tasks_short.py')==(B/'export-patch/patch_tasks_short.py').read_bytes()
 assert json.loads(z.read('x2-cache-export-source/build-info.json'))['output_sha256']==expected
assert not run('git','-C',str(G),'status','--porcelain')
subprocess.run(['git','-C',str(G),'fetch','origin','main'],check=True)
subprocess.run(['git','-C',str(G),'merge','--ff-only','origin/main'],check=True)
names=['X2-cache-export.apk','X2-cache-export-source.zip','使用说明.md','VALIDATION.md']
for name in names:shutil.copy2(O/name,G/F/name)
subprocess.run(['git','-C',str(G),'add','--',*[F+'/'+n for n in names]],check=True)
changed=run('git','-C',str(G),'-c','core.quotepath=false','diff','--cached','--name-only').splitlines();assert set(changed)=={F+'/'+n for n in names},changed
subprocess.run(['git','-C',str(G),'commit','-m','X2 export10 candidate: guard independent player preview pause and rewind'],check=True)
commit=run('git','-C',str(G),'rev-parse','HEAD');subprocess.run(['git','-C',str(G),'push','origin','HEAD:main'],check=True)
result={'commit':commit,'apk_sha256':expected,'source_sha256':sha(O/'X2-cache-export-source.zip'),'verified_raw_downloads':{}}
for name in ['X2-cache-export.apk','X2-cache-export-source.zip']:
 url='https://raw.githubusercontent.com/LiChenguang6/PQC/'+commit+'/'+urllib.parse.quote(F+'/'+name)
 for attempt in range(4):
  try:
   digest=hashlib.sha256();count=0
   with urllib.request.urlopen(url,timeout=60) as response:
    while True:
     chunk=response.read(1024*1024)
     if not chunk:break
     digest.update(chunk);count+=len(chunk)
   assert digest.hexdigest()==sha(O/name),(name,'raw SHA mismatch')
   result['verified_raw_downloads'][name]={'url':url,'sha256':digest.hexdigest(),'bytes':count};break
  except Exception:
   if attempt==3:raise
   time.sleep(3)
(R/'published-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2))
