from prepare_machine import prepare
prepare()
import json,struct,sys
from pathlib import Path
from unicorn import Uc,UC_ARCH_ARM64,UC_ARCH_X86,UC_MODE_ARM,UC_MODE_64
from unicorn.arm64_const import *
from unicorn.x86_const import *
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE.parent/'export-patch'))
from patch_launch_title import SPECS
results=[]
for abi,s in SPECS.items():
 for title in ['中文视频标题😀 第一集','ASCII title','标题?甲=乙/测试','']:
  arm=abi=='arm64-v8a';u=Uc(UC_ARCH_ARM64 if arm else UC_ARCH_X86,UC_MODE_ARM if arm else UC_MODE_64)
  d=(BASE/'asm'/f'{abi}-patched.so').read_bytes();u.mem_map(0,(max(len(d),s['buffer']+0x6000)+0xffff)&~0xffff);u.mem_write(0,d)
  heap=0x1000000;stack=0x2000000;u.mem_map(heap,0x10000);u.mem_map(stack,0x10000)
  controller=heap+0x101;model=heap+0x301;t=heap+0x501;url=heap+0x2001
  uri='https://fixture.invalid/video.m3u8?token=仅测试'
  def string(at,text):
   wide=any(ord(c)>255 for c in text);encoded=text.encode('utf-16le') if wide else text.encode('latin1');length=len(encoded)//(2 if wide else 1)
   u.mem_write(at-1,struct.pack('<I',(95 if wide else 94)<<12));u.mem_write(at+7,struct.pack('<I',length*2));u.mem_write(at+15,encoded)
  string(t,title);string(url,uri);u.mem_write(controller+0x53,struct.pack('<I',model));u.mem_write(model+0x53,struct.pack('<I',t));u.mem_write(controller+0x2b,struct.pack('<I',heap+0x401))
  if arm:
   u.reg_write(UC_ARM64_REG_X0,controller);u.reg_write(UC_ARM64_REG_X28,0);u.reg_write(UC_ARM64_REG_X22,heap+0x9001);u.reg_write(UC_ARM64_REG_X15,stack+0x8000);u.reg_write(UC_ARM64_REG_X29,stack+0x9000)
   u.emu_start(s['entry'],s['entry']+4,count=100000)
   assert u.reg_read(UC_ARM64_REG_X0)==controller
   assert u.reg_read(UC_ARM64_REG_X2)==heap+0x401
   u.reg_write(UC_ARM64_REG_X0,url);u.emu_start(s['end'],s['end']+4,count=100000)
   assert u.reg_read(UC_ARM64_REG_X0)==url
   assert u.reg_read(UC_ARM64_REG_X15)==stack+0x9000
  else:
   u.reg_write(UC_X86_REG_RAX,controller);u.reg_write(UC_X86_REG_R14,heap+0x8000);u.reg_write(UC_X86_REG_RSP,stack+0x8000);u.reg_write(UC_X86_REG_RBP,stack+0x9000)
   u.mem_write(heap+0x8048,struct.pack('<Q',0));u.mem_write(heap+0x8078,struct.pack('<Q',heap+0x9001))
   u.emu_start(s['entry'],s['entry']+7,count=100000)
   assert u.reg_read(UC_X86_REG_RAX)==controller
   assert u.reg_read(UC_X86_REG_RCX)==heap+0x401
   u.reg_write(UC_X86_REG_RAX,url);u.mem_write(stack+0x9000,struct.pack('<QQ',0x1234,stack+0xf000));u.emu_start(s['end'],stack+0xf000,count=100000)
   assert u.reg_read(UC_X86_REG_RAX)==url
   assert u.reg_read(UC_X86_REG_RBP)==0x1234
  tl,ul,seq,magic=struct.unpack('<IIII',u.mem_read(s['buffer'],16));assert seq==2 and magic==0x35543258
  got=bytes(u.mem_read(s['buffer']+16,tl*2)).decode('utf-16le');goturi=bytes(u.mem_read(s['buffer']+2064,ul*2)).decode('utf-16le');assert got==title,(abi,got,title);assert goturi==uri
  results.append({'abi':abi,'title':title,'copied_title_and_exact_url':True,'return_and_registers_preserved':True})
(BASE/'title-machine-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2));print('PASS',len(results),'title+URL machine executions')
