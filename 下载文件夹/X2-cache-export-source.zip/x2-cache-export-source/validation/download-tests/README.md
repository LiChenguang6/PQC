# Captured playback downloader validation

The production component is `export-patch/src/org/x2/export/MediaDownloader.java`. It accepts the already playing MPV URI, captured User-Agent/referrer and individual `"Header: value"` fields. It does not derive application APIs, download permissions, device IDs, signatures or authorization headers.

`Result.input` is a complete local media file or local-only M3U8. `durationSeconds` is the HLS EXTINF sum, or `-1` for direct media requiring native probing. `suggestedName` is the generic `video.mp4` and contains no signed URL data.

Supported network inputs are direct HTTP/HTTPS media, finite media HLS and simple muxed master playlists (highest declared BANDWIDTH). Ordinary AES-128 keys, explicit IVs, media sequence and key changes are retained. MAP, byte ranges, independent audio/subtitle renditions, low-latency/live/incomplete playlists and DRM key formats are explicitly rejected before media transfer.

Requests use default platform TLS certificate/hostname verification. Captured authorization, Cookie and custom fields are sent only to the initial exact origin. Across origins only the captured User-Agent and an origin-only referrer remain; HTTPS-to-HTTP referrers are omitted. A separate per-download CookieManager accepts response cookies under host/domain/path/secure rules; it does not install a global CookieHandler. Transport headers such as Host, connection framing, Range and Accept-Encoding are managed by the downloader. It requests complete identity-encoded objects and rejects unexpected encoded or partial responses.

Limits: 4 MiB per playlist, 20,000 segments, 128 keys, 24 hours EXTINF sum, 256 MiB per HLS segment and 32 GiB transferred overall. Direct media streams to disk with a 64 KiB buffer. Five redirects and three nested master levels are allowed. Keys/segments retry at most once for transient failures; authentication/unsupported-format failures are not retried. `.part` files are never returned as success and are removed on transfer failure. The caller owns cleanup of the work directory and successfully completed intermediate files.

Cancellation checks run before and during transfer, plus a monitor disconnects the active connection. Connect/read timeouts are 10/15 seconds. A stalled JDK read may return only when the server closes or the read timeout expires; cancellation is not promised to be instantaneous.

The 23 cases in `results.json` use an actual local threaded HTTP server and an untrusted local HTTPS server, not mocked connection objects. They cover encoded/query-only redirects, the final response URI as the HLS base, extensionless HLS with leading whitespace, response cookies, credential stripping, direct byte preservation, nonzero MEDIA-SEQUENCE, explicit-IV AES video with frame hashes matching a reference, simple master selection, bounded retries, negative HLS/HTTP cases and cancellation cleanup. They do not establish that the third-party application server was reached or that its real video requests succeeded.

Run in this analysis workspace:

```bash
java -jar ../patch-tools/ecj.jar -source 1.8 -target 1.8 -encoding UTF-8 \
  -bootclasspath ../patch-tools/android-35/android.jar -d classes \
  ../export-patch/src/org/x2/export/MediaDownloader.java DownloadMain.java
python3 test_downloader.py
```

The test script uses the sibling synthetic `test-cache` fixtures and host FFmpeg for independent decoding validation. Test credentials and TLS keys are generated local fixtures; no application account data is used.
