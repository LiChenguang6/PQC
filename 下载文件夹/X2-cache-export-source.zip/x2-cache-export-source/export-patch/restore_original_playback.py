"""Restore exactly four original instruction sites, with before-image assertions.
This is a baseline experiment, not a claim of restoring server entitlements.
"""
import hashlib
from patch_scroll import branch
SITES={'arm64-v8a':[(0x70b420,4,'entering_ad_original_initialization'),(0x6bd490,4,'original_vip_getter'),(0x70c168,4,'original_progress_callback'),(0x70caa0,4,'original_pause_branch')],
       'x86_64':[(0x61f214,5,'entering_ad_original_initialization'),(0x779cc7,5,'original_vip_getter'),(0x620322,5,'original_progress_callback'),(0x620edb,6,'original_pause_branch')]}
def apply(data,original,abi,ui_report,tasks_report):
    if abi not in SITES:return data,{}
    changes={v['offset']:v for v in ui_report+tasks_report['changes']}
    out=bytearray(data);restored=[]
    for at,size,name in SITES[abi]:
        change=changes[at];before=bytes.fromhex(change['after']);assert len(before)==size
        assert data[at:at+size]==before,(abi,name,'unexpected modified input')
        expected=bytes.fromhex(change['before']);assert expected==original[at:at+size],(abi,name,'baseline mismatch')
        out[at:at+size]=expected;restored.append({'name':name,'offset':at,'before':before.hex(),'after':expected.hex()})
    # Preserve the user's working player callbacks; only the entry getter is optional.
    vip=next((at,size,name) for at,size,name in SITES[abi] if name=='original_vip_getter')
    at,size,_=vip;out[at:at+size]=bytes.fromhex(changes[at]['after'])
    ad=next((at,size,name) for at,size,name in SITES[abi] if name=='entering_ad_original_initialization')
    at,size,_=ad;replacement=branch(abi,at,tasks_report['symbols']['ad_entry'],True);assert len(replacement)==size
    out[at:at+size]=replacement
    at=0x6403fc if abi=='arm64-v8a' else 0x6200ac
    expected=bytes.fromhex('02b040b842801c8b' if abi=='arm64-v8a' else '8b480b49034e48')
    assert original[at:at+len(expected)]==expected and data[at:at+len(expected)]==expected,(abi,'permission input mismatch')
    jump=branch(abi,at,tasks_report['symbols']['play_permission_entry'])
    padding=bytes.fromhex('1f2003d5') if abi=='arm64-v8a' else b'\x90'*2
    out[at:at+len(expected)]=jump+padding
    return bytes(out),{'baseline':'original uploaded X2 APK','restored_sites':restored,'conditional_ad_and_vip_entry':True,'output_sha256':hashlib.sha256(out).hexdigest()}
