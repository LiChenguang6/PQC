# Minimal local-cache remux engine

FFmpeg upstream release tag `n6.0`, fetched over certificate-verified HTTPS from the official FFmpeg GitHub mirror:
https://codeload.github.com/FFmpeg/FFmpeg/tar.gz/refs/tags/n6.0

Archive SHA-256:
`9a1fa94608300e835bf89bdfcd7d77deceba67bff3494f609816f84bd69a459e`

`fetch-source.sh` checks that digest before extraction. Original upstream source is unmodified. Build uses Android NDK r28c, API 24, without GPL or nonfree options. Source license files are in `source/FFmpeg-n6.0/COPYING*` and `LICENSE.md`.

Build with:

```bash
./fetch-source.sh
./build.sh x86_64 arm64-v8a armeabi-v7a
```

Each ABI installs public headers in `<abi>/include` and static `libavformat.a`, `libavcodec.a`, `libavutil.a` in `<abi>/lib`. No network protocols or encoders are compiled. H264, HEVC, AAC/AAC-LATM decoders are included only so avformat_find_stream_info can derive track dimensions, channels, and sample rate; exported packets are still copied without transcoding. HLS, MPEGTS, MOV/MP4, raw AAC/H264/HEVC demuxers; MOV/MP4 muxers; file/crypto/data protocols; AAC/H264/HEVC parsers and relevant bitstream filters are explicitly enabled. AES-128 HLS decryption is included by FFmpeg's crypto protocol.

JNI bridge must use its own static FFmpeg engine exclusively. Hide all static library symbols and bind locally using `-fvisibility=hidden -Wl,--exclude-libs,ALL -Wl,-Bsymbolic`. Keep the JNI entry's explicit `JNIEXPORT` default visibility. This avoids interposition by the original app's independently configured libmpv media engine.

Example link tail, after bridge source and include flags:

```
-Wl,--start-group lib/libavformat.a lib/libavcodec.a lib/libavutil.a -Wl,--end-group -lm -llog -Wl,--exclude-libs,ALL -Wl,-Bsymbolic
```

Distribute the original FFmpeg source or exact source-fetch instructions, license texts, bridge source, and relink scripts/object files alongside a distributed statically linked bridge, so LGPL relinking remains possible.
