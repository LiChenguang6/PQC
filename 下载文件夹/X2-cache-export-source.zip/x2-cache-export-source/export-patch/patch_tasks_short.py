"""Pinned, call-free short-title and native task-entry bridge for owned-app testing."""
import hashlib,struct,subprocess
from pathlib import Path
from patch_scroll import branch
from patch_launch_title import arm_asm,x_asm
PINS={'arm64-v8a':'074f16df27f3dbc5e8b7872b45e7c57ed14501274d345f78e36d76e80f1663d3','x86_64':'bf9fb8aab48b04839e833cd0aeedc477266bab828a6f8618d9c34ac93e72165a'}
S={
 'arm64-v8a':dict(buffer=0x8b1000,entry=0x6ba55c,end=0x6ba588,nav=0x591fd8,caption=0x627fb4,vip=0x6bd428,preview=0x70c168,preview_original=0x70c184),
 'x86_64':dict(buffer=0x8c1000,entry=0x777316,end=0x77733a,nav=0x5fc961,caption=0x6cd158,vip=0x779c60,preview=0x620322,preview_original=0x62033c)}
def assembly(abi,s):
 if abi=='arm64-v8a':
  a=arm_asm(s);before='ldur w1,[x0,#0x53]\nadd x1,x1,x28,lsl #32\ncmp w1,w22\nb.eq title_done\nldur w1,[x1,#0x53]\nadd x1,x1,x28,lsl #32';assert before in a
  a=a.replace(before,'ldur w1,[x1,#0x53]\nadd x1,x1,x28,lsl #32').replace('ldur w2,[x0,#0x2b]','ldur w3,[x1,#0x67]')
  addr='adrp x2,title_buffer\nadd x2,x2,:lo12:title_buffer\n'
  first=addr+'add x4,x2,#0x4000\nldr w3,[x4,#0x910]\nadd w3,w3,#1\nstr w3,[x4,#0x910]\nand w3,w3,#3\nmov w4,#0x5000\nmul x3,x3,x4\nadd x4,x2,#0x6000\nadd x4,x4,x3\nstr x4,[x2,#0x4908]\nmov x2,x4\n'
  a=a.replace(addr,first,1)
  at=a.index('end_copy:');a=a[:at]+a[at:].replace(addr,addr+'ldr x2,[x2,#0x4908]\n',1)
  return a+'''
.global nav_entry,caption_entry,vip_entry
nav_entry:
stp x3,x4,[x15,#-16]!
cbnz x2,nav_continue
adrp x3,manage_event
add x3,x3,:lo12:manage_event
mov w4,#1
stlr w4,[x3]
mov x2,#2
stur x2,[x29,#-0x18]
nav_continue:
ldp x3,x4,[x15],#16
ldur w3,[x0,#0x1f]
b nav_resume
caption_entry:
stp x4,x6,[x15,#-16]!
ldur w4,[x5,#7]
cmp w4,#4
b.ne caption_done
ldur w4,[x5,#-1]
lsr w4,w4,#12
cmp w4,#95
b.ne caption_done
ldur w4,[x5,#15]
mov w6,#0x6d3b
movk w6,#0x52a8,lsl #16
cmp w4,w6
b.ne caption_done
add x5,x27,#0x1b000
ldr x5,[x5,#0xd68]
caption_done:
ldp x4,x6,[x15],#16
ldur w3,[x0,#0xf]
b caption_resume
vip_entry:
adrp x16,test_flag
add x16,x16,:lo12:test_flag
ldar w16,[x16]
cbz w16,vip_original
add x0,x22,#0x20
ret
vip_original:
stp x29,x30,[x15,#-16]!
b vip_resume
.global preview_entry
preview_entry:
adrp x16,test_flag
add x16,x16,:lo12:test_flag
ldar w16,[x16]
cbnz w16,preview_skip
b preview_original
preview_skip:
mov x0,x22
ret
'''
 a=x_asm(s);before='movl 0x53(%rax),%edi\naddq 0x48(%r14),%rdi\ncmpq 0x78(%r14),%rdi\nje title_done\nmovl 0x53(%rdi),%edi\naddq 0x48(%r14),%rdi';assert before in a
 a=a.replace(before,'movl 0x53(%rdi),%edi\naddq 0x48(%r14),%rdi').replace('movl 0x2b(%rax),%ecx\naddq 0x48(%r14),%rcx','movl 0x67(%rdi),%edx\naddq 0x48(%r14),%rdx')
 addr='leaq title_buffer(%rip),%r8\n'
 first=addr+'movl 0x4910(%r8),%ecx\nincl %ecx\nmovl %ecx,0x4910(%r8)\nandl $3,%ecx\nimull $0x5000,%ecx\nleaq 0x6000(%r8,%rcx),%rdx\nmovq %rdx,0x4908(%r8)\nmovq %rdx,%r8\n'
 a=a.replace(addr,first,1)
 at=a.index('end_copy:');a=a[:at]+a[at:].replace(addr,addr+'movq 0x4908(%r8),%r8\n',1)
 return a+'''
.global nav_entry,caption_entry,vip_entry
nav_entry:
pushfq
pushq %rcx
testq %rsi,%rsi
jnz nav_continue
leaq manage_event(%rip),%rcx
movl $1,(%rcx)
movq $2,%rsi
movq %rsi,-0x18(%rbp)
nav_continue:
popq %rcx
popfq
movl 0x1f(%rax),%ecx
addq 0x48(%r14),%rcx
jmp nav_resume
caption_entry:
pushfq
pushq %rcx
cmpl $4,7(%rbx)
jne caption_done
movl -1(%rbx),%ecx
shrl $12,%ecx
cmpl $95,%ecx
jne caption_done
cmpl $0x52a86d3b,15(%rbx)
jne caption_done
movq 0x1bee7(%r15),%rbx
caption_done:
popq %rcx
popfq
movl 0xf(%rax),%edx
addq 0x48(%r14),%rdx
jmp caption_resume
vip_entry:
cmpl $0,test_flag(%rip)
je vip_original
movq 0x80(%r14),%rax
movq %rbp,%rsp
popq %rbp
ret
vip_original:
cmpq 0x38(%r14),%rsp
jbe vip_overflow
jmp vip_resume
.global preview_entry
preview_entry:
cmpl $0,test_flag(%rip)
je preview_original
movq 0x78(%r14),%rax
ret
'''
def apply(data,abi,ndk,work):
 if abi not in S:return data,None
 assert hashlib.sha256(data).hexdigest()==PINS[abi]
 s=S[abi];buf=bytearray(data);work=Path(work);work.mkdir(exist_ok=True,parents=True)
 ph=struct.unpack_from('<Q',buf,32)[0];n=struct.unpack_from('<H',buf,56)[0]
 for i in range(n):
  p=ph+56*i;t,f,o,v,pa,fs,ms,align=struct.unpack_from('<IIQQQQQQ',buf,p)
  if t==1 and f==5:rx=p;cave=(v+fs+15)&~15
  if t==1 and f==6:rwva=v;rw=p
 arm=abi=='arm64-v8a';width=4 if arm else 7
 asm=work/(abi+'.S');obj=work/(abi+'.o');elf=work/(abi+'.elf');raw=work/(abi+'.bin');asm.write_text(assembly(abi,s))
 compiler='aarch64-linux-android24-clang' if arm else 'x86_64-linux-android24-clang'
 subprocess.run([str(Path(ndk)/compiler),'-c',str(asm),'-o',str(obj)],check=True)
 syms=dict(title_buffer=s['buffer'],entry_resume=s['entry']+width,end_resume=s['end']+4,nav_resume=s['nav']+width,caption_resume=s['caption']+width,vip_resume=s['vip']+width,manage_event=s['buffer']+0x4900,test_flag=s['buffer']+0x4904)
 syms['preview_original']=s['preview_original']
 if arm:syms['vip_resume']=s['vip']+4
 else:
  syms['vip_resume']=s['vip']+10
  syms['vip_overflow']=s['vip']+10+struct.unpack_from('<i',data,s['vip']+6)[0]
 subprocess.run([str(Path(ndk)/'ld.lld'),'-Ttext='+hex(cave),'-e','entry_copy',*['--defsym='+k+'='+hex(v) for k,v in syms.items()],str(obj),'-o',str(elf)],check=True)
 subprocess.run([str(Path(ndk)/'llvm-objcopy'),'--only-section=.text','-O','binary',str(elf),str(raw)],check=True)
 code=raw.read_bytes();assert cave+len(code)<rwva and not any(buf[cave:cave+len(code)])
 symbols={l.split()[2]:int(l.split()[0],16) for l in subprocess.check_output([str(Path(ndk)/'llvm-nm'),str(elf)],text=True).splitlines() if len(l.split())==3}
 expected={'arm64-v8a':dict(entry='237046b8',end='ef031daa',nav='03f041b8',caption='03f040b8',vip='fd79bfa9'),'x86_64':dict(entry='8b576749035648',end='4889ec5dc3',nav='8b481f49034e48',caption='8b500f49035648',vip='493b6638')}
 changes=[]
 for key,label in [('entry','entry_copy'),('end','end_copy'),('nav','nav_entry'),('caption','caption_entry'),('vip','vip_entry')]:
  at=s[key];before=bytes.fromhex(expected[abi][key]);assert data[at:at+len(before)]==before,(abi,key,data[at:at+len(before)].hex())
  if not arm and key=='vip':
   # Four-byte cmp plus six-byte conditional branch: retain original branch in cave.
   before=data[at:at+10];assert before[:4]==bytes.fromhex('493b6638')
  jump=branch(abi,at,symbols[label]);replacement=jump+(bytes.fromhex('1f2003d5')*((len(before)-len(jump))//4) if arm else b'\x90'*(len(before)-len(jump)))
  assert len(replacement)==len(before);buf[at:at+len(before)]=replacement;changes.append(dict(name=key,offset=at,before=before.hex(),after=replacement.hex()))
 at=s['preview'];before=branch(abi,at,s['preview_original'],call=True);assert data[at:at+len(before)]==before
 replacement=branch(abi,at,symbols['preview_entry'],call=True);buf[at:at+len(before)]=replacement
 changes.append(dict(name='preview_timer_test_guard',offset=at,before=before.hex(),after=replacement.hex()))
 struct.pack_into('<Q',buf,rw+40,0x20000)
 end=cave+len(code);struct.pack_into('<QQ',buf,rx+32,end-0x340000,end-0x340000);buf[cave:end]=code
 return bytes(buf),dict(cave=cave,code_size=len(code),changes=changes,symbols=symbols,output_sha256=hashlib.sha256(buf).hexdigest())
