# X2社保存导出版补丁源码

本补丁保留原 APK 的 Flutter 浏览、播放和下载业务，在界面内增加“保存/导出”入口：可以从正在播放的视频地址下载并保存 MP4，也可以导出本副本已经完成的普通 HLS 缓存。不重新编码，不修改原 Flutter AOT 业务。

## 安装与使用

1. 安装生成的 `X2-cache-export.apk`。新版名称为“X2社·保存导出版”，包名仍为 `com.example.yinqishe_export`，版本码 10。可直接更新此前导出版，不用卸载原版或导出版。
2. 在导出版中按原有流程登录、刷视频，开始播放需要保存的视频。
3. 点击原界面右侧可拖动的“保存/导出”按钮，选择“保存当前播放视频”。
4. 选择保存位置，等待下载、合并和验证完成。此入口不依赖原来的下载按钮先完成缓存。
5. 对已有缓存，选择“导出已下载缓存”，刷新列表并按视频 ID 选择，再通过系统窗口保存。
6. 保持保存页打开，等待“已保存 MP4”，再用文件管理器或播放器打开、分享。

导出版与原版可以并存，签名和数据目录彼此独立。原版账号状态与私有缓存不迁移，需要在导出版正常登录和播放。新签名不能覆盖原签名；不要为安装本补丁卸载原版而丢失数据。此前导出版所用的开发签名保留，更新该副本会保留其数据。

用户报告的原下载按钮“下载失败”尚无唯一已证实根因；播放与下载是不同接口，旧按钮的错误仍可能出现。新增入口复用播放器实际取得的 HTTP(S) 地址与请求配置，进行独立的正常媒体下载；不构造业务令牌、模拟设备身份或修改权限判定。平台实际连通性仍需单独验证。

## 实现与范围

- `libx2player.so` 通过原 media_kit 的 Create/Dispose 生命周期建立独立 MPV weak client，只读原播放器属性，不修改原播放器库或消费 Dart 的事件队列。仅接受实际加载、有 `time-pos` 且未暂停的唯一 HTTP(S) 播放器；多播放器、切换中、未完成加载或不支持的本地源会明确拒绝。
- 点击入口时在后台线程即时读取地址、User-Agent、Referer 和原始 header 数组，保留 query。地址和请求凭据仅在进程内传递，不放入 Intent、不写日志或诊断文件。原本地缓存服务会引导至缓存导出，保留原始 IV 处理。
- `MediaDownloader` 使用 Android HttpURLConnection，保留 TLS 校验，跟随有限重定向并以最终 URI 解析相对引用；支持无后缀 HLS、普通有限媒体清单、AES-128 及简单复用音视频的 master variant。使用独立 CookieManager，捕获的鉴权头仅在原 origin 使用；不修改全局 CookieHandler。
- 下载失败显示阶段和 HTTP 状态，不输出签名 query 或密钥。临时媒体和密钥在保存、失败或取消后删除；失败时删除系统目标文档。直接媒体要求可探测时长，仍校验输出轨道、编码和完整时长。
- 静态确认缓存位于 `Context.getDir("flutter", 0)/downloads/video/<videoId>`。
- `index.m3u8` 是完成标记；导出优先读取 `index.raw.m3u8`，保留原 `IV`、`MEDIA-SEQUENCE` 和分片顺序，再把媒体与密钥映射为同一缓存目录的本地文件。
- `enc.key` 为普通 AES-128 HLS 的本地 16 字节密钥；不解析加密 Hive 记录库，不访问其他应用数据。
- 通过 `libx2export.so` 内静态链接的最小 FFmpeg 6.0 本地媒体处理组件，进行流复制、必要的自动位流过滤和 MP4 封装。它不启用网络协议；符号隐藏并绑定在本组件内部，避免与原 `libmpv.so` 的 FFmpeg 冲突。全部原有原生媒体库原字节保持不变。
- 原 APK 的 `libmpv.so` 没有编译 MP4 封装器，因此仅调用它的导出符号不能完成本任务；已依据实际 Android 运行测试选择独立最小封装组件。
- 已有缓存导出对缺文件、空分片、缺密钥、错误密钥长度、路径越界、同名分片冲突、主清单、独立音轨、byterange、密钥轮换与不支持的加密方式明确拒绝。播放源下载支持普通 AES-128 密钥切换；复杂独立音轨、fMP4 MAP、byterange、直播和 DRM/SAMPLE-AES 暂不支持。
- 缺失原始清单时，若加密本地清单也没有显式 IV，无法排除原下载器曾丢失 IV，会拒绝导出并要求重新下载。
- 输出会重新打开检查轨道数量、编码和预期时长；失败时不将半成品当作成功。所选目标为系统文件保存 URI，无需新增全盘存储权限。
- 不伪造业务令牌或设备身份，不移除 DRM；当前播放源拒绝请求时明确报错。不读取其他应用的私有目录。
- 缓存列表只显示视频 ID 与缓存大小，不声称恢复了加密下载记录中的影片标题。

## 复现构建

需要 Linux x86_64、Python 3、Java 21 运行时和 `keytool`，以及原 APK。源码不包含原 APK 和本地签名私钥。

运行：

```bash
python3 bootstrap_tools.py
bash ../minimal-ffmpeg/fetch-source.sh
bash ../minimal-ffmpeg/build.sh x86_64 arm64-v8a armeabi-v7a
X2_INPUT_APK=/absolute/path/app.apk python3 build_patch.py
```

默认工具位置为源码同级的 `../patch-tools`，可通过 `X2_PATCH_TOOLS` 覆盖；最小 FFmpeg 库默认为 `../minimal-ffmpeg/<ABI>/lib`，可通过 `X2_FFMPEG_ROOT` 覆盖。自定义 NDK 路径时运行媒体构建脚本需设置 `X2_NDK_ROOT`。结果位于 `../output/`：APK、签名验证文本与 `build-info.json`。首次构建会生成本地开发签名；保留自己的 `build/local-export-key.p12` 才能后续更新自己生成的导出版。此签名不等于原应用签名。

工具为 Apktool 2.11.1、ECJ 3.41.0、Android Platform 35、Build Tools 35.0.0 与 NDK r28c。Google 工具按官方仓库元数据摘要校验；Maven 构件按仓库发布的摘要校验（Apktool 为 SHA-512，ECJ 为 SHA-1）。FFmpeg 6.0 的匹配头文件及许可证随源码放在 `third_party/ffmpeg-6.0`。

构建脚本从输入 APK 重新解包，修改包作用域的 provider authorities/自定义权限、新增两个 Activity，并在原 FlutterActivity/壳入口的 `onCreate` 最后添加入口。`inject_player_capture.py` 在 media_kit 输出管理器的 Create/Dispose 与 engine detach 注入三处只读观察器生命周期回调。原始 FlutterActivity 的混淆名称为 `c9/d`；本补丁只适用于本次分析的 APK 版本，不应直接套用于其他版本。

## 验证说明

验证记录以最终交付的分析报告为准。合成测试素材用于验证明文 HLS、带显式 IV 的 AES-128 HLS、分片/密钥缺失等情况；合成测试通过不代表第三方在线服务一定可连接，也不代表原应用所有媒体格式都已覆盖。
