from pathlib import Path
import subprocess,zipfile,io,json,hashlib
B=Path('/workspace/x2-analysis');R=B/'export9-tests';P='6adae13d4f03223f2b21a097e366a3cc0c2ddfb6'
old=zipfile.ZipFile(io.BytesIO(subprocess.check_output(['git','-C','/workspace/pqc-upload','show',P+':下载文件夹/X2-cache-export.apk'])));new=zipfile.ZipFile(B/'output/X2-cache-export.apk');assert set(old.namelist())==set(new.namelist())
changed=[n for n in old.namelist() if old.read(n)!=new.read(n)];assert set(n for n in changed if not n.startswith('META-INF/'))=={'AndroidManifest.xml','lib/arm64-v8a/libapp.so','lib/x86_64/libapp.so'},changed
src=zipfile.ZipFile(io.BytesIO(subprocess.check_output(['git','-C','/workspace/pqc-upload','show',P+':下载文件夹/X2-cache-export-source.zip'])))
for p in (B/'export-patch/src').rglob('*.java'):assert p.read_bytes()==src.read('x2-cache-export-source/export-patch/'+str(p.relative_to(B/'export-patch')))
d=dict(passed=True,baseline_commit=P,all_dex_and_assets_byte_identical=True,all_java_sources_byte_identical=True,original_native_libraries_preserved_except_two_declared_snapshots=True,changed_entries=changed,apk_sha256=hashlib.sha256((B/'output/X2-cache-export.apk').read_bytes()).hexdigest());(R/'comparison-results.json').write_text(json.dumps(d,indent=2));print(json.dumps(d,indent=2))
