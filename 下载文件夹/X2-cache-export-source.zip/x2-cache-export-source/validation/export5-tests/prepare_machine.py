"""Recreate machine-test snapshots from the pinned user-supplied original APK."""
from pathlib import Path
import sys,zipfile,json
B=Path('/workspace/x2-analysis');R=B/'export5-tests'
def prepare():
 sys.path.insert(0,str(B/'export-patch'))
 import patch_scroll,patch_ui,patch_launch_title
 ndk=B/'patch-tools/android-ndk-r28c/toolchains/llvm/prebuilt/linux-x86_64/bin';work=R/'asm';work.mkdir(exist_ok=True)
 with zipfile.ZipFile(B/'input/app.apk') as apk:
  for abi in patch_launch_title.SPECS:
   original=apk.read('lib/'+abi+'/libapp.so');path=B/'extracted/lib'/abi/'libapp.so';path.parent.mkdir(parents=True,exist_ok=True)
   if not path.exists():path.write_bytes(original)
   assert path.read_bytes()==original
   d,_=patch_scroll.apply(original,abi,ndk,work);d,_=patch_ui.apply(d,abi);d,report=patch_launch_title.apply(d,abi,ndk,work)
   (work/(abi+'-patched.so')).write_bytes(d);(work/(abi+'-report.json')).write_text(json.dumps(report,indent=2))
if __name__=='__main__':prepare()
