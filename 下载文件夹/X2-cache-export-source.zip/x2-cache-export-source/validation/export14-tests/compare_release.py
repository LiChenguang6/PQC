from pathlib import Path
import zipfile,json,hashlib
B=Path('/workspace/x2-analysis');P=B/'export-patch';R=B/'export14-tests';G=Path('/workspace/pqc-upload/下载文件夹')
with zipfile.ZipFile(G/'X2-cache-export-source.zip') as z:
 old=z.read('x2-cache-export-source/export-patch/src/org/x2/export/MediaDownloader.java').decode();new=(P/'src/org/x2/export/MediaDownloader.java').read_text();start=new.index('    /** Read-only, bounded inspection');end=new.index('    private static final class Session {',start);assert new[:start]+new[end:]==old
 unchanged=[]
 for n in z.namelist():
  prefix='x2-cache-export-source/export-patch/'
  if n.startswith(prefix+'src/') or n.startswith(prefix+'native/'):
   local=P/n[len(prefix):]
   if local.is_file() and local.read_bytes()==z.read(n):unchanged.append(n[len(prefix):])
with zipfile.ZipFile(G/'X2-cache-export.apk') as old,zipfile.ZipFile(B/'output/X2-cache-export.apk') as new:
 libs=[n for n in old.namelist() if n.startswith('lib/') and n.endswith('.so')];same=[n for n in libs if old.read(n)==new.read(n)];assert same==libs
r={'compared_to_release':'export13','existing_media_download_implementation_unchanged':True,'all_native_libraries_identical_to_export13':True,'native_library_count':len(libs),'unchanged_source_files':unchanged,'apk_sha256':hashlib.sha256((B/'output/X2-cache-export.apk').read_bytes()).hexdigest()};(R/'comparison-results.json').write_text(json.dumps(r,indent=2));print('PASS existing downloader implementation and all native libraries unchanged from export13')
