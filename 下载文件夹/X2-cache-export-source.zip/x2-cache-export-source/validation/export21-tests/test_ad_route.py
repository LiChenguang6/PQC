from pathlib import Path
import json,zipfile,struct,hashlib
from unicorn import *
from unicorn.arm64_const import *
from unicorn.x86_const import *
B=Path('/workspace/x2-analysis');R=B/'export21-tests';results=[]
for abi,base,at,show,skip,width in [('arm64-v8a',0x8b1000,0x70b420,0x70b43c,0x70b520,4),('x86_64',0x8c1000,0x61f214,0x61f22c,0x61f310,5)]:
 with zipfile.ZipFile(B/'output/X2-cache-export.apk') as z:d=z.read('lib/'+abi+'/libapp.so')
 arm=abi=='arm64-v8a'
 for ads in [0,1]:
  for vip in [0,1]:
   u=Uc(UC_ARCH_ARM64 if arm else UC_ARCH_X86,UC_MODE_ARM if arm else UC_MODE_64);u.mem_map(0,0x900000);u.mem_write(0,d);u.mem_map(0x2000000,0x10000)
   stack=0x2008000;controller=0x234567;closure=0x345678;u.mem_write(base+0x4934,struct.pack('<I',ads));u.mem_write(base+0x4904,struct.pack('<I',vip))
   regs={UC_ARM64_REG_X1:controller,UC_ARM64_REG_X2:closure,UC_ARM64_REG_X15:stack,UC_ARM64_REG_X29:stack+0x100,UC_ARM64_REG_SP:stack+0x1000} if arm else {UC_X86_REG_RDI:controller,UC_X86_REG_RSI:closure,UC_X86_REG_RSP:stack,UC_X86_REG_RBP:stack+0x100}
   for k,v in regs.items():u.reg_write(k,v)
   calls=[]
   def hook(emu,pc,size,data):
    if pc not in [show,skip]:return
    assert emu.reg_read(UC_ARM64_REG_X1 if arm else UC_X86_REG_RDI)==controller
    assert emu.reg_read(UC_ARM64_REG_X2 if arm else UC_X86_REG_RSI)==closure
    calls.append(pc)
    if arm:emu.reg_write(UC_ARM64_REG_PC,emu.reg_read(UC_ARM64_REG_X30))
    else:
     sp=emu.reg_read(UC_X86_REG_RSP);ret=struct.unpack('<Q',emu.mem_read(sp,8))[0];emu.reg_write(UC_X86_REG_RSP,sp+8);emu.reg_write(UC_X86_REG_RIP,ret)
   u.hook_add(UC_HOOK_CODE,hook);u.emu_start(at,at+width,count=50);assert calls==[skip if ads else show],(abi,ads,vip,calls)
   assert u.reg_read(UC_ARM64_REG_X15 if arm else UC_X86_REG_RSP)==stack
   assert u.reg_read(UC_ARM64_REG_X29 if arm else UC_X86_REG_RBP)==stack+0x100
   results.append({'abi':abi,'skip_ads':bool(ads),'entry_test':bool(vip),'target':'original_dismiss_completion' if ads else 'original_show_ads','receiver_and_callback_preserved':True})
r={'passed':True,'apk_sha256':hashlib.sha256((B/'output/X2-cache-export.apk').read_bytes()).hexdigest(),'cases':results};(R/'ad-route-results.json').write_text(json.dumps(r,indent=2));print('PASS 8 actual-payload ad routes: independent flags, correct original target, receiver/callback/stack preserved')
