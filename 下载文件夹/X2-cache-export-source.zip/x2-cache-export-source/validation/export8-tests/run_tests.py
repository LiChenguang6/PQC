from pathlib import Path
import subprocess,time,threading,http.server,json,hashlib,re
B=Path('/workspace/x2-analysis');R=B/'export8-tests';A=str(B/'android-sdk/platform-tools/adb');P='com.example.yinqishe_export';apk=B/'output/X2-cache-export.apk'
def run(*args,timeout=60):return subprocess.check_output([A,*args],timeout=timeout,text=True)
print(run('push',str(apk),'/data/local/tmp/X2-export8.apk'),flush=True)
try:print(run('shell','pm','install','-r','/data/local/tmp/X2-export8.apk',timeout=150),flush=True)
except subprocess.TimeoutExpired:print('Install response timed out; checking installed payload',flush=True)
p=run('shell','pm','path',P).strip().split('package:')[1];sha=run('exec-out','sha256sum',p).split()[0];assert sha==hashlib.sha256(apk.read_bytes()).hexdigest()
(R/'installed-results.json').write_text(json.dumps(dict(installed_sha256=sha,matches_delivery=True),indent=2))
subprocess.run(['python3',str(B/'ui-download-tests/build_test_apk.py')],check=True,stdout=(R/'test-build.log').open('w'),stderr=subprocess.STDOUT,timeout=150)
class Handler(http.server.BaseHTTPRequestHandler):
 def do_GET(self):
  data=(B/'capture-tests/fixture/capture-fixture.mp4').read_bytes();self.send_response(200);self.send_header('Content-Length',str(len(data)));self.end_headers()
  try:
   for i in range(0,len(data),128):self.wfile.write(data[i:i+128]);self.wfile.flush();time.sleep(.1)
  except OSError:pass
 def log_message(self,*a):pass
server=http.server.ThreadingHTTPServer(('0.0.0.0',18770),Handler);server.daemon_threads=True;threading.Thread(target=server.serve_forever,daemon=True).start()
results={}
try:
 for mode,expected,extra in [('ui8','ASYNC_CACHE_PARTITIONS_MULTISELECT_BATCH_PAUSE_RESUME_REMOVE_AND_PLAY_PASS',[]),('entry8','PRODUCTION_TWO_BUTTON_MANAGER_AND_SETTINGS_PASS',['-e','activity','com.example.yinqishe_app.MainActivity']),('drag','DRAG_PERSIST_AND_MANAGE_PASS',['-e','activity','org.x2.export.DownloadTasksActivity'])]:
  run('shell','am','force-stop',P)
  log=run('shell','am','instrument','-w','-e','mode',mode,*extra,'org.x2.uitests/org.x2.uitests.DownloadInstrumentation',timeout=180)
  (R/(mode+'-runtime.log')).write_text(log);print(log,flush=True);assert expected in log,mode
  results[mode]=dict(passed=True,metrics=dict(re.findall(r'INSTRUMENTATION_RESULT: (cold_activity_ms|warm_activity_ms|warm_rows)=(\d+)',log)))
  results['apk_sha256']=sha;(R/'ui-results.json').write_text(json.dumps(results,indent=2))
 results['apk_sha256']=sha;(R/'ui-results.json').write_text(json.dumps(results,indent=2))
finally:server.shutdown();server.server_close()
