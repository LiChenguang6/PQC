package org.x2.capturetests;

import java.io.IOException;
import java.util.Arrays;
import org.x2.export.PlayerCapture;

public final class CaptureTest {
    private static final String UA = "X2CaptureTest/1.0 (controlled fixture)";
    private static final String REFERRER = "https://reference.invalid/watch?fixture=1";
    private static final String TITLE = "Controlled capture fixture 中文 🎬";
    private static final String[] HEADERS = {
        "X-Capture-Test: alpha,beta", "X-Second-Test: left, right; mode=fixture"
    };
    private static int passed;

    public static void main(String[] args) {
        try {
            if (args.length != 2) throw new IllegalArgumentException("library directory, fixture URI");
            System.load(args[0] + "/libcapturetest.so");
            CaptureNative.load(args[0] + "/libmpv.so");
            run(args[1], args[0] + "/capture-fixture.mp4");
            System.out.println("CAPTURE_TEST_SUCCESS cases=" + passed);
        } catch (Throwable error) {
            error.printStackTrace(System.out);
            System.out.println("CAPTURE_TEST_FAILURE " + error);
            System.exit(2);
        }
    }

    private static void run(String uri, String localFixture) throws Exception {
        PlayerCapture.clear();
        expectRejected("no registered player");

        long idle = CaptureNative.create(null, UA, REFERRER, HEADERS, TITLE, false);
        PlayerCapture.register(idle);
        expectRejected("registered player idle");
        PlayerCapture.unregister(idle);
        terminate("unregister idle then terminate", idle);

        String pendingUri = uri.substring(0, uri.lastIndexOf('/') + 1) + "pending.mp4";
        long pending = CaptureNative.create(pendingUri, UA, REFERRER, HEADERS, TITLE, false);
        PlayerCapture.register(pending);
        awaitPending(pending, pendingUri);
        expectRejected("connecting player has no playable time position");
        PlayerCapture.unregister(pending);
        terminate("unregister connecting then terminate", pending);

        long first = CaptureNative.create(uri, UA, REFERRER, HEADERS, TITLE, false);
        PlayerCapture.register(first);
        awaitActive(first, uri);
        PlayerCapture.Source source = PlayerCapture.snapshot();
        equal("URI", uri, source.uri);
        equal("user agent", UA, source.userAgent);
        equal("referrer", REFERRER, source.referrer);
        equal("title", TITLE, source.title);
        require(Arrays.equals(HEADERS, source.headers), "raw header NODE_ARRAY preserved: " + Arrays.toString(source.headers));
        pass("source values and comma-containing header fields");

        CaptureNative.pause(first, true);
        Thread.sleep(100);
        expectRejected("paused player");
        CaptureNative.pause(first, false);
        awaitActive(first, uri);
        source = PlayerCapture.snapshot();
        equal("resumed URI", uri, source.uri);
        pass("resumed player");

        long second = CaptureNative.create(uri + "?second=1", UA, REFERRER, HEADERS, TITLE + " 2", false);
        PlayerCapture.register(second);
        awaitActive(second, uri + "?second=1");
        expectRejected("two active players are ambiguous");

        PlayerCapture.unregister(second);
        terminate("unregister active then terminate", second);
        source = PlayerCapture.snapshot();
        equal("remaining player URI", uri, source.uri);
        pass("other player unaffected by unregister");

        long local = CaptureNative.create(localFixture, UA, REFERRER, HEADERS, TITLE, false);
        PlayerCapture.register(local);
        awaitActive(local, localFixture);
        expectRejected("HTTP plus local active player is ambiguous");
        PlayerCapture.unregister(local);
        terminate("unregister local then terminate", local);

        PlayerCapture.clear();
        expectRejected("clear removed all players");
        terminate("clear active then terminate", first);

        long automatic = CaptureNative.create(uri + "?automatic=1", UA, REFERRER, HEADERS, TITLE, false);
        PlayerCapture.register(automatic);
        awaitActive(automatic, uri + "?automatic=1");
        PlayerCapture.snapshot();
        terminate("automatic weak-client shutdown on direct terminate", automatic);
        expectRejected("directly terminated player removed");
    }

    private static void awaitActive(long handle, String uri) throws Exception {
        long until = System.nanoTime() + 15000000000L;
        while (System.nanoTime() < until) {
            String path = CaptureNative.property(handle, "path");
            String idle = CaptureNative.property(handle, "idle-active");
            String pause = CaptureNative.property(handle, "pause");
            String position = CaptureNative.property(handle, "time-pos");
            if (uri.equals(path) && "no".equals(idle) && "no".equals(pause) && position != null) {
                System.out.println("FIXTURE_ACTIVE uri=" + path + " time=" + position);
                return;
            }
            Thread.sleep(50);
        }
        throw new AssertionError("fixture did not become active: path=" + CaptureNative.property(handle, "path")
            + " idle=" + CaptureNative.property(handle, "idle-active")
            + " pause=" + CaptureNative.property(handle, "pause")
            + " time=" + CaptureNative.property(handle, "time-pos"));
    }

    private static void awaitPending(long handle, String uri) throws Exception {
        long until = System.nanoTime() + 5000000000L;
        while (System.nanoTime() < until) {
            String path = CaptureNative.property(handle, "path");
            String idle = CaptureNative.property(handle, "idle-active");
            String pause = CaptureNative.property(handle, "pause");
            String position = CaptureNative.property(handle, "time-pos");
            if (uri.equals(path) && "no".equals(idle) && "no".equals(pause) && position == null) {
                System.out.println("FIXTURE_PENDING uri=" + path + " idle=" + idle + " pause=" + pause + " time=null");
                pass("loading path exists without a decoded time position");
                return;
            }
            Thread.sleep(25);
        }
        throw new AssertionError("fixture did not enter connecting state: path=" + CaptureNative.property(handle, "path")
            + " idle=" + CaptureNative.property(handle, "idle-active")
            + " pause=" + CaptureNative.property(handle, "pause")
            + " time=" + CaptureNative.property(handle, "time-pos"));
    }

    private static void expectRejected(String label) throws Exception {
        try {
            PlayerCapture.snapshot();
            throw new AssertionError("accepted " + label);
        } catch (IOException expected) {
            require(expected.getMessage() != null && expected.getMessage().length() > 0,
                "rejection contains a useful explanation: " + label);
            System.out.println("EXPECTED_REJECTION " + label + ": " + expected.getMessage());
            pass(label);
        }
    }

    private static void terminate(String label, final long handle) throws Exception {
        long start = System.nanoTime();
        final Throwable[] failure = new Throwable[1];
        Thread destroy = new Thread(new Runnable() {
            public void run() {
                try { CaptureNative.terminate(handle); }
                catch (Throwable error) { failure[0] = error; }
            }
        }, "capture-test-destroy");
        destroy.start();
        destroy.join(5000);
        long millis = (System.nanoTime() - start) / 1000000L;
        require(!destroy.isAlive(), label + " blocked for at least 5000 ms");
        if (failure[0] != null) throw new AssertionError(label, failure[0]);
        require(millis < 5000L, label + " took " + millis + " ms");
        System.out.println("TERMINATE_MILLIS " + label + ": " + millis);
        pass(label);
    }

    private static void equal(String label, String expected, String actual) {
        require(expected.equals(actual), label + " expected=" + expected + " actual=" + actual);
    }

    private static void require(boolean result, String message) {
        if (!result) throw new AssertionError(message);
    }

    private static void pass(String label) {
        passed++;
        System.out.println("CASE_PASS " + label);
    }
}
