from pathlib import Path
import sys,json,zipfile
B=Path('/workspace/x2-analysis');sys.path.insert(0,str(B/'export-patch'))
import patch_scroll,patch_ui,patch_launch_title,patch_tasks_short
N=B/'patch-tools/android-ndk-r28c/toolchains/llvm/prebuilt/linux-x86_64/bin';R=B/'export11-tests/asm';R.mkdir(exist_ok=True)
for abi in patch_tasks_short.S:
 with zipfile.ZipFile(B/'input/app.apk') as z:d=z.read('lib/'+abi+'/libapp.so')
 d,_=patch_scroll.apply(d,abi,N,R);d,_=patch_ui.apply(d,abi);d,_=patch_launch_title.apply(d,abi,N,R);d,r=patch_tasks_short.apply(d,abi,N,R)
 (R/(abi+'-patched.so')).write_bytes(d);(R/(abi+'-report.json')).write_text(json.dumps(r,indent=2));print(abi,r['output_sha256'])
