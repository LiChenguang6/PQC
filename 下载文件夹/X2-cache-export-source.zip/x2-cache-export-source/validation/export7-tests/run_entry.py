from pathlib import Path
import subprocess,json,hashlib
B=Path('/workspace/x2-analysis');R=B/'export7-tests';A=str(B/'android-sdk/platform-tools/adb');P='com.example.yinqishe_export';apk=B/'output/X2-cache-export.apk'
def run(*args,timeout=60):return subprocess.check_output([A,*args],timeout=timeout,text=True)
print(run('push',str(apk),'/data/local/tmp/X2-export7-final.apk'),flush=True)
try:print(run('shell','pm','install','-r','/data/local/tmp/X2-export7-final.apk',timeout=150),flush=True)
except subprocess.TimeoutExpired:print('Install response timed out; checking installed payload',flush=True)
p=run('shell','pm','path',P).strip().split('package:')[1];sha=run('exec-out','sha256sum',p).split()[0];assert sha==hashlib.sha256(apk.read_bytes()).hexdigest()
(R/'installed-results.json').write_text(json.dumps(dict(installed_sha256=sha,matches_delivery=True),indent=2))
run('shell','am','force-stop',P)
log=run('shell','am','instrument','-w','-e','mode','entry7','-e','activity','com.example.yinqishe_app.MainActivity','org.x2.uitests/org.x2.uitests.DownloadInstrumentation',timeout=180)
(R/'entry-runtime.log').write_text(log);print(log,flush=True);assert 'INITIAL_ENTRY_SETTINGS_LONG_PRESS_AND_DETACHED_RECOVERY_PASS' in log
(R/'entry-results.json').write_text(json.dumps(dict(passed=True,initial_production_onCreate_navigation_without_manual_install=True,production_manager_contains_settings_button=True,settings_activity_contains_folder_controls=True,long_press_backup_menu_opens=True,navigation_survives_overlay_detachment_over_one_second=True,onResume_restores_missing_overlay=True,apk_sha256=sha,real_platform_home_not_reachable=True),indent=2))
