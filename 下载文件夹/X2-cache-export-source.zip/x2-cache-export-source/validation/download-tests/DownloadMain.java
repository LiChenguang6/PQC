import java.io.File;
import java.io.IOException;
import java.net.URI;
import org.x2.export.MediaDownloader;

public final class DownloadMain {
    private static volatile boolean cancelled;
    public static void main(String[] args) throws Exception {
        String mode = args[0];
        String source = args[1];
        URI uri = new URI(source);
        if (mode.equals("cancel-stall")) {
            Thread cancel = new Thread(new Runnable() { public void run() {
                try { Thread.sleep(400); } catch (InterruptedException ignored) { }
                cancelled = true;
            }});
            cancel.setDaemon(true); cancel.start();
        }
        String[] headers = mode.equals("bad-header") ? new String[]{"X-Test: value\r\nInjected: yes"}
            : new String[]{"Authorization: Bearer AUTHSECRET", "Cookie: captured=COOKIESECRET", "X-Auth: HEADERSECRET"};
        try {
            MediaDownloader.Result result = MediaDownloader.download(source, "X2-Test-UA",
                "http://" + uri.getRawAuthority() + "/ref?secret=REFSECRET", headers, new File(args[2]),
                new MediaDownloader.Progress() {
                    @Override public void update(String stage, double fraction) {
                        if (mode.equals("cancel") && stage.startsWith("下载") && fraction > 0) cancelled = true;
                    }
                    @Override public boolean cancelled() { return cancelled; }
                });
            System.out.println("OK\t" + result.durationSeconds + "\t" + result.input.getAbsolutePath());
        } catch (IOException failure) {
            System.out.println("ERR\t" + failure.getMessage());
            System.exit(2);
        }
    }
}
