#!/usr/bin/env python3
"""Package the reproducible patch and LGPL media sources, excluding keys/builds."""
from pathlib import Path
import zipfile

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
OUTPUT = BASE / "output"
PREFIX = "x2-cache-export-source/"

def main():
    OUTPUT.mkdir(exist_ok=True)
    destination = OUTPUT / "X2-cache-export-source.zip"
    items = []
    for directory in ("src", "native", "third_party"):
        items += [(p, "export-patch/" + str(p.relative_to(HERE)))
                  for p in (HERE / directory).rglob("*") if p.is_file()]
    for name in ("README.md", "build_patch.py", "bootstrap_tools.py", "package_source.py", "inject_player_capture.py"):
        items.append((HERE / name, "export-patch/" + name))
    media = BASE / "minimal-ffmpeg"
    for name in ("README.md", "build.sh", "fetch-source.sh", "source/FFmpeg-n6.0.tar.gz"):
        items.append((media / name, "minimal-ffmpeg/" + name))
    for name in ("build-info.json", "signature-verification.txt"):
        items.append((OUTPUT / name, name))
    for name in ("native-tests/android-results.json", "native-tests/NativeTest.java",
                 "playlist-tests/results.json", "playlist-tests/test_playlist_preparer.py",
                 "playlist-tests/PrepareMain.java", "download-tests/README.md",
                 "download-tests/results.json", "download-tests/DownloadMain.java", "download-tests/test_downloader.py",
                 "capture-tests/run_capture_tests.py", "capture-tests/native/capture_helper.c",
                 "capture-tests/src/org/x2/capturetests/CaptureNative.java",
                 "capture-tests/src/org/x2/capturetests/CaptureTest.java", "capture-tests/results/results.json",
                 "ui-download-tests/AndroidManifest.xml", "ui-download-tests/build_test_apk.py",
                 "ui-download-tests/fixture_server.py", "ui-download-tests/run_ui.py",
                 "ui-download-tests/verify_media.py", "ui-download-tests/cache_regression.py",
                 "ui-download-tests/src/org/x2/uitests/DownloadInstrumentation.java",
                 "ui-download-tests/results/ui-results.json", "ui-download-tests/results/media-results.json",
                 "ui-download-tests/results/cache-regression.json"):
        path = BASE / name
        if path.is_file():
            items.append((path, "validation/" + name))
    with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for source, target in items:
            if not source.is_file():
                raise RuntimeError("Missing source artifact: " + str(source))
            archive.write(source, PREFIX + target)
    with zipfile.ZipFile(destination) as archive:
        assert archive.testzip() is None
        assert not any("key.p12" in name or "/build/" in name or name.endswith(".apk")
                       for name in archive.namelist())
    print(destination)

if __name__ == "__main__":
    main()
