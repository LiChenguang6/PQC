from pathlib import Path
import zipfile,json,hashlib
B=Path('/workspace/x2-analysis');P=B/'export-patch';R=B/'export15-tests';G=Path('/workspace/pqc-upload/下载文件夹')
with zipfile.ZipFile(G/'X2-cache-export-source.zip') as z:
 for name in ['MediaDownloader.java','DownloadService.java','DownloadStore.java','NativeRemux.java','DownloadConfig.java']:
  assert (P/'src/org/x2/export'/name).read_bytes()==z.read('x2-cache-export-source/export-patch/src/org/x2/export/'+name),name
with zipfile.ZipFile(G/'X2-cache-export.apk') as old,zipfile.ZipFile(B/'output/X2-cache-export.apk') as new:
 changed=[];same=[]
 for name in old.namelist():
  if not name.startswith('lib/') or not name.endswith('.so'):continue
  (same if old.read(name)==new.read(name) else changed).append(name)
 assert all(name.endswith('/libapp.so') or name.endswith('/libx2player.so') for name in changed),changed
 for abi in ['arm64-v8a','x86_64']:
  assert new.read('lib/'+abi+'/libapp.so')==(R/'asm'/(abi+'-patched.so')).read_bytes(),abi
r={'compared_to_release':'export14','core_download_queue_service_remux_settings_unchanged':True,'changed_native_files':changed,'unchanged_native_file_count':len(same),'machine_test_payload_matches_delivered_AOT':True,'apk_sha256':hashlib.sha256((B/'output/X2-cache-export.apk').read_bytes()).hexdigest()};(R/'comparison-results.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
