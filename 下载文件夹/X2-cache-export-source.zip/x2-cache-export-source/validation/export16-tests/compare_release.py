from pathlib import Path
import hashlib,json,zipfile
B=Path('/workspace/x2-analysis');R=B/'export16-tests';G=Path('/workspace/pqc-upload/下载文件夹');P=B/'export-patch'
with zipfile.ZipFile(G/'X2-cache-export-source.zip') as z:
 for n in ['MediaDownloader.java','DownloadService.java','DownloadStore.java','NativeRemux.java','VideoThumbnails.java']:
  assert (P/'src/org/x2/export'/n).read_bytes()==z.read('x2-cache-export-source/export-patch/src/org/x2/export/'+n),n
with zipfile.ZipFile(G/'X2-cache-export.apk') as old,zipfile.ZipFile(B/'output/X2-cache-export.apk') as new:
 libs=[n for n in old.namelist() if n.startswith('lib/') and n.endswith('.so')]
 assert libs and all(old.read(n)==new.read(n) for n in libs)
 assert not any('capturetest' in n or 'uitests' in n for n in new.namelist())
r={'passed':True,'compared_to_release':'export15','all_native_libraries_identical':len(libs),'download_service_store_remux_thumbnail_helper_unchanged':True,'apk_sha256':hashlib.sha256((B/'output/X2-cache-export.apk').read_bytes()).hexdigest()};(R/'comparison-results.json').write_text(json.dumps(r,indent=2));print(r)
