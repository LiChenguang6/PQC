from pathlib import Path
import importlib.util,time,json
BASE=Path('/workspace/x2-analysis');ROOT=BASE/'export3-tests'
spec=importlib.util.spec_from_file_location('ui',BASE/'runtime-logs/final_ui_test.py');ui=importlib.util.module_from_spec(spec);spec.loader.exec_module(ui);ui.ROOT=ROOT
end=time.monotonic()+60
while 'CONTROLLED_PLAYER_READY' not in (ROOT/'capture-ui.log').read_text():
 if time.monotonic()>end:raise RuntimeError((ROOT/'capture-ui.log').read_text())
 time.sleep(1)
button=ui.wait_node('two-buttons',lambda n:n.get('text')=='下载')
nodes=ui.dump('two-buttons');manage=next(n for n in nodes if n.get('text')=='管理')
assert button.get('bounds').split(',')[1].split(']')[0]==manage.get('bounds').split(',')[1].split(']')[0]
ui.shot('two-buttons');ui.tap(button)
ui.tap(ui.wait_node('first-folder-setup',lambda n:n.get('text')=='选择保存文件夹并下载'))
ui.wait_node('tree-picker',lambda n:n.get('package')=='com.android.documentsui')
ui.shot('tree-picker')
print(json.dumps([{'text':n.get('text'),'desc':n.get('content-desc'),'id':n.get('resource-id')} for n in ui.dump('tree-picker') if n.get('text') or n.get('content-desc')],ensure_ascii=False),flush=True)
