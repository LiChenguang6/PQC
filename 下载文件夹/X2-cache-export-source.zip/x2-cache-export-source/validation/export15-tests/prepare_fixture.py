from pathlib import Path
import subprocess
R=Path('/workspace/x2-analysis/export15-tests');F=R/'fixture';F.mkdir(exist_ok=True)
subprocess.run(['ffmpeg','-nostdin','-hide_banner','-loglevel','error','-f','lavfi','-i','color=c=blue:s=160x90:r=10','-t','12','-an','-c:v','libx264','-preset','ultrafast','-threads','1','-g','40','-sc_threshold','0','-pix_fmt','yuv420p','-f','hls','-hls_time','4','-hls_playlist_type','vod','-hls_segment_filename',str(F/'seg%d.ts'),'-y',str(F/'media.m3u8')],check=True)
