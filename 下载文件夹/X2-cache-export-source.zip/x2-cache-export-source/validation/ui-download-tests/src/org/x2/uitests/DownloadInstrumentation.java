package org.x2.uitests;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.x2.capturetests.CaptureNative;
import org.x2.export.DownloadConfig;
import org.x2.export.DownloadStore;
import org.x2.export.ExportEntry;
import org.x2.export.PlayerCapture;

/** Test APK only. No test entry points or fixture credentials are in the user APK. */
public final class DownloadInstrumentation extends Instrumentation {
    private Bundle options;
    @Override public void onCreate(Bundle args){options=args;start();}
    @Override public void onStart(){long handle=0;try{
        String mode=options.getString("mode","capture");
        if(mode.equals("metaProbe15")){
            Bundle result=new Bundle();for(DownloadStore.Job job:DownloadStore.get(getTargetContext()).all())if(job.title.equals("封面回归15 视频")){
                android.media.MediaMetadataRetriever retriever=new android.media.MediaMetadataRetriever();String stage="setDataSource";try{retriever.setDataSource(getTargetContext(),android.net.Uri.parse(job.document));stage="extractMetadata";result.putString("duration",retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION));stage="frame";android.graphics.Bitmap bitmap=retriever.getScaledFrameAtTime(1000000,android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC,640,360);result.putString("frame",bitmap==null?"null":bitmap.getWidth()+"x"+bitmap.getHeight());if(bitmap!=null)bitmap.recycle();}catch(Exception|OutOfMemoryError error){result.putString("error_stage",stage);result.putString("error_class",error.getClass().getSimpleName());result.putString("error_message",error.getMessage());}finally{retriever.release();}break;
            }finish(Activity.RESULT_OK,result);return;
        }
        if(mode.equals("controls20")){
            getTargetContext().getSharedPreferences("x2-development",0).edit().putInt("entry-test-version",0).putBoolean("forbidden-entry",true).commit();
            System.loadLibrary("capturetest");CaptureNative.seedDetails(getTargetContext().getApplicationInfo().nativeLibraryDir+"/libapp.so","https://fixture.invalid/controls20",0);
            final Activity settings=startActivitySync(new Intent().setClassName(getTargetContext(),"org.x2.export.DownloadSettingsActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            final android.widget.Switch ads=(android.widget.Switch)findText(settings.findViewById(android.R.id.content),"自动跳过播放器广告"),entry=(android.widget.Switch)findText(settings.findViewById(android.R.id.content),"开发测试：禁区入口（仅本地）");if(ads==null||entry==null)throw new AssertionError("independent settings absent");if(entry.isChecked())throw new AssertionError("old experimental permission flag reenabled on upgrade");
            runOnMainSync(()->{ads.setChecked(false);entry.setChecked(false);ads.setChecked(true);});if(CaptureNative.bridgeFlag(0)!=1||CaptureNative.bridgeFlag(1)!=0)throw new AssertionError("ad enable JNI or entry independence failed");
            runOnMainSync(()->entry.setChecked(true));if(CaptureNative.bridgeFlag(0)!=1||CaptureNative.bridgeFlag(1)!=1)throw new AssertionError("entry toggle changed ad flag");
            runOnMainSync(()->ads.setChecked(false));if(CaptureNative.bridgeFlag(0)!=0||CaptureNative.bridgeFlag(1)!=1)throw new AssertionError("ad disable changed entry flag");runOnMainSync(()->settings.finish());
            final Activity again=startActivitySync(new Intent().setClassName(getTargetContext(),"org.x2.export.DownloadSettingsActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));final android.widget.Switch a=(android.widget.Switch)findText(again.findViewById(android.R.id.content),"自动跳过播放器广告"),e=(android.widget.Switch)findText(again.findViewById(android.R.id.content),"开发测试：禁区入口（仅本地）");if(a.isChecked()||!e.isChecked())throw new AssertionError("settings not persisted");runOnMainSync(()->{a.setChecked(true);e.setChecked(false);again.finish();});
            Bundle result=new Bundle();result.putString("result","AD_AND_ENTRY_SETTINGS_PERSIST_AND_ACTUAL_JNI_FLAGS_INDEPENDENT_PASS");finish(Activity.RESULT_OK,result);return;
        }
        if(mode.equals("dedupe18Reload")){
            final DownloadStore store=DownloadStore.get(getTargetContext());DownloadStore.Job found=null;for(DownloadStore.Job j:store.all())if(j.title.equals("去重18 持久化"))found=j;
            if(found==null||found.source!=null||found.sourceKey.length()!=64)throw new AssertionError("completed source fingerprint not persisted");
            assertDuplicate18(store,org.x2.export.DownloadStore.playback(getTargetContext(),source18("https://test.invalid/persist18.m3u8","不同标题")));
            boolean blocked=false;try{org.x2.export.DownloadService.enqueue(getTargetContext(),source18("https://test.invalid/persist18.m3u8","不同标题"));}catch(java.io.IOException expected){blocked=expected.getMessage().contains("已经下载完成");}if(!blocked)throw new AssertionError("service enqueue did not reject completed task");
            store.remove(found);Bundle result=new Bundle();result.putString("result","COMPLETED_FINGERPRINT_PROCESS_RELOAD_AND_SERVICE_REJECTION_PASS");finish(Activity.RESULT_OK,result);return;
        }
        if(mode.equals("dedupe18")){
            final DownloadStore store=DownloadStore.get(getTargetContext());for(DownloadStore.Job j:store.all())if(j.title.startsWith("去重18"))store.remove(j);
            Class<?> identity=Class.forName("org.x2.export.VideoIdentity");java.lang.reflect.Method video=identity.getDeclaredMethod("video",String.class);video.setAccessible(true);
            String id=(String)video.invoke(null,"detail_match=exact_uri\ndetail_video_id=123\ndetail_video_type=2\n");
            if(id.length()!=64||!((String)video.invoke(null,"detail_match=none\ndetail_video_id=123\ndetail_video_type=2\n")).isEmpty())throw new AssertionError("identity accepts unmatched metadata");
            DownloadStore.Job first=DownloadStore.playback(getTargetContext(),source18("https://TEST.invalid:443/one.m3u8?asset=1#ignored","去重18 同标题"));first.videoKey=id;store.add(first);
            for(String state:new String[]{"queued","running","paused","failed","cancelled","deleting","success"}){first.state=state;assertDuplicate18(store,DownloadStore.playback(getTargetContext(),source18("https://test.invalid/one.m3u8?asset=1","另一个标题")));}
            first.source=null;store.save();assertDuplicate18(store,DownloadStore.playback(getTargetContext(),source18("https://test.invalid/one.m3u8?asset=1","不同标题")));
            DownloadStore.Job token=DownloadStore.playback(getTargetContext(),source18("https://other.invalid/new-token/one.m3u8","去重18 新地址"));token.videoKey=id;assertDuplicate18(store,token);
            DownloadStore.Job distinct=DownloadStore.playback(getTargetContext(),source18("https://test.invalid/one.m3u8?asset=2","去重18 同标题"));store.add(distinct);
            DownloadStore.Job reused=DownloadStore.playback(getTargetContext(),source18("https://test.invalid/one.m3u8?asset=1","去重18 复用端点"));reused.videoKey=(String)video.invoke(null,"detail_match=exact_uri\ndetail_video_id=124\ndetail_video_type=2\n");store.add(reused);
            final java.util.concurrent.atomic.AtomicInteger accepted=new java.util.concurrent.atomic.AtomicInteger(),rejected=new java.util.concurrent.atomic.AtomicInteger();final java.util.ArrayList<Thread> threads=new java.util.ArrayList<Thread>();
            for(int n=0;n<8;n++){Thread worker=new Thread(()->{try{store.add(DownloadStore.playback(getTargetContext(),source18("https://test.invalid/race18.m3u8","去重18 并发")));accepted.incrementAndGet();}catch(java.io.IOException expected){rejected.incrementAndGet();}});threads.add(worker);worker.start();}for(Thread worker:threads)worker.join();if(accepted.get()!=1||rejected.get()!=7)throw new AssertionError("concurrent duplicates accepted "+accepted.get());
            for(DownloadStore.Job j:store.all())if(j.title.startsWith("去重18"))store.remove(j);
            DownloadStore.Job persisted=DownloadStore.playback(getTargetContext(),source18("https://test.invalid/persist18.m3u8","去重18 持久化"));persisted.state="success";persisted.source=null;store.add(persisted);
            Bundle result=new Bundle();result.putString("result","SOURCE_IDENTITY_STATES_DIFFERENT_TITLES_DISTINCT_VIDEOS_AND_ATOMIC_RACE_PASS");finish(Activity.RESULT_OK,result);return;
        }
        if(mode.equals("gallery16")){
            getUiAutomation();DownloadConfig.setPreviews(getTargetContext(),true);DownloadConfig.setColumns(getTargetContext(),1);
            final Activity settings=startActivitySync(new Intent().setClassName(getTargetContext(),"org.x2.export.DownloadSettingsActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            runOnMainSync(()->{View root=settings.findViewById(android.R.id.content);((android.widget.Switch)findText(root,"显示视频预览图")).setChecked(false);findText(root,"预览每行数量：1").performClick();});
            if(!clickAccessible("2 个",10000))throw new AssertionError("column choice missing");
            if(DownloadConfig.previews(getTargetContext())||DownloadConfig.columns(getTargetContext())!=2)throw new AssertionError("settings did not persist");
            runOnMainSync(()->settings.finish());
            final DownloadStore store=DownloadStore.get(getTargetContext());for(DownloadStore.Job old:store.all())if(old.title.startsWith("画廊16"))store.remove(old);final android.net.Uri uri=createDeleteFixture("画廊16 视频");final DownloadStore.Job one=savedJob(store,"画廊16 视频 A",uri),two=savedJob(store,"画廊16 视频 B",uri);
            final Activity manager=startActivitySync(new Intent().setClassName(getTargetContext(),"org.x2.export.DownloadTasksActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            runOnMainSync(()->((View)fieldUnchecked(manager,"completed")).performClick());final android.widget.GridView completed=(android.widget.GridView)field(manager,"completedGrid");View card=awaitPreviewCard(completed,one.title);if(completed.getNumColumns()!=2||((View)field(card,"frame")).getVisibility()!=View.GONE)throw new AssertionError("manager ignores settings");
            ActivityMonitor monitor=addMonitor("org.x2.export.VideoPreviewActivity",null,false);runOnMainSync(()->findText(manager.findViewById(android.R.id.content),"视频预览").performClick());final Activity gallery=waitForMonitorWithTimeout(monitor,10000);removeMonitor(monitor);if(gallery==null)throw new AssertionError("gallery missing");
            final android.widget.GridView grid=(android.widget.GridView)field(gallery,"grid");card=awaitPreviewCard(grid,one.title);if(grid.getNumColumns()!=2||((View)field(card,"frame")).getVisibility()!=View.GONE||findText(gallery.findViewById(android.R.id.content),"多选")!=null||findText(gallery.findViewById(android.R.id.content),"下载设置")!=null)throw new AssertionError("gallery layout mismatch");
            final Intent[] opened={null};ActivityMonitor player=new ActivityMonitor(){@Override public ActivityResult onStartActivity(Intent intent){if(Intent.ACTION_VIEW.equals(intent.getAction())){opened[0]=intent;return new ActivityResult(Activity.RESULT_OK,null);}return null;}};addMonitor(player);runOnMainSync(()->grid.performItemClick(null,position(grid,one.title),0));Thread.sleep(300);removeMonitor(player);if(opened[0]==null||!uri.equals(opened[0].getData())||(opened[0].getFlags()&Intent.FLAG_GRANT_READ_URI_PERMISSION)==0)throw new AssertionError("gallery playback failed");
            runOnMainSync(()->{gallery.finish();manager.finish();});
            final Activity again=startActivitySync(new Intent().setClassName(getTargetContext(),"org.x2.export.DownloadSettingsActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));if(findText(again.findViewById(android.R.id.content),"预览每行数量：2")==null||((android.widget.Switch)findText(again.findViewById(android.R.id.content),"显示视频预览图")).isChecked())throw new AssertionError("settings lost on reopen");
            runOnMainSync(()->{again.finish();DownloadConfig.setPreviews(getTargetContext(),true);DownloadConfig.setColumns(getTargetContext(),4);});
            final Activity four=startActivitySync(new Intent().setClassName(getTargetContext(),"org.x2.export.VideoPreviewActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));final android.widget.GridView fourGrid=(android.widget.GridView)field(four,"grid");card=awaitPreviewCard(fourGrid,one.title);if(fourGrid.getNumColumns()!=4||((View)field(card,"frame")).getVisibility()!=View.VISIBLE)throw new AssertionError("four columns or images missing");
            runOnMainSync(()->four.finish());DownloadConfig.setColumns(getTargetContext(),1);store.remove(one);store.remove(two);android.provider.DocumentsContract.deleteDocument(getTargetContext().getContentResolver(),uri);
            Bundle result=new Bundle();result.putString("result","GALLERY_SETTINGS_PERSIST_COLUMNS_HIDE_IMAGES_MINIMAL_UI_PLAYBACK_PASS");finish(Activity.RESULT_OK,result);return;
        }
        if(mode.equals("preview15")){
            getUiAutomation();final DownloadStore store=DownloadStore.get(getTargetContext());for(DownloadStore.Job old:store.all())if(old.title.startsWith("封面回归15"))store.remove(old);
            final android.net.Uri video=createDeleteFixture("封面回归15 视频"),broken=createDeleteFixture("封面回归15 无效文件");byte[] bytes;try(java.io.InputStream in=new java.net.URL(options.getString("fixture")).openStream();java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream()){byte[] block=new byte[8192];int n;while((n=in.read(block))!=-1)out.write(block,0,n);bytes=out.toByteArray();}try(java.io.OutputStream out=getTargetContext().getContentResolver().openOutputStream(video,"wt")){out.write(bytes);}
            final DownloadStore.Job filler=savedJob(store,"封面回归15 占位",video),good=savedJob(store,"封面回归15 视频",video),bad=savedJob(store,"封面回归15 无效文件",broken);
            final Activity manager=startActivitySync(new Intent().setClassName(getTargetContext(),"org.x2.export.DownloadTasksActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));final android.widget.AbsListView list=(android.widget.AbsListView)field(manager,"completedGrid");runOnMainSync(()->((View)fieldUnchecked(manager,"completed")).performClick());long end=System.currentTimeMillis()+15000;while(position(list,good.title)<0&&System.currentTimeMillis()<end)Thread.sleep(100);runOnMainSync(()->list.setSelection(position(list,good.title)));Thread.sleep(500);
            View card=awaitPreviewCard(list,good.title);if(card==null||!card.getClass().getName().endsWith("VideoPreviewCard"))throw new AssertionError("completed videos did not use preview cards");android.widget.ImageView cover=(android.widget.ImageView)field(card,"cover");android.widget.TextView duration=(android.widget.TextView)field(card,"duration");end=System.currentTimeMillis()+15000;while(!hasPreview(cover)&&System.currentTimeMillis()<end)Thread.sleep(100);if(!hasPreview(cover)||!"0:02".contentEquals(duration.getText()))throw new AssertionError("SAF MP4 preview or duration missing "+duration.getText());android.graphics.Bitmap bitmap=((android.graphics.drawable.BitmapDrawable)cover.getDrawable()).getBitmap();if(bitmap.getWidth()>640||bitmap.getHeight()>360)throw new AssertionError("thumbnail exceeds size bound");if(Math.abs(cover.getWidth()*9.0/16-cover.getHeight())>2)throw new AssertionError("cover not16:9");
            java.io.File directory=new java.io.File(getTargetContext().getCacheDir(),"video-previews-v1");java.io.File[] cached=directory.listFiles();if(cached==null||cached.length==0)throw new AssertionError("thumbnail disk cache not written");
            Class<?> thumbnails=Class.forName("org.x2.export.VideoThumbnails");java.lang.reflect.Field memoryField=thumbnails.getDeclaredField("memory");memoryField.setAccessible(true);android.util.LruCache memory=(android.util.LruCache)memoryField.get(null);runOnMainSync(()->memory.evictAll());try(java.io.OutputStream out=getTargetContext().getContentResolver().openOutputStream(video,"wt")){out.write(new byte[]{1,2,3});}
            final View previous=card;runOnMainSync(()->{((android.widget.ImageView)fieldUnchecked(previous,"cover")).setImageBitmap(null);((View)fieldUnchecked(manager,"ongoing")).performClick();((View)fieldUnchecked(manager,"completed")).performClick();list.setSelection(position(list,good.title));});Thread.sleep(600);card=awaitPreviewCard(list,good.title);cover=(android.widget.ImageView)field(card,"cover");end=System.currentTimeMillis()+15000;while(!hasPreview(cover)&&System.currentTimeMillis()<end)Thread.sleep(100);if(!hasPreview(cover))throw new AssertionError("persisted preview unavailable after memory eviction");try(java.io.OutputStream out=getTargetContext().getContentResolver().openOutputStream(video,"wt")){out.write(bytes);}
            final Intent[] playback={null};ActivityMonitor player=new ActivityMonitor(){@Override public ActivityResult onStartActivity(Intent intent){if(Intent.ACTION_VIEW.equals(intent.getAction())){playback[0]=intent;return new ActivityResult(Activity.RESULT_OK,null);}return null;}};addMonitor(player);android.graphics.Rect location=new android.graphics.Rect();if(!cover.getGlobalVisibleRect(location))throw new AssertionError("preview cover not visible");tap(location.centerX(),location.centerY());Thread.sleep(500);if(playback[0]==null||!video.equals(playback[0].getData())||!"video/mp4".equals(playback[0].getType())||(playback[0].getFlags()&Intent.FLAG_GRANT_READ_URI_PERMISSION)==0||playback[0].getClipData()==null)throw new AssertionError("cover tap did not launch granted MP4 playback");playback[0]=null;
            runOnMainSync(()->((View)fieldUnchecked(manager,"multi")).performClick());Thread.sleep(300);card=awaitPreviewCard(list,good.title);cover=(android.widget.ImageView)field(card,"cover");if(!cover.getGlobalVisibleRect(location))throw new AssertionError("selection cover not visible");tap(location.centerX(),location.centerY());Thread.sleep(500);if(!((java.util.Set)field(manager,"selected")).contains(good.id)||playback[0]!=null)throw new AssertionError("card tap in multiselect launched playback or failed to select");removeMonitor(player);
            runOnMainSync(()->{((View)fieldUnchecked(manager,"multi")).performClick();list.setSelection(position(list,bad.title));});Thread.sleep(800);View failed=awaitPreviewCard(list,bad.title);if(!bad.title.contentEquals(((TextView)field(failed,"title")).getText()))throw new AssertionError("invalid-file card missing");if(hasPreview((android.widget.ImageView)field(failed,"cover")))throw new AssertionError("invalid MP4 borrowed another video thumbnail");if(!"--:--".contentEquals(((TextView)field(failed,"duration")).getText()))throw new AssertionError("invalid MP4 got wrong duration");
            runOnMainSync(()->list.setSelection(position(list,good.title)));Thread.sleep(400);getUiAutomation().takeScreenshot().compress(android.graphics.Bitmap.CompressFormat.PNG,100,new java.io.FileOutputStream(new java.io.File(getTargetContext().getCacheDir(),"preview15-screen.png")));
            runOnMainSync(()->manager.finish());store.remove(filler);store.remove(good);store.remove(bad);android.provider.DocumentsContract.deleteDocument(getTargetContext().getContentResolver(),video);android.provider.DocumentsContract.deleteDocument(getTargetContext().getContentResolver(),broken);
            Bundle result=new Bundle();result.putString("result","SAF_PREVIEW_CARD_DURATION_DISK_CACHE_PLAYBACK_MULTISELECT_AND_FAILURE_PASS");result.putString("thumbnail_bounds",bitmap.getWidth()+"x"+bitmap.getHeight());result.putString("duration_badge","0:02");finish(Activity.RESULT_OK,result);return;
        }
        if(mode.equals("source15")){
            getUiAutomation();final Activity settings=startActivitySync(new Intent().setClassName(getTargetContext(),"org.x2.export.DownloadSettingsActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));System.loadLibrary("capturetest");CaptureNative.load(getTargetContext().getApplicationInfo().nativeLibraryDir+"/libmpv.so");handle=CaptureNative.create(options.getString("fixture"),"DO_NOT_REPORT_AGENT","",new String[]{"X-Fixture: DO_NOT_REPORT_HEADER"},"DO_NOT_REPORT_TITLE",true);PlayerCapture.register(handle);
            java.lang.reflect.Method detail=PlayerCapture.class.getDeclaredMethod("pageDetails",String.class);detail.setAccessible(true);String fixture=options.getString("fixture"),image=getTargetContext().getApplicationInfo().nativeLibraryDir+"/libapp.so";
            CaptureNative.seedDetails(image,fixture,0);String numeric=(String)detail.invoke(null,fixture);if(!numeric.contains("detail_match=exact_uri")||!numeric.contains("detail_video_id=778899")||!numeric.contains("detail_play_time_raw=180")||!numeric.contains("detail_can_watch=0"))throw new AssertionError("numeric bridge incomplete "+numeric);
            if(!((String)detail.invoke(null,fixture+"&wrong-source=1")).contains("detail_match=none"))throw new AssertionError("wrong URI matched metadata");
            CaptureNative.seedDetails(image,fixture,2);if(!((String)detail.invoke(null,fixture)).contains("detail_match=none"))throw new AssertionError("incomplete seqlock matched metadata");
            CaptureNative.seedDetails(image,fixture,3);if(!((String)detail.invoke(null,fixture)).contains("detail_match=none"))throw new AssertionError("invalid metadata marker matched");CaptureNative.seedDetails(image,fixture,0);
            long end=System.currentTimeMillis()+15000;String duration="";while(System.currentTimeMillis()<end){duration=CaptureNative.property(handle,"duration");if(duration!=null&&duration.startsWith("12"))break;Thread.sleep(100);}if(duration==null||!duration.startsWith("12"))throw new AssertionError("HLS fixture unavailable");
            CaptureNative.pause(handle,false);Class<?> history=Class.forName("org.x2.export.PlaybackDiagnostics");java.lang.reflect.Method startHistory=history.getDeclaredMethod("start",android.content.Context.class);startHistory.setAccessible(true);getTargetContext().getSharedPreferences("x2-development",0).edit().putBoolean("forbidden-entry",true).commit();startHistory.invoke(null,getTargetContext());Thread.sleep(1600);CaptureNative.pause(handle,true);
            final View probe=findText(settings.findViewById(android.R.id.content),"检查当前播放源（复制）");if(probe==null||!hasScroll(settings.findViewById(android.R.id.content)))throw new AssertionError("source inspection setting unavailable");runOnMainSync(()->probe.performClick());if(!clickAccessible("复制",20000))throw new AssertionError("inspection result not available");Thread.sleep(300);
            android.content.ClipboardManager cb=(android.content.ClipboardManager)getTargetContext().getSystemService(android.content.Context.CLIPBOARD_SERVICE);String text=cb.getPrimaryClip().getItemAt(0).getText().toString();if(!text.contains("version=9.9.9-export15")||!text.contains("manifest_seconds=12.000")||!text.contains("segments=3")||!text.contains("endlist=1")||!text.contains("source_id=")||!text.contains("snapshot=recent_cached")||!text.contains("detail_play_time_raw=180")||!text.contains("detail_video_id=778899")||!text.contains("detail_can_watch=0"))throw new AssertionError("manifest result incomplete "+text);if(text.contains("DO_NOT_REPORT")||text.contains("http://")||text.contains("auth_key")||text.contains("X-Fixture"))throw new AssertionError("inspection report leaked captured credentials");
            PlayerCapture.unregister(handle);CaptureNative.terminate(handle);handle=0;Bundle result=new Bundle();result.putString("result","PHONE_SOURCE_DETAILS_EXACT_URI_REJECTION_HLS_PRIVACY_AND_COPY_PASS");result.putString("manifest_seconds","12.000");result.putBoolean("real_platform_video",false);finish(Activity.RESULT_OK,result);return;
        }
        if(mode.equals("offline28")){
            System.loadLibrary("capturetest");CaptureNative.load(getTargetContext().getApplicationInfo().nativeLibraryDir+"/libmpv.so");
            handle=CaptureNative.create(options.getString("fixture"),"X2OfflineFixture","",new String[0],"Synthetic offline 28-second fixture",false);PlayerCapture.register(handle);
            double max=0,duration=0;long until=SystemClock.elapsedRealtime()+45000;String endProperty="";java.lang.reflect.Method metrics=PlayerCapture.class.getDeclaredMethod("playbackState");metrics.setAccessible(true);String state="";
            while(SystemClock.elapsedRealtime()<until){String pos=CaptureNative.property(handle,"time-pos"),dur=CaptureNative.property(handle,"duration");try{if(pos!=null)max=Math.max(max,Double.parseDouble(pos));if(dur!=null)duration=Double.parseDouble(dur);}catch(NumberFormatException ignored){}if(max>=23){state=(String)metrics.invoke(null);endProperty=CaptureNative.property(handle,"end");break;}Thread.sleep(200);}
            if(max<23||duration<27||!state.contains("players=1"))throw new AssertionError("original MPV/observer did not cross23seconds: max="+max+" duration="+duration+" state="+state);
            PlayerCapture.unregister(handle);CaptureNative.terminate(handle);handle=0;Bundle result=new Bundle();result.putString("result","ORIGINAL_MPV_OBSERVER_CONTINUOUS_LOCAL_PLAYBACK_OVER23_SECONDS_PASS");result.putString("numeric_state",state);result.putDouble("max_position_seconds",max);result.putDouble("duration_seconds",duration);result.putString("end_property",endProperty);result.putBoolean("real_platform_video",false);finish(Activity.RESULT_OK,result);return;
        }
        if(mode.equals("delete12")){
            getUiAutomation();final DownloadStore store=DownloadStore.get(getTargetContext());for(DownloadStore.Job old:store.all())if(old.title.startsWith("删除回归12"))store.remove(old);
            final android.net.Uri keep=createDeleteFixture("删除回归12 保留"),one=createDeleteFixture("删除回归12 A"),two=createDeleteFixture("删除回归12 B"),ui=createDeleteFixture("删除回归12 界面");
            final DownloadStore.Job k=savedJob(store,"删除回归12 保留",keep),a=savedJob(store,"删除回归12 A",one),b=savedJob(store,"删除回归12 B",two),unselected=savedJob(store,"删除回归12 界面",ui),bad=savedJob(store,"删除回归12 失败",android.net.Uri.parse("content://invalid.x2.test/no-permission"));
            runOnMainSync(()->org.x2.export.DownloadService.command(getTargetContext(),"remove",k.id));awaitRemoved(store,k.id);if(!documentExists(keep))throw new AssertionError("record-only action deleted MP4");
            final java.util.ArrayList<String> ids=new java.util.ArrayList<String>();ids.add(a.id);ids.add(b.id);ids.add(bad.id);runOnMainSync(()->org.x2.export.DownloadService.commandBatch(getTargetContext(),"remove_file",ids));awaitRemoved(store,a.id);awaitRemoved(store,b.id);
            long end=System.currentTimeMillis()+15000;while(bad.state.equals("deleting")&&System.currentTimeMillis()<end)Thread.sleep(100);if(store.find(bad.id)==null||!bad.state.equals("success")||!bad.stage.contains("无法删除"))throw new AssertionError("failed file deletion lost record");
            if(documentExists(one)||documentExists(two)||!documentExists(ui)||store.find(unselected.id)==null)throw new AssertionError("batch deleted wrong files");
            final Activity manager=startActivitySync(new Intent().setClassName(getTargetContext(),"org.x2.export.DownloadTasksActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));final android.widget.AbsListView list=(android.widget.AbsListView)field(manager,"completedGrid");
            runOnMainSync(()->((View)fieldUnchecked(manager,"completed")).performClick());end=System.currentTimeMillis()+15000;while(position(list,"删除回归12 界面")<0&&System.currentTimeMillis()<end)Thread.sleep(100);if(position(list,"删除回归12 界面")<0)throw new AssertionError("completed fixture missing");
            runOnMainSync(()->list.getOnItemLongClickListener().onItemLongClick(list,null,position(list,"删除回归12 界面"),0));if(!clickAccessible("删除记录及 MP4 文件",15000))throw new AssertionError("single-file delete option absent");sendKeyDownUpSync(android.view.KeyEvent.KEYCODE_BACK);
            runOnMainSync(()->{((View)fieldUnchecked(manager,"multi")).performClick();int pos=position(list,"删除回归12 界面");list.performItemClick(null,pos,pos);findText(manager.findViewById(android.R.id.content),"删除").performClick();});
            if(!clickAccessible("删除记录及 MP4 文件",15000)||!clickAccessible("删除",15000))throw new AssertionError("batch file-delete confirmation missing");awaitRemoved(store,unselected.id);if(documentExists(ui))throw new AssertionError("UI batch left MP4 behind");
            if(!documentExists(keep))throw new AssertionError("unselected retained file disappeared");android.provider.DocumentsContract.deleteDocument(getTargetContext().getContentResolver(),keep);store.remove(bad);Thread.sleep(7000);
            Bundle result=new Bundle();result.putString("result","RECORD_ONLY_KEEP_BATCH_FILE_DELETE_FAILURE_RETENTION_AND_UI_OPTIONS_PASS");result.putInt("pid",android.os.Process.myPid());finish(Activity.RESULT_OK,result);return;
        }
        if(mode.equals("cover13")){
            final Class<?> appearance=Class.forName("org.x2.export.Appearance");final java.lang.reflect.Method image=appearance.getDeclaredMethod("importImage",android.content.Context.class,android.net.Uri.class,boolean.class),reset=appearance.getDeclaredMethod("reset",android.content.Context.class);image.setAccessible(true);reset.setAccessible(true);
            java.io.File source=new java.io.File(getTargetContext().getFilesDir(),"cover13-test.png");android.graphics.Bitmap fixture=android.graphics.Bitmap.createBitmap(40,20,android.graphics.Bitmap.Config.ARGB_8888);fixture.eraseColor(0xff3388cc);try(java.io.FileOutputStream out=new java.io.FileOutputStream(source)){fixture.compress(android.graphics.Bitmap.CompressFormat.PNG,100,out);}fixture.recycle();image.invoke(null,getTargetContext(),android.net.Uri.fromFile(source),false);
            final Activity main=startActivitySync(new Intent().setClassName(getTargetContext(),"com.example.yinqishe_app.MainActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));System.loadLibrary("capturetest");
            long end=System.currentTimeMillis()+15000;while(!CaptureNative.setHomeReady(0)&&System.currentTimeMillis()<end)Thread.sleep(100);Thread.sleep(1500);
            final View cover=main.findViewById(android.R.id.content).findViewWithTag("x2-custom-cover");if(cover==null)throw new AssertionError("production startup cover disappeared before home-ready signal");
            if(!CaptureNative.setHomeReady(1))throw new AssertionError("test home marker unavailable");end=System.currentTimeMillis()+3000;while(cover.getParent()!=null&&System.currentTimeMillis()<end)Thread.sleep(100);if(cover.getParent()!=null)throw new AssertionError("production cover did not consume home-ready signal");Thread.sleep(300);if(cover.getParent()!=null)throw new AssertionError("removed cover reattached");reset.invoke(null,getTargetContext());source.delete();
            Bundle result=new Bundle();result.putString("result","PRODUCTION_COVER_WAITS_FOR_HOME_MARKER_AND_REMOVES_PASS");result.putBoolean("home_marker_synthetic",true);finish(Activity.RESULT_OK,result);return;
        }
        if(mode.equals("appearance12")){
            getUiAutomation();final Class<?> appearance=Class.forName("org.x2.export.Appearance");final java.lang.reflect.Method setName=appearance.getDeclaredMethod("setName",android.content.Context.class,String.class),name=appearance.getDeclaredMethod("name",android.content.Context.class),image=appearance.getDeclaredMethod("importImage",android.content.Context.class,android.net.Uri.class,boolean.class),file=appearance.getDeclaredMethod("file",android.content.Context.class,boolean.class),shortcut=appearance.getDeclaredMethod("shortcut",android.content.Context.class),reset=appearance.getDeclaredMethod("reset",android.content.Context.class),cover=appearance.getDeclaredMethod("installCover",Activity.class);for(java.lang.reflect.Method method:new java.lang.reflect.Method[]{setName,name,image,file,shortcut,reset,cover})method.setAccessible(true);
            java.io.File source=new java.io.File(getTargetContext().getFilesDir(),"appearance12-test.png"),invalid=new java.io.File(getTargetContext().getFilesDir(),"appearance12-invalid.txt"),untouched=new java.io.File(getTargetContext().getFilesDir(),"appearance12-unrelated.mp4");android.graphics.Bitmap fixture=android.graphics.Bitmap.createBitmap(40,20,android.graphics.Bitmap.Config.ARGB_8888);fixture.eraseColor(0xff3388cc);try(java.io.FileOutputStream out=new java.io.FileOutputStream(source)){fixture.compress(android.graphics.Bitmap.CompressFormat.PNG,100,out);}fixture.recycle();try(java.io.FileOutputStream out=new java.io.FileOutputStream(invalid)){out.write(new byte[]{1,2,3});}try(java.io.FileOutputStream out=new java.io.FileOutputStream(untouched)){out.write(new byte[]{7,8,9});}
            setName.invoke(null,getTargetContext(),"云影😀");image.invoke(null,getTargetContext(),android.net.Uri.fromFile(source),true);image.invoke(null,getTargetContext(),android.net.Uri.fromFile(source),false);java.io.File iconFile=(java.io.File)file.invoke(null,getTargetContext(),true),splashFile=(java.io.File)file.invoke(null,getTargetContext(),false);android.graphics.Bitmap decoded=android.graphics.BitmapFactory.decodeFile(iconFile.getPath());if(decoded==null||decoded.getWidth()!=256||decoded.getHeight()!=256)throw new AssertionError("custom icon not normalized");decoded.recycle();long validLength=iconFile.length();boolean rejected=false;try{image.invoke(null,getTargetContext(),android.net.Uri.fromFile(invalid),true);}catch(java.lang.reflect.InvocationTargetException expected){rejected=true;}if(!rejected||iconFile.length()!=validLength)throw new AssertionError("invalid image replaced saved icon");
            final Activity settings=startActivitySync(new Intent().setClassName(getTargetContext(),"org.x2.export.DownloadSettingsActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));ActivityMonitor monitor=addMonitor("org.x2.export.AppearanceActivity",null,false);runOnMainSync(()->findText(settings.findViewById(android.R.id.content),"名称、图标与开屏").performClick());final Activity page=waitForMonitorWithTimeout(monitor,15000);removeMonitor(monitor);if(page==null||findText(page.findViewById(android.R.id.content),"选择应用开屏图片")==null||!hasScroll(page.findViewById(android.R.id.content)))throw new AssertionError("appearance settings entry missing");
            final Throwable[] failure={null};runOnMainSync(()->{try{cover.invoke(null,page);}catch(Throwable e){failure[0]=e;}});if(failure[0]!=null)throw new AssertionError(failure[0]);View custom=page.findViewById(android.R.id.content).findViewWithTag("x2-custom-cover");if(custom==null)throw new AssertionError("custom startup cover missing");final View close=findText(custom,"关闭封面");runOnMainSync(()->close.performClick());Thread.sleep(500);if(custom.getParent()!=null)throw new AssertionError("startup cover cannot close or reappeared");
            android.content.pm.ShortcutManager shortcuts=getTargetContext().getSystemService(android.content.pm.ShortcutManager.class);boolean supported=shortcuts!=null&&shortcuts.isRequestPinShortcutSupported();boolean pinned=false;
            if(supported){runOnMainSync(()->{try{shortcut.invoke(null,getTargetContext());}catch(Throwable e){failure[0]=e;}});if(failure[0]!=null)throw new AssertionError(failure[0]);long end=System.currentTimeMillis()+20000;while(System.currentTimeMillis()<end){for(android.content.pm.ShortcutInfo item:shortcuts.getPinnedShortcuts())if(item.getId().equals("x2-custom-entry"))pinned=true;if(pinned)break;for(String label:new String[]{"Add automatically","ADD AUTOMATICALLY","Add","ADD","添加","自动添加"})if(clickAccessible(label,200))break;Thread.sleep(200);}if(!pinned)throw new AssertionError("launcher did not pin custom shortcut");
                setName.invoke(null,getTargetContext(),"新名称😀");runOnMainSync(()->{try{shortcut.invoke(null,getTargetContext());}catch(Throwable e){failure[0]=e;}});boolean updated=false;for(android.content.pm.ShortcutInfo item:shortcuts.getPinnedShortcuts())if(item.getId().equals("x2-custom-entry")&&"新名称😀".contentEquals(item.getShortLabel()))updated=true;if(!updated)throw new AssertionError("pinned shortcut label did not update");}
            reset.invoke(null,getTargetContext());if(iconFile.exists()||splashFile.exists()||!untouched.exists()||"新名称😀".equals(name.invoke(null,getTargetContext())))throw new AssertionError("appearance reset damaged unrelated data or retained custom files");if(pinned)runOnMainSync(()->{try{shortcut.invoke(null,getTargetContext());}catch(Throwable ignored){}});source.delete();invalid.delete();untouched.delete();
            Bundle result=new Bundle();result.putString("result","APPEARANCE_IMPORT_VALIDATION_ENTRY_COVER_RESET_AND_SHORTCUT_PASS");result.putBoolean("launcher_pin_supported",supported);result.putBoolean("launcher_pinned_and_updated",pinned);finish(Activity.RESULT_OK,result);return;
        }
        if(mode.equals("ui8")){
            getUiAutomation();
            final DownloadStore store=DownloadStore.get(getTargetContext());
            for(DownloadStore.Job old:store.all()){if(old.title.startsWith("分区回归"))store.remove(old);else if(old.active()){old.state="paused";old.paused=true;}}
            org.x2.export.DownloadConfig.setParallel(getTargetContext(),2);
            final DownloadStore.Job a=DownloadStore.playback(getTargetContext(),new PlayerCapture.Source("http://10.0.2.2:18770/slow/A.mp4","X2BatchTest","",new String[0],"分区回归 A"));
            final DownloadStore.Job b=DownloadStore.playback(getTargetContext(),new PlayerCapture.Source("http://10.0.2.2:18770/slow/B.mp4","X2BatchTest","",new String[0],"分区回归 B"));
            final DownloadStore.Job c=DownloadStore.playback(getTargetContext(),new PlayerCapture.Source("http://10.0.2.2:18770/slow/C.mp4","X2BatchTest","",new String[0],"分区回归 完成"));c.state="success";c.stage="已保存 MP4";c.document="content://com.android.externalstorage.documents/document/primary%3ADownload%2Ftest.mp4";c.source=null;
            store.add(a);store.add(b);store.add(c);store.save();
            long started=SystemClock.uptimeMillis();final Activity manager=startActivitySync(new Intent().setClassName(getTargetContext(),"org.x2.export.DownloadTasksActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));long opened=SystemClock.uptimeMillis()-started;
            final android.widget.AbsListView list=(android.widget.ListView)field(manager,"list");long end=System.currentTimeMillis()+15000;
            while(position(list,"分区回归 B")<0&&System.currentTimeMillis()<end)Thread.sleep(100);
            if(position(list,"分区回归 A")<0)throw new AssertionError("async queue not loaded");
            runOnMainSync(()->((View)fieldUnchecked(manager,"multi")).performClick());
            runOnMainSync(()->{int pa=position(list,"分区回归 A"),pb=position(list,"分区回归 B");list.performItemClick(null,pa,pa);list.performItemClick(null,pb,pb);});
            Thread.sleep(1200);if(((java.util.Set)field(manager,"selected")).size()!=2)throw new AssertionError("selection lost across refresh");
            final View pause=findText(manager.findViewById(android.R.id.content),"暂停");runOnMainSync(()->pause.performClick());awaitState(a,"paused");awaitState(b,"paused");
            runOnMainSync(()->{int pa=position(list,"分区回归 A"),pb=position(list,"分区回归 B");list.performItemClick(null,pa,pa);list.performItemClick(null,pb,pb);findText(manager.findViewById(android.R.id.content),"继续").performClick();});awaitState(a,"running");awaitState(b,"running");
            runOnMainSync(()->{int pa=position(list,"分区回归 A"),pb=position(list,"分区回归 B");list.performItemClick(null,pa,pa);list.performItemClick(null,pb,pb);pause.performClick();});awaitState(a,"paused");awaitState(b,"paused");
            runOnMainSync(()->{int pa=position(list,"分区回归 A"),pb=position(list,"分区回归 B");list.performItemClick(null,pa,pa);list.performItemClick(null,pb,pb);findText(manager.findViewById(android.R.id.content),"删除").performClick();});Thread.sleep(500);
            boolean clicked=false;long dialogEnd=System.currentTimeMillis()+20000;while(!clicked&&System.currentTimeMillis()<dialogEnd){android.view.accessibility.AccessibilityNodeInfo window=getUiAutomation().getRootInActiveWindow();if(window!=null){java.util.List<android.view.accessibility.AccessibilityNodeInfo> nodes=window.findAccessibilityNodeInfosByText("删除");for(android.view.accessibility.AccessibilityNodeInfo node:nodes)if("删除".contentEquals(node.getText())&&node.isClickable()){clicked=node.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK);break;}}if(!clicked)Thread.sleep(300);}if(!clicked)throw new AssertionError("remove confirmation missing");
            end=System.currentTimeMillis()+15000;while((store.find(a.id)!=null||store.find(b.id)!=null)&&System.currentTimeMillis()<end)Thread.sleep(100);if(store.find(a.id)!=null||store.find(b.id)!=null||store.find(c.id)==null)throw new AssertionError("batch remove affected wrong records");
            runOnMainSync(()->{((View)fieldUnchecked(manager,"multi")).performClick();((View)fieldUnchecked(manager,"completed")).performClick();});Thread.sleep(800);
            final Intent[] playback={null};ActivityMonitor player=new ActivityMonitor(){@Override public ActivityResult onStartActivity(Intent i){if(Intent.ACTION_VIEW.equals(i.getAction())){playback[0]=i;return new ActivityResult(Activity.RESULT_OK,null);}return null;}};addMonitor(player);
            runOnMainSync(()->{int pos=position(list,"分区回归 完成");if(pos<0)throw new AssertionError("completed partition missing");list.performItemClick(null,pos,pos);});Thread.sleep(400);removeMonitor(player);
            if(playback[0]==null||!"video/mp4".equals(playback[0].getType())||(playback[0].getFlags()&Intent.FLAG_GRANT_READ_URI_PERMISSION)==0||playback[0].getClipData()==null)throw new AssertionError("completed click did not grant playback URI");
            runOnMainSync(()->manager.finish());waitForIdleSync();long warm=SystemClock.uptimeMillis();final Activity again=startActivitySync(new Intent().setClassName(getTargetContext(),"org.x2.export.DownloadTasksActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));long warmMs=SystemClock.uptimeMillis()-warm;
            final android.widget.ListView warmList=(android.widget.ListView)field(again,"list");if(warmList.getAdapter().getCount()==0)throw new AssertionError("warm open did not display cached records");
            Bundle report=new Bundle();report.putString("result","ASYNC_CACHE_PARTITIONS_MULTISELECT_BATCH_PAUSE_RESUME_REMOVE_AND_PLAY_PASS");report.putLong("cold_activity_ms",opened);report.putLong("warm_activity_ms",warmMs);report.putInt("warm_rows",warmList.getAdapter().getCount());runOnMainSync(()->again.finish());finish(Activity.RESULT_OK,report);return;
        }
        if(mode.equals("pauseSeed6")||mode.equals("pauseVerify6")){
            DownloadStore store=DownloadStore.get(getTargetContext());DownloadStore.Job selected=null;
            if(mode.equals("pauseSeed6")){
                for(DownloadStore.Job old:store.all())if(old.title.equals("回归持久暂停"))store.remove(old);
                selected=DownloadStore.playback(getTargetContext(),new PlayerCapture.Source("http://10.0.2.2:18770/slow/Persist.mp4","X2PausePersist/1.0","",new String[0],"回归持久暂停"));store.add(selected);
                final String id=selected.id;runOnMainSync(()->org.x2.export.DownloadService.command(getTargetContext(),"pause",id));awaitState(selected,"paused");Thread.sleep(1500);
            } else {
                for(DownloadStore.Job job:store.all())if(job.title.equals("回归持久暂停"))selected=job;
                if(selected==null||!selected.paused||!selected.state.equals("paused"))throw new AssertionError("paused record not restored: "+(selected==null?"missing":selected.state+"/"+selected.paused));
                final String id=selected.id;runOnMainSync(()->org.x2.export.DownloadService.start(getTargetContext()));Thread.sleep(1200);
                if(!selected.state.equals("paused"))throw new AssertionError("paused task restarted automatically");
                runOnMainSync(()->org.x2.export.DownloadService.command(getTargetContext(),"resume",id));awaitState(selected,"running");
                runOnMainSync(()->org.x2.export.DownloadService.command(getTargetContext(),"cancel",id));awaitState(selected,"cancelled");
                store.remove(selected);
            }
            Bundle report=new Bundle();report.putString("result",mode.equals("pauseSeed6")?"PAUSED_RECORD_SAVED":"PAUSED_RECORD_RESTORED_AND_RESUMED");finish(Activity.RESULT_OK,report);return;
        }
        if(mode.equals("service6")){
            final DownloadStore store=DownloadStore.get(getTargetContext());
            for(DownloadStore.Job old:store.all())if(old.title.startsWith("回归暂停 ")||old.title.equals("回归持久暂停"))store.remove(old);
            org.x2.export.DownloadConfig.setParallel(getTargetContext(),1);
            final DownloadStore.Job a=DownloadStore.playback(getTargetContext(),new PlayerCapture.Source("http://10.0.2.2:18770/slow/A.mp4","X2ServiceRegression/1.0","",new String[0],"回归暂停 A"));
            final DownloadStore.Job b=DownloadStore.playback(getTargetContext(),new PlayerCapture.Source("http://10.0.2.2:18770/slow/B.mp4","X2ServiceRegression/1.0","",new String[0],"回归暂停 B"));
            store.add(a);store.add(b);
            runOnMainSync(()->org.x2.export.DownloadService.start(getTargetContext()));
            awaitState(a,"running");Thread.sleep(1200);
            runOnMainSync(()->org.x2.export.DownloadService.command(getTargetContext(),"pause",a.id));
            awaitState(a,"paused");awaitState(b,"running");int progress=a.progress;Thread.sleep(1500);if(a.progress!=progress)throw new AssertionError("paused progress changed");
            runOnMainSync(()->org.x2.export.DownloadService.command(getTargetContext(),"resume",a.id));Thread.sleep(600);
            if(!a.state.equals("paused")||!a.resumeRequested)throw new AssertionError("resume exceeded parallel limit");
            runOnMainSync(()->org.x2.export.DownloadService.command(getTargetContext(),"cancel",b.id));awaitState(b,"cancelled");awaitState(a,"running");
            runOnMainSync(()->org.x2.export.DownloadService.command(getTargetContext(),"pause",a.id));awaitState(a,"paused");
            runOnMainSync(()->org.x2.export.DownloadService.command(getTargetContext(),"remove",a.id));
            long end=System.currentTimeMillis()+15000;while(store.find(a.id)!=null&&System.currentTimeMillis()<end)Thread.sleep(100);
            if(store.find(a.id)!=null)throw new AssertionError("paused removal failed");
            for(int i=0;i<25;i++){runOnMainSync(()->org.x2.export.DownloadService.command(getTargetContext(),"cancel",b.id));Thread.sleep(50);}
            Thread.sleep(8000);
            if(!b.state.equals("cancelled"))throw new AssertionError("cancel state lost");
            Bundle report=new Bundle();report.putString("result","PAUSE_RESUME_CANCEL_REMOVE_PROCESS_SURVIVED");report.putInt("pid",android.os.Process.myPid());finish(Activity.RESULT_OK,report);return;
        }
        if(mode.equals("reset")){
            DownloadStore store=DownloadStore.get(getTargetContext());
            for(DownloadStore.Job job:store.all())if(job.title.startsWith("任务 ")||job.title.equals("受控测试视频"))store.remove(job);
            Bundle report=new Bundle();report.putString("result","TEST_RECORDS_RESET");finish(Activity.RESULT_OK,report);return;
        }
        if(mode.equals("seed")){
            DownloadStore store=DownloadStore.get(getTargetContext());
            for(String label:options.getString("jobs","A,B,C,D").split(",")){
                String kind=label.equals("E")?"retry":"slow";
                PlayerCapture.Source source=new PlayerCapture.Source(options.getString("server","http://127.0.0.1:18766")+"/"+kind+"/"+label+".mp4?fixture_nonce=BACKGROUND_TEST","X2ControlledBgTest/1.0","",new String[0],options.getString("title","任务 "+label));
                store.add(DownloadStore.playback(getTargetContext(),source));
            }
            Bundle report=new Bundle();report.putString("result","SEEDED_ENCRYPTED_QUEUE");report.putInt("parallel",DownloadConfig.parallel(getTargetContext()));finish(Activity.RESULT_OK,report);return;
        }
        if(mode.equals("diagnostic11"))getUiAutomation();
        Intent launch=new Intent();launch.setClassName(getTargetContext(),options.getString("activity","com.tencent.a.SetupInfoActivity"));launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        final Activity activity=startActivitySync(launch);
        if(mode.equals("diagnostic11")){
            final Class<?> capture=Class.forName("org.x2.export.PlayerCapture");final java.lang.reflect.Method bridge=capture.getDeclaredMethod("testState",boolean.class),metrics=capture.getDeclaredMethod("playbackState");bridge.setAccessible(true);metrics.setAccessible(true);
            String initial=(String)bridge.invoke(null,false);if(!initial.contains("bridge=ready")||!initial.contains("flag=0"))throw new AssertionError("bridge not ready "+initial);
            final Activity settings=startActivitySync(new Intent().setClassName(getTargetContext(),"org.x2.export.DownloadSettingsActivity").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            final View toggle=findText(settings.findViewById(android.R.id.content),"开发测试：禁区入口与本地试看计时");if(!(toggle instanceof android.widget.Switch))throw new AssertionError("development toggle missing");
            runOnMainSync(()->((android.widget.Switch)toggle).setChecked(false));runOnMainSync(()->((android.widget.Switch)toggle).setChecked(true));
            String state=(String)bridge.invoke(null,true);if(!state.contains("flag=1"))throw new AssertionError("setting did not synchronize flag "+state);
            if(activity.hasWindowFocus())throw new AssertionError("main still focused during settings test");
            System.loadLibrary("capturetest");CaptureNative.load(getTargetContext().getApplicationInfo().nativeLibraryDir+"/libmpv.so");
            handle=CaptureNative.create(options.getString("fixture"),"DO_NOT_REPORT_AGENT","",new String[]{"X-Diagnostic-Secret: DO_NOT_REPORT_HEADER"},"DO_NOT_REPORT_TITLE",true);PlayerCapture.register(handle);
            String props="";long end=System.currentTimeMillis()+20000;
            while(System.currentTimeMillis()<end){props=(String)metrics.invoke(null);if(props.contains("pause=1")&&!props.contains("dur=-1"))break;Thread.sleep(100);}
            if(!props.contains("players=1")||!props.contains("pause=1")||props.contains("dur=-1"))throw new AssertionError("MPV numeric state unavailable: "+props);
            Thread.sleep(1600);Class<?> diagnostic=Class.forName("org.x2.export.PlaybackDiagnostics");java.lang.reflect.Method report=diagnostic.getDeclaredMethod("report",android.content.Context.class);report.setAccessible(true);String text=(String)report.invoke(null,getTargetContext());
            if(!text.contains("version=9.9.9-export15")||!text.contains("process=64-bit")||!text.contains("flag=1")||!text.contains("players=1"))throw new AssertionError("diagnostic report incomplete "+text);
            if(text.contains("DO_NOT_REPORT")||text.contains("http://")||text.contains("auth_key")||text.contains("X-Diagnostic-Secret"))throw new AssertionError("diagnostic leaked source data");
            final View copy=findText(settings.findViewById(android.R.id.content),"播放诊断（复制）");if(copy==null)throw new AssertionError("diagnostic button missing");
            final View root=settings.findViewById(android.R.id.content);if(!hasScroll(root))throw new AssertionError("settings must scroll");runOnMainSync(()->copy.performClick());
            boolean clicked=false;end=System.currentTimeMillis()+15000;while(!clicked&&System.currentTimeMillis()<end){android.view.accessibility.AccessibilityNodeInfo window=getUiAutomation().getRootInActiveWindow();if(window!=null)for(android.view.accessibility.AccessibilityNodeInfo node:window.findAccessibilityNodeInfosByText("复制"))if("复制".contentEquals(node.getText())&&node.isClickable()){clicked=node.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK);break;}if(!clicked)Thread.sleep(200);}
            if(!clicked)throw new AssertionError("copy confirmation unavailable");Thread.sleep(300);
            android.content.ClipboardManager clipboard=(android.content.ClipboardManager)getTargetContext().getSystemService(android.content.Context.CLIPBOARD_SERVICE);if(clipboard.getPrimaryClip()==null||!clipboard.getPrimaryClip().getItemAt(0).getText().toString().contains("version=9.9.9-export15"))throw new AssertionError("report not copied");
            PlayerCapture.unregister(handle);CaptureNative.terminate(handle);handle=0;
            Bundle result=new Bundle();result.putString("result","DIAGNOSTIC_SYNC_WITHOUT_MAIN_FOCUS_MPV_METRICS_PRIVACY_AND_CLIPBOARD_PASS");result.putString("numeric_state",props);finish(Activity.RESULT_OK,result);return;
        }
        if(mode.equals("entry8")){
            final View row=activity.findViewById(android.R.id.content).findViewWithTag("x2-download-buttons");
            if(!(row instanceof LinearLayout)||((LinearLayout)row).getChildCount()!=2)throw new AssertionError("production lifecycle missing two buttons");
            ActivityMonitor monitor=addMonitor("org.x2.export.DownloadTasksActivity",null,false);runOnMainSync(()->((LinearLayout)row).getChildAt(1).performClick());Activity manager=waitForMonitorWithTimeout(monitor,30000);removeMonitor(monitor);if(manager==null)throw new AssertionError("production manage button did not open page");
            final View settings=findText(manager.findViewById(android.R.id.content),"下载设置");monitor=addMonitor("org.x2.export.DownloadSettingsActivity",null,false);runOnMainSync(()->settings.performClick());Activity config=waitForMonitorWithTimeout(monitor,15000);removeMonitor(monitor);if(config==null||findText(config.findViewById(android.R.id.content),"更改下载文件夹")==null)throw new AssertionError("folder settings unavailable");
            Bundle report=new Bundle();report.putString("result","PRODUCTION_TWO_BUTTON_MANAGER_AND_SETTINGS_PASS");finish(Activity.RESULT_OK,report);return;
        }
        if(mode.equals("entry7")){
            ActivityMonitor managerMonitor=addMonitor("org.x2.export.DownloadTasksActivity",null,false);
            System.loadLibrary("capturetest");long until=System.currentTimeMillis()+30000;boolean requested=false;
            while(System.currentTimeMillis()<until){if(CaptureNative.requestManager()){requested=true;break;}Thread.sleep(200);}
            if(!requested)throw new AssertionError("libapp not mapped");
            Activity manager=waitForMonitorWithTimeout(managerMonitor,15000);removeMonitor(managerMonitor);
            if(manager==null)throw new AssertionError("initial lifecycle navigation listener missing");
            View row=activity.findViewById(android.R.id.content).findViewWithTag("x2-download-buttons");
            if(row==null||((LinearLayout)row).getChildCount()!=1)throw new AssertionError("initial single download overlay missing");
            final View settingsButton=findText(manager.findViewById(android.R.id.content),"下载设置");
            if(settingsButton==null)throw new AssertionError("manager settings button missing");
            ActivityMonitor settingsMonitor=addMonitor("org.x2.export.DownloadSettingsActivity",null,false);
            runOnMainSync(()->settingsButton.performClick());Activity settings=waitForMonitorWithTimeout(settingsMonitor,10000);removeMonitor(settingsMonitor);
            if(settings==null||findText(settings.findViewById(android.R.id.content),"更改下载文件夹")==null)throw new AssertionError("settings page not shown");
            final Activity closeSettings=settings,closeManager=manager;runOnMainSync(()->{closeSettings.finish();closeManager.finish();});waitForIdleSync();Thread.sleep(800);
            final View firstRow=activity.findViewById(android.R.id.content).findViewWithTag("x2-download-buttons");
            final boolean[] menu={false};runOnMainSync(()->menu[0]=((LinearLayout)firstRow).getChildAt(0).performLongClick());waitForIdleSync();Thread.sleep(300);
            if(!menu[0]||firstRow.hasWindowFocus())throw new AssertionError("long press backup menu not shown");
            settingsMonitor=addMonitor("org.x2.export.DownloadSettingsActivity",null,false);
            sendKeyDownUpSync(android.view.KeyEvent.KEYCODE_DPAD_DOWN);sendKeyDownUpSync(android.view.KeyEvent.KEYCODE_DPAD_DOWN);sendKeyDownUpSync(android.view.KeyEvent.KEYCODE_ENTER);
            Activity backupSettings=waitForMonitorWithTimeout(settingsMonitor,10000);removeMonitor(settingsMonitor);
            if(backupSettings==null||findText(backupSettings.findViewById(android.R.id.content),"更改下载文件夹")==null)throw new AssertionError("long press settings item failed");
            final Activity closeBackup=backupSettings;runOnMainSync(()->closeBackup.finish());waitForIdleSync();Thread.sleep(400);
            runOnMainSync(()->((android.view.ViewGroup)firstRow.getParent()).removeView(firstRow));Thread.sleep(1000);
            managerMonitor=addMonitor("org.x2.export.DownloadTasksActivity",null,false);CaptureNative.requestManager();
            manager=waitForMonitorWithTimeout(managerMonitor,12000);removeMonitor(managerMonitor);
            if(manager==null)throw new AssertionError("navigation stopped after overlay detached");
            final Activity detachedManager=manager;runOnMainSync(()->detachedManager.finish());waitForIdleSync();Thread.sleep(600);
            if(activity.findViewById(android.R.id.content).findViewWithTag("x2-download-buttons")==null)throw new AssertionError("onResume did not restore overlay");
            Bundle report=new Bundle();report.putString("result","INITIAL_ENTRY_SETTINGS_LONG_PRESS_AND_DETACHED_RECOVERY_PASS");finish(Activity.RESULT_OK,report);return;
        }
        if(mode.equals("controls6")){
            runOnMainSync(()->content(activity));
            long until=System.currentTimeMillis()+30000;boolean mapped=false;
            System.loadLibrary("capturetest");while(System.currentTimeMillis()<until){if(CaptureNative.requestManager()){mapped=true;break;}Thread.sleep(200);}
            if(!mapped)throw new AssertionError("libapp not mapped");
            PlayerCapture.manageRequested(false);
            runOnMainSync(()->{content(activity);ExportEntry.install(activity);});waitForIdleSync();Thread.sleep(500);
            View row=activity.findViewById(android.R.id.content).findViewWithTag("x2-download-buttons");
            if(((LinearLayout)row).getChildCount()!=1)throw new AssertionError("floating manager still present");
            ActivityMonitor monitor=addMonitor("org.x2.export.DownloadTasksActivity",null,false);
            CaptureNative.requestManager();Activity manager=waitForMonitorWithTimeout(monitor,15000);removeMonitor(monitor);
            if(manager==null)throw new AssertionError("left tab event did not open manager");
            Bundle report=new Bundle();report.putString("result","SINGLE_DOWNLOAD_AND_MANAGER_BRIDGE_PASS");finish(Activity.RESULT_OK,report);return;
        }
        if(mode.equals("drag")){
            getTargetContext().getSharedPreferences("x2-overlay-position",0).edit().clear().commit();
            final ScrollView[] scroll=new ScrollView[1];
            runOnMainSync(()->{scroll[0]=content(activity);ExportEntry.install(activity);});
            waitForIdleSync();Thread.sleep(500);
            View row=activity.findViewById(android.R.id.content).findViewWithTag("x2-download-buttons");int[] location=new int[2];row.getLocationOnScreen(location);
            float oldX=row.getX(),oldY=row.getY();float x=location[0]+row.getWidth()/4f,y=location[1]+row.getHeight()/2f;
            swipe(x,y,x-100,y+250);waitForIdleSync();Thread.sleep(300);
            float newX=row.getX(),newY=row.getY();
            if(Math.abs(newX-oldX)<50||Math.abs(newY-oldY)<100)throw new AssertionError("buttons did not drag");
            if(scroll[0].getScrollY()!=0)throw new AssertionError("drag scrolled underlying page");
            if(!row.hasWindowFocus())throw new AssertionError("drag triggered a click/dialog");
            runOnMainSync(()->{scroll[0]=content(activity);ExportEntry.install(activity);});waitForIdleSync();Thread.sleep(500);
            row=activity.findViewById(android.R.id.content).findViewWithTag("x2-download-buttons");
            if(Math.abs(newX-row.getX())>2||Math.abs(newY-row.getY())>2)throw new AssertionError("position not restored");
            swipe(30,620,30,280);waitForIdleSync();Thread.sleep(200);int after=scroll[0].getScrollY();if(after<=0)throw new AssertionError("uncovered page cannot scroll");
            ActivityMonitor monitor=addMonitor("org.x2.export.DownloadTasksActivity",null,false);
            row.getLocationOnScreen(location);tap(location[0]+row.getWidth()*3f/4,location[1]+row.getHeight()/2f);
            Activity manager=waitForMonitorWithTimeout(monitor,15000);removeMonitor(monitor);if(manager==null)throw new AssertionError("management tap after drag did not open manager");
            Bundle report=new Bundle();report.putString("result","DRAG_PERSIST_AND_MANAGE_PASS");report.putFloat("x",newX);report.putFloat("y",newY);report.putInt("uncovered_page_scroll",after);finish(Activity.RESULT_OK,report);return;
        }
        System.loadLibrary("capturetest");CaptureNative.load(getTargetContext().getApplicationInfo().nativeLibraryDir+"/libmpv.so");String uri=options.getString("fixture");
        handle=CaptureNative.create(uri,"X2ControlledUiTest/1.0","",new String[0],"受控测试视频",false);PlayerCapture.register(handle);
        long deadline=System.currentTimeMillis()+30000;boolean ready=false;
        while(System.currentTimeMillis()<deadline){try{if(uri.equals(PlayerCapture.snapshot().uri)){ready=true;break;}}catch(java.io.IOException e){}Thread.sleep(100);}
        if(!ready)throw new IllegalStateException("controlled playback not ready");
        Bundle report=new Bundle();report.putString("result","CONTROLLED_PLAYER_READY");sendStatus(1,report);Thread.sleep(240000);
        PlayerCapture.unregister(handle);CaptureNative.terminate(handle);handle=0;finish(Activity.RESULT_OK,report);
    }catch(Throwable error){if(handle!=0){PlayerCapture.unregister(handle);CaptureNative.terminate(handle);}Bundle report=new Bundle();report.putString("failure",error.getClass().getSimpleName()+": "+error.getMessage());report.putString("test_stack",java.util.Arrays.toString(error.getStackTrace()));finish(Activity.RESULT_CANCELED,report);}}
    private boolean clickAccessible(String label,long timeout)throws Exception{long end=System.currentTimeMillis()+timeout;do{android.view.accessibility.AccessibilityNodeInfo window=getUiAutomation().getRootInActiveWindow();if(window!=null)for(android.view.accessibility.AccessibilityNodeInfo node:window.findAccessibilityNodeInfosByText(label))if(label.contentEquals(node.getText())){android.view.accessibility.AccessibilityNodeInfo click=node;while(click!=null&&!click.isClickable())click=click.getParent();if(click!=null&&click.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK))return true;}Thread.sleep(100);}while(System.currentTimeMillis()<end);return false;}
    private android.net.Uri createDeleteFixture(String title)throws Exception{android.net.Uri tree=android.net.Uri.parse(DownloadConfig.folder(getTargetContext()));android.net.Uri parent=android.provider.DocumentsContract.buildDocumentUriUsingTree(tree,android.provider.DocumentsContract.getTreeDocumentId(tree));android.net.Uri uri=android.provider.DocumentsContract.createDocument(getTargetContext().getContentResolver(),parent,"video/mp4",title+"-"+System.nanoTime()+".mp4");try(java.io.OutputStream out=getTargetContext().getContentResolver().openOutputStream(uri)){out.write(new byte[]{0,0,0,24,102,116,121,112,109,112,52,50});}return uri;}
    private DownloadStore.Job savedJob(DownloadStore store,String title,android.net.Uri document)throws Exception{DownloadStore.Job job=DownloadStore.playback(getTargetContext(),new PlayerCapture.Source("https://fixture.invalid/"+java.util.UUID.randomUUID()+".mp4","","",new String[0],title));job.state="success";job.stage="已保存 MP4";job.document=document.toString();job.source=null;store.add(job);return job;}
    private boolean documentExists(android.net.Uri uri)throws Exception{try(java.io.InputStream in=getTargetContext().getContentResolver().openInputStream(uri)){return in!=null;}catch(java.io.FileNotFoundException e){return false;}}
    private void awaitRemoved(DownloadStore store,String id)throws Exception{long end=System.currentTimeMillis()+20000;while(store.find(id)!=null&&System.currentTimeMillis()<end)Thread.sleep(100);if(store.find(id)!=null)throw new AssertionError("record removal timed out "+store.find(id).stage);}
    private boolean hasScroll(View root){if(root instanceof ScrollView)return true;if(root instanceof android.view.ViewGroup){android.view.ViewGroup g=(android.view.ViewGroup)root;for(int i=0;i<g.getChildCount();i++)if(hasScroll(g.getChildAt(i)))return true;}return false;}
    private Object field(Object target,String name)throws Exception{java.lang.reflect.Field f=target.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(target);}
    private Object fieldUnchecked(Object target,String name){try{return field(target,name);}catch(Exception e){throw new RuntimeException(e);}}
    private org.x2.export.PlayerCapture.Source source18(String uri,String title){return new org.x2.export.PlayerCapture.Source(uri,"","",new String[0],title);}
    private void assertDuplicate18(DownloadStore store,DownloadStore.Job job)throws Exception{int count=store.all().size();boolean blocked=false;try{store.add(job);}catch(java.io.IOException expected){blocked=true;}if(!blocked||store.all().size()!=count)throw new AssertionError("duplicate was added");}
    private View awaitPreviewCard(android.widget.AbsListView list,String title)throws Exception{long end=System.currentTimeMillis()+15000;View card;while((card=previewCard(list,title))==null&&System.currentTimeMillis()<end){final int pos=position(list,title);if(pos>=0)runOnMainSync(()->list.setSelection(pos));Thread.sleep(300);}if(card==null)throw new AssertionError("preview card not visible: "+title+" first="+list.getFirstVisiblePosition()+" rows="+list.getAdapter().getCount());return card;}
    private boolean hasPreview(android.widget.ImageView image){return image.getDrawable() instanceof android.graphics.drawable.BitmapDrawable&&((android.graphics.drawable.BitmapDrawable)image.getDrawable()).getBitmap()!=null;}
    private View previewCard(android.widget.AbsListView list,String title){for(int i=0;i<list.getChildCount();i++){View child=list.getChildAt(i);try{if(title.contentEquals(((TextView)field(child,"title")).getText()))return child;}catch(Exception ignored){}}return null;}
    private int position(android.widget.AbsListView list,String title){for(int i=0;i<list.getAdapter().getCount();i++)try{if(title.equals(field(list.getAdapter().getItem(i),"title")))return i;}catch(Exception ignored){}return -1;}
    private View findText(View root,String text){if(root instanceof TextView&&text.contentEquals(((TextView)root).getText()))return root;if(root instanceof android.view.ViewGroup){android.view.ViewGroup g=(android.view.ViewGroup)root;for(int i=0;i<g.getChildCount();i++){View found=findText(g.getChildAt(i),text);if(found!=null)return found;}}return null;}
    private void awaitState(DownloadStore.Job job,String expected)throws Exception {long end=System.currentTimeMillis()+20000;while(System.currentTimeMillis()<end){if(job.state.equals(expected))return;Thread.sleep(100);}throw new AssertionError("expected "+expected+" got "+job.state+" / "+job.stage);}
    private ScrollView content(Activity activity){ScrollView view=new ScrollView(activity);LinearLayout column=new LinearLayout(activity);column.setOrientation(1);
        for(int i=0;i<100;i++){TextView text=new TextView(activity);text.setText("相关测试视频 "+i);text.setTextSize(20);text.setHeight(110);column.addView(text);}view.addView(column);activity.setContentView(view);return view;}
    private void tap(float x,float y){long now=SystemClock.uptimeMillis();MotionEvent event=MotionEvent.obtain(now,now,MotionEvent.ACTION_DOWN,x,y,0);event.setSource(android.view.InputDevice.SOURCE_TOUCHSCREEN);sendPointerSync(event);event.recycle();event=MotionEvent.obtain(now,now+60,MotionEvent.ACTION_UP,x,y,0);event.setSource(android.view.InputDevice.SOURCE_TOUCHSCREEN);sendPointerSync(event);event.recycle();}
    private void swipe(float x,float y,float endX,float endY){long down=SystemClock.uptimeMillis();MotionEvent event=MotionEvent.obtain(down,down,MotionEvent.ACTION_DOWN,x,y,0);event.setSource(android.view.InputDevice.SOURCE_TOUCHSCREEN);sendPointerSync(event);event.recycle();
        for(int i=1;i<=8;i++){SystemClock.sleep(25);long now=SystemClock.uptimeMillis();event=MotionEvent.obtain(down,now,i==8?MotionEvent.ACTION_UP:MotionEvent.ACTION_MOVE,x+(endX-x)*i/8,y+(endY-y)*i/8,0);event.setSource(android.view.InputDevice.SOURCE_TOUCHSCREEN);sendPointerSync(event);event.recycle();}}
}
