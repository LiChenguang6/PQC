from pathlib import Path
import hashlib
import json
import subprocess

BASE = Path('/workspace/x2-analysis')
ROOT = BASE / 'ui-download-tests/results'


def frame_hashes(path):
    process = subprocess.run(['ffmpeg', '-v', 'error', '-i', str(path), '-map', '0:v:0', '-f', 'framemd5', '-'],
                             capture_output=True, text=True, check=True)
    return [line.rsplit(',', 1)[-1].strip() for line in process.stdout.splitlines()
            if line and not line.startswith('#')]


def main():
    records = []
    for case in ('clear', 'aes', 'direct'):
        path = ROOT / (case + '-downloaded.mp4')
        reference = BASE / ('capture-tests/fixture/capture-fixture.mp4' if case == 'direct'
                            else 'test-cache/reference/clear.mp4')
        info = json.loads(subprocess.run(['ffprobe', '-v', 'error', '-show_format', '-show_streams', '-of', 'json', str(path)],
                                        capture_output=True, text=True, check=True).stdout)
        subprocess.run(['ffmpeg', '-v', 'error', '-i', str(path), '-f', 'null', '-'], capture_output=True, check=True)
        frames = frame_hashes(path)
        assert frames and frames == frame_hashes(reference), case
        streams = [{'type': s['codec_type'], 'codec': s['codec_name']} for s in info['streams']]
        assert {s['type'] for s in streams} == {'video', 'audio'}, case
        records.append({'case': case, 'bytes': path.stat().st_size, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                        'seconds': float(info['format']['duration']), 'streams': streams,
                        'full_audio_video_decode': True, 'frames': len(frames), 'video_frames_match_reference': True})
    (ROOT / 'media-results.json').write_text(json.dumps(records, indent=2))
    print(json.dumps(records, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
