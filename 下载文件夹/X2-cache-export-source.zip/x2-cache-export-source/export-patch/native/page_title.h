/* UTF-16 snapshots written by pinned, no-allocation Dart leaf trampolines.
 * Sequence checks reject concurrent updates and a URL must match the player.
 * No pointers into the moving Dart heap are retained or read here. */
#include <link.h>
#include <stdatomic.h>
typedef struct TitleSnapshot { uint32_t title_len,uri_len,sequence,magic; uint16_t title[1024],uri[8192]; } TitleSnapshot;
static uintptr_t title_buffer_address;
static pthread_mutex_t title_buffer_lock=PTHREAD_MUTEX_INITIALIZER;
static int locate_title_buffer(struct dl_phdr_info *info,size_t size,void *opaque) {
    (void)size; (void)opaque;
#if defined(__aarch64__)
    const uintptr_t offset=0x8b1000;
#elif defined(__x86_64__)
    const uintptr_t offset=0x8c1000;
#else
    const uintptr_t offset=0;
#endif
    const char *name=strrchr(info->dlpi_name,'/');name=name?name+1:info->dlpi_name;
    if(!offset||strcmp(name,"libapp.so"))return 0;
    for(int i=0;i<info->dlpi_phnum;i++) {
        const ElfW(Phdr) *p=&info->dlpi_phdr[i];
        if(p->p_type==PT_LOAD&&(p->p_flags&PF_W)&&offset>=p->p_vaddr&&offset+0x19810<=p->p_vaddr+p->p_memsz) {
            title_buffer_address=info->dlpi_addr+offset;return 1;
        }
    }
    return 0;
}
static jstring page_title(JNIEnv *env,jstring uri) {
    /* Called from the capture worker; resolution and copying are serialized. */
    pthread_mutex_lock(&title_buffer_lock);
    if(!title_buffer_address)dl_iterate_phdr(locate_title_buffer,NULL);
    jstring result=NULL;
    if(title_buffer_address) {
        for(int slot=0;slot<5&&!result;slot++) {
        uintptr_t offset=slot?0x6000+(uintptr_t)(slot-1)*0x5000:0;
        const volatile TitleSnapshot *p=(const volatile TitleSnapshot *)(title_buffer_address+offset);
        uint32_t before=__atomic_load_n(&p->sequence,__ATOMIC_ACQUIRE);
        if(!(before&1)&&p->magic==0x35543258&&p->title_len>0&&p->title_len<=1024&&p->uri_len>0&&p->uri_len<=8192) {
            TitleSnapshot copy;memcpy(&copy,(const void *)p,sizeof(copy));
            __atomic_thread_fence(__ATOMIC_ACQUIRE);
            uint32_t after=__atomic_load_n(&p->sequence,__ATOMIC_ACQUIRE);
            if(before==after&&!(after&1)&&copy.title_len<=1024&&copy.uri_len<=8192&&(*env)->GetStringLength(env,uri)==(jsize)copy.uri_len) {
                const jchar *chars=(*env)->GetStringChars(env,uri,NULL);
                if(chars) {
                    if(!memcmp(chars,copy.uri,copy.uri_len*2))result=(*env)->NewString(env,copy.title,(jsize)copy.title_len);
                    (*env)->ReleaseStringChars(env,uri,chars);
                }
            }
        }
        }
    }
    pthread_mutex_unlock(&title_buffer_lock);return result;
}

JNIEXPORT jboolean JNICALL Java_org_x2_export_PlayerCapture_nativeManageRequested(JNIEnv *env,jclass type,jboolean test) {
    (void)env;(void)type;
    pthread_mutex_lock(&title_buffer_lock);
    if(!title_buffer_address)dl_iterate_phdr(locate_title_buffer,NULL);
    uint32_t event=0;
    if(title_buffer_address) {
        uint32_t *flag=(uint32_t *)(title_buffer_address+0x4900);
        __atomic_store_n(flag+1,test?1:0,__ATOMIC_RELEASE);
        event=__atomic_exchange_n(flag,0,__ATOMIC_ACQ_REL);
    }
    pthread_mutex_unlock(&title_buffer_lock);
    return event?JNI_TRUE:JNI_FALSE;
}

JNIEXPORT jstring JNICALL Java_org_x2_export_PlayerCapture_nativeTestState(JNIEnv *env,jclass type,jboolean test) {
    (void)type;char result[240];
    pthread_mutex_lock(&title_buffer_lock);
    if(!title_buffer_address)dl_iterate_phdr(locate_title_buffer,NULL);
    if(title_buffer_address){
        uint32_t *p=(uint32_t *)(title_buffer_address+0x4904);
        __atomic_store_n(p,test?1:0,__ATOMIC_RELEASE);
        snprintf(result,sizeof(result),"bridge=ready flag=%u pause_seen=%u pause_skipped=%u",__atomic_load_n(p,__ATOMIC_ACQUIRE),__atomic_load_n(p+7,__ATOMIC_RELAXED),__atomic_load_n(p+8,__ATOMIC_RELAXED));
    }else snprintf(result,sizeof(result),"bridge=unavailable flag=unknown");
    pthread_mutex_unlock(&title_buffer_lock);return (*env)->NewStringUTF(env,result);
}

JNIEXPORT jint JNICALL Java_org_x2_export_PlayerCapture_nativeHomeReady(JNIEnv *env,jclass type){
    (void)env;(void)type;int result=-1;pthread_mutex_lock(&title_buffer_lock);
    if(!title_buffer_address)dl_iterate_phdr(locate_title_buffer,NULL);
    if(title_buffer_address)result=__atomic_load_n((uint32_t *)(title_buffer_address+0x4930),__ATOMIC_ACQUIRE)?1:0;
    pthread_mutex_unlock(&title_buffer_lock);return result;
}

/* Copied numeric fields only; the supplied player URI must match the same seqlock sample. */
JNIEXPORT jstring JNICALL Java_org_x2_export_PlayerCapture_nativePageDetails(JNIEnv *env,jclass type,jstring uri){
    (void)type;char text[360];snprintf(text,sizeof(text),"detail_match=none\n");
    if(!uri)return (*env)->NewStringUTF(env,text);
    pthread_mutex_lock(&title_buffer_lock);if(!title_buffer_address)dl_iterate_phdr(locate_title_buffer,NULL);
    if(title_buffer_address){
        const volatile TitleSnapshot *p=(const volatile TitleSnapshot *)title_buffer_address;
        uint32_t before=__atomic_load_n(&p->sequence,__ATOMIC_ACQUIRE);
        if(!(before&1)&&p->magic==0x35543258&&p->uri_len>0&&p->uri_len<=8192){
            TitleSnapshot copy;int64_t values[6];memcpy(&copy,(const void *)p,sizeof(copy));memcpy(values,(const void *)(title_buffer_address+0x4820),sizeof(values));
            __atomic_thread_fence(__ATOMIC_ACQUIRE);uint32_t after=__atomic_load_n(&p->sequence,__ATOMIC_ACQUIRE);
            if(before==after&&!(after&1)&&values[5]==0x3531444d&&copy.uri_len>0&&copy.uri_len<=8192&&(*env)->GetStringLength(env,uri)==(jsize)copy.uri_len){
                const jchar *chars=(*env)->GetStringChars(env,uri,NULL);
                if(chars){if(!memcmp(chars,copy.uri,copy.uri_len*2))snprintf(text,sizeof(text),"detail_match=exact_uri\ndetail_video_id=%lld\ndetail_play_time_raw=%lld\ndetail_can_watch=%lld\ndetail_video_type=%lld\ndetail_reason_type=%lld\n",(long long)values[0],(long long)values[1],(long long)values[4],(long long)values[2],(long long)values[3]);(*env)->ReleaseStringChars(env,uri,chars);}
            }
        }
    }
    pthread_mutex_unlock(&title_buffer_lock);return (*env)->NewStringUTF(env,text);
}
