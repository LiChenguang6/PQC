# X2 社保存导出版补丁源码（export15）

保留原应用浏览、播放入口，新增并排“下载”“管理”按钮，独立前台服务完成并发下载和本地 MP4 封装。版本码 23，沿用此前导出版签名和包名，可直接更新。

## 使用

首次点击“下载”选择一次系统目录，以后点击直接排队，不离开原视频。可继续浏览、退到桌面或熄屏。通过“管理”取消、重试、删除指定任务；已完成的 MP4 默认保留。“下载设置”修改目录和并发数量可输入 1–32（默认 3），新目录只影响新任务。“导出已有缓存”保留。

允许后台运行和通知可降低系统中断机会。强行停止、厂商省电策略仍可中断；重新打开管理页会重新下载中断任务，不支持字节断点续传。过期播放链接需重新播放后新建任务。原版和副本数据独立。

## export15：已完成视频封面卡片与详情对照

下载完成页改为16:9封面卡片、标题和时长角标；本地MediaMetadataRetriever后台从精确SAF文档提取，最多640x360，两个后台线程、12MiB内存缓存、128张/32MiB私有磁盘缓存。按任务ID及文档URI绑定异步结果，复用视图时拒绝错图；坏文件显示占位。普通点按仍携带读取授权启动系统播放器，长按和多选删除保留。

播放源报告新增与完整URI精确匹配的详情原始数值：videoId、playTime、canWatch、videoType、reasonType。两架构只在原长视频getter的无调用复制区读取类型245模型，所有数值与原标题/URI共用序列提交。短视频复制钩子保持原逻辑，JNI只读复制区、不读Dart堆、不保留堆指针。未知/未完成/错误URI均不报告详情；不输出鉴权、地址或标题。先前stage3输出摘要因新增复制代码而变化，patch_tasks_short.PINS基于锁定原始输入重算并验证。

本版仍是继续定位真实12秒清单的测试版，不代表获得完整视频或改变服务器VIP权限。测试见validation/export15-tests。

## export14：手机 VPN 环境下的播放源检查（诊断测试版）

新增“管理 → 下载设置 → 检查当前播放源（复制）”。开发测试开启后，数值诊断线程每秒尝试保存当前正在播放的连接到单份内存快照，30秒过期；关闭开关后清除。用于进入管理界面导致原播放器暂停时进行检查，不写磁盘或复制凭据。报告标明live/recent_cached与快照年龄。后台读取原播放器当前URI与已有请求上下文，通过手机网络重新请求清单；复用原下载器的TLS、重定向、跨域凭据隔离及有界读取。最多四层清单、每份4MiB，不读取分片与密钥，45秒截止及取消。直接媒体只检查前缀，不下载整个文件。

报告含版本、源地址的截短SHA256标识、播放器数值状态、HLS分片数、EXTINF总时长、ENDLIST及加密类型标记。复制内容不含URI、标题、头值、密钥、账户或原始清单。主清单沿用下载器最高带宽选择；当前响应与原播放时的响应可能不同，不能当作服务器VIP限制证明。失败只报告异常类与可提取的HTTP状态码。

本版没有修改服务器账户、认证令牌或VIP出站参数，也未声称真实目标视频已超过20秒。用途是利用用户手机可用的VPN取得此前缺失的媒体响应证据。验证见validation/export14-tests。

## export13：启动封面时机修正

首个Flutter帧可能仍是原启动图片，改为等待主页导航构建信号；关闭后不再重新挂载，图片加载不会因短暂视图替换而丢失。保留手动关闭及30秒异常兜底上限，不增加强制等待。两种ABI指令仿真和测试专用就绪标记验证分开记录，真实平台首页仍未验证。

## export12：MP4删除选项、外观设置与播放诊断

已完成文件可选择仅删记录或同时删除实际MP4。单项长按菜单、完成分区多选删除均有明确选项及二次确认。物理删除使用独立后台线程与已保存的精确SAF文档URI，成功才移除记录；权限／提供程序失败时保留记录，状态说明原因。删除状态纳入服务前台生命周期；中断后恢复成可重试记录。普通取消／记录删除仍保留原语义。

设置新增“名称、图标与开屏”。名称、归一化PNG图标用于创建／更新本应用的固定桌面快捷方式；不动态改APK清单或应用列表条目。开屏图片保存为应用私有PNG，在原启动Activity内部显示可关闭封面，主页底部导航构建完成后移除（export13修正），不增加初始化等待。系统启动图标仍由Android控制。图片通过系统选择器读取，缩放并原子保存，恢复默认只清除外观配置及两张私有图片。

设置新增可复制播放诊断，开关同步与两处20秒分支计数沿用下节；修正了未发布诊断实现中引用释放循环的错误。真实禁区在红米Turbo4Pro/Android16的20秒暂停仍未确认解决，需要该设备复制诊断的实际数值。不能把原MPV测试媒体当作平台验证。

验证脚本见 validation/export12-tests：实际SAF文件删除／保留／失败保留记录、单项与批量选择、桌面固定及改名更新、图片导入及非法图片保护、封面关闭／重置、原MPV只读数值与复制、后台控制回归。原Flutter资源及libmpv均保留。

## export11 诊断实现（未发布，已并入 export12）：开关即时同步与本机播放轨迹

用户已确认 export10 在红米 Turbo 4 Pro / Android 16 仍约20秒暂停／回退，故没有将该版指令测试视为真实平台验收成功。

开发开关增加独立 JNI 同步入口，设置切换时立即同步，Activity 轮询和诊断采样也会同步；不再把开关同步耦合到 MainActivity 有焦点、Flutter 首帧等导航条件。原管理事件消费条件保留。

在位置回调补丁中记录超过20秒进入分支次数 pause_seen，以及开启开关后跳过暂停／回退的次数 pause_skipped。没有新分配／新调用，保留原进度存储和通知。40个回调用例验证控制行为与计数。

下载设置新增“播放诊断（复制）”，设置页可滚动。诊断显示版本、进程位数、支持ABI、系统版本、配置开关、原生桥状态／实际开关／命中计数，并通过独立工作线程读取原 MPV 弱客户端的 time-pos、duration、pause、eof-reached、idle-active。最近45条数值记录仅保存在进程内存；不记录视频地址、标题、请求头或账户信息，不改播放器属性。打开管理页本身可能暂停原视频，故需检查之前的时间序列。

真实设备停止后，在45秒内打开管理→下载设置→播放诊断→复制，将文字反馈用于定位。此版未声称修复 Android16 设备上的实际停止，也未验证真实禁区视频 >20秒。只使用云端模拟器检查诊断与开关同步，禁止把测试媒体当作平台视频。

## export10 测试版：补上播放器独立的暂停／回退分支

PlayerController::_playerStreamSubscriptionListenerPosition 在秒数 >20 且 field_47=false 时独立调用 pause 和 seek。export9 仅跳过上层 updateTryWatchEnd，未覆盖这条实际停止链路。本版在比较后的条件分支处加入无调用、无分配的开关检查：开发测试开启时跳过暂停与回退；关闭时保留原条件。位置存储、上层进度回调、notifyUpdate 保留，手动暂停／拖动不改。

两个 ABI 共 40 个完整位置回调测试覆盖 19/20/21/25/65 秒、canWatch 开／关、测试开关开／关。暂停、回退、通知由桩记录，并非真实视频播放。禁区入口 Rx 读取修复与之前下载管理均保留；全部 dex、Java 和 assets 与 export9 一致。

真实“禁区 → 任意视频 → 连续播放 >20 秒”仍未验证通过。新连通性检查中，两个配置入口 HTTP 403 / error code 1010；四条内置 API 主机在代理 CONNECT 阶段 403。无法获得真实清单／分片，不能认定服务器提供完整内容。本版是本地修复候选，不能替代真实平台验收。见 validation/export10-tests/network-results.json 与 pause-results.json。

## export9：保留禁区页面的响应式依赖

export8 的开发入口在 UserService.isForbiddenVip 开头直接返回 true，绕过 userInfo Rx.value 读取。ForbiddenPage 的 Obx 回调只通过该 getter 读取响应式值，RxNotifier.notifyChildrens 在没有订阅依赖时抛出 GetX improper-use 异常，可能表现为白色错误页。

将覆盖点移到 getter 的统一返回尾部。原始 Rx.value 调用、会员判断、分配／GC 安全点、整个原函数体在尾部之前逐字保留；只在开关打开时覆盖最终返回值。开关关闭保留原返回值。ARM64/x86_64 共 40 个完整函数指令用例对比 export8 与 export9：export8 开启时零次响应式读取，export9 始终读取一次或两次，取决于原会员分支；同时验证栈恢复和返回值。

Java 下载逻辑、所有 dex、所有 assets 与 export8 逐字一致。真实平台仍不可达，不能把指令测试当成真实禁区页面及视频的端到端验证。本次报告见 validation/export9-tests。

## export8：双按钮、异步任务列表和分区批量管理

所有 ABI 恢复并排、可拖动的“下载／管理”。管理按钮直接进入原生页面，不依赖左侧标签。原生导航等待 Flutter 首帧后再打开页面。左侧标签沿用旧补丁，未继续调整。

进程启动时在单独线程预读加密队列；管理页立即绘制内存快照，再每 750ms 异步读取状态，不在 UI 线程等待密钥、文件或目录提供程序。快照只含标题、状态和文件 URI，不复制播放签名或认证头。

“正在下载”包含等待、进行中、暂停、失败、取消记录；“下载完成”包含成功项。完成项普通点击通过带读权限和 ClipData 的 ACTION_VIEW 打开 MP4；需系统播放器支持。长按完成项可以删除记录。两区都有多选、全选和批量删除；未完成区支持批量暂停、继续、取消。操作通过一次服务 Intent 传递稳定的任务 ID 列表，刷新不改变选中项，删除完成记录保留 MP4。

开发测试开关额外跳过 VideoPlayByVideoIdController 的本地 20 秒试看结束标记，默认关闭。只在原调用位置转到无分配／无新增调用的叶函数：关闭时尾跳原函数，开启时返回 Null。ARM64/x86_64 覆盖，ARMv7 不变。不会修改请求或服务器账号；真实平台不可达，不能保证服务端提供完整媒体。验证记录见 validation/export8-tests。

## export6：任务控制、主页入口及短视频标题（保留）

`MediaDownloader` 的取消监控线程关闭连接／流时捕获运行时异常，解决日志中确认的 Okio `Unbalanced enter/exit` 导致进程退出。前台服务每次 onStartCommand 重新履行 startForeground，覆盖停止／新命令交错的恢复路径。

任务增加持久化 paused 状态，工作线程在下载检查和本地封装／写出检查处协作等待。暂停让出并发名额，恢复等待名额，不超出设置值；暂停线程与当前任务最多共 64 个。只有同一进程和仍有效连接可延续当前传输；进程结束后工作文件清理，或连接失效时，恢复可能重新下载。本实现不承诺字节 Range 断点续传。

`patch_tasks_short.py` 固定输入为 export5 的两份 64 位快照。VideoDetail.authPlayUrl getter 的无调用片段复制 field_53 标题和最终 URL，使用 4 槽短视频快照，保留相邻预加载标题。JNI 比对当前 MPV URL 后采用标题。原详情页的独立快照保留。

MainController.changeMainTabIndex 的索引 0 写入原生管理事件，同时维持索引 1（视频），避免进入空白活动页。按钮标题在绘制时把“活动”替换为原存在的“下载”对象，不修改字符串本体。Java 只在窗口有焦点时消费事件并打开原 DownloadTasksActivity。export6 曾移除 64 位“管理”按钮；export8 已恢复双按钮。

自有应用开发设置的 forbidden-entry 默认为 false。开启时仅让客户端 UserService.isForbiddenVip getter 放行，关闭时执行原代码；并不修改服务器 VIP、账号资料或其他 VIP 功能。原资料来自 user/base/info，入口判断接受 vipType 7/8。真实服务器不可达，不能声称恢复服务器设备／账号授权。测试开关和事件只占匿名 RW 空间，开关持久化于应用私有配置。

本次验证脚本在 validation/export6-tests；之前版本记录仅作为历史证据。

## export5：主页、标题及开屏（保留）

`patch_launch_title.py` 默认将 MainController 的初始值、`index` 入口与缺省路由选择设为“视频”（索引 1）。保留标签布局和显式其他标签路由。

原启动 `_doLoading` 的网络检查、并发选线、登录、广告数据拉取及 AppService 网络初始化全部保留。最后成功路径调用原 `_tapJumpAction`；只取消广告计数器读取与非零计数拦截，原 StorageService/AppService 就绪判断与失败提示保留。该动作原有的 offHome 路径进入主页。原广告组件在初始化完成后才创建，计时器每秒减 1，初值 5；现在无需创建或点击它。连接超时配置为 15 秒，但失败后备用请求、登录等会影响总启动耗时，不能把它当作总耗时上限。

播放页 URL getter 的两个无调用叶子片段将页面详情模型中的实际标题及生成的播放 URL 复制到新增匿名 RW 内存。只复制 OneByteString/TwoByteString 的内容，不持有 Dart 引用，不调用函数或分配对象。序列号保护读取；JNI 只在完整快照 URL 与当前 MPV path 完全一致时采用该标题，切换中或不匹配时回退到播放器标题。该绑定覆盖原 VideoPlayByVideoId 详情播放页；尚未验证其他播放器入口。RW 段仅增大内存大小，不增加文件或读写 Dart 堆；RX 叶子代码位于原零填充区。

`VideoFilename.mp4` 使用入队时固定的标题创建输出，保留中文和表情，替换控制字符及 `/\:*?"<>|`，限制 UTF-8 文件名长度，避免重复扩展名。同名任务交给 DocumentsProvider 原子创建不同文件；API 29 Downloads provider 实测追加 ` (1)`。名称缺失时为“当前播放视频”；旧任务保留此前入队记录中的标题。设置和管理原有行为保留。

这些 AOT 变化覆盖 ARM64 和 x86_64；ARMv7 保留原主页、启动流程和播放器标题来源。Java 输出命名功能覆盖三个 ABI。云端无法访问实际平台，真实内容标题与启动跳转仍需在用户可连通的平台上观察；受控播放与指令验证的范围见 VALIDATION.md。

## export4 已有交互修正（保留）

“下载”“管理”按钮作为一组拖动，移动超过触摸阈值后取消按钮点击，避免误下载。位置用相对于可用区域的比例保存，恢复时限制在可见范围内。普通点击保留原行为，未覆盖区域继续由原页面接收滑动。

“同时下载数量”改为整数输入框，可设置 1–32，拒绝 0、越界和无效值；后台线程池按该配置同步调整。降低并发时已启动的任务不中断。用户已确认下载队列显示正常，本次保留原管理列表实现。

## 原有网络英文提示与进入播放器弹窗

`patch_ui.py` 在已锁定的 ARM64/x86_64 快照中移除 `ApiExceptionHandler._debugPrintError` 内将原始网络异常展示为 toast 的那一个调用，保留后续日志及其他错误处理、登录和权限提示。

播放器 onInit 原来必定创建 VerticalGroupAds 弹层，即使推广图片列表为空也可能留下空白遮罩。现在直接调用该弹层正常关闭时原有的 `_showAllEntranceAdsDismissAction`，继续详情加载、播放器事件绑定等初始化，跳过入场推广容器。没有修改播放授权判断或其他对话框。这两项补丁与既有滚动补丁一样，目前覆盖 ARM64、x86_64；ARMv7 保留原样。

## 同类视频数量的调查结果

原客户端只调用一次 `video/guessLike`，查询只有 videoId；返回的列表直接赋给推荐数据并显示，没有发现本地 take(12)，也没有翻页或触底续载。这能解释用户观察到的单批 12 项，但当前云机不能验证服务器是否接受分页参数或更大批次。本版没有实现无限相关推荐，也不声称已经突破 12 项。

## 后台实现

`DownloadService` 持有前台 dataSync 通知和活动期间的 PARTIAL_WAKE_LOCK；工作线程独立于 Activity，线程池随配置调整为 1–32，按队列上限调度。每个任务使用隔离的下载目录和 CookieManager。取消、删除不会取消其他任务；网络操作受超时约束。私有队列使用 AndroidKeyStore AES-GCM 和 AtomicFile 保存，进程重启恢复待处理任务。SAF tree URI 获取持久授权，保存目录只需选择一次。目标 MP4 在本地封装与完整性验证后才创建，失败、取消清理半成品。

## 原推荐区域滚动修复

原 `_buildTabBarViewZeroChildWidget` 返回 Padding/GetBuilder/Wrap，卡片位于 TabBarView 中且没有内层纵向滚动容器。`patch_scroll.py` 把最外层 Padding 替换为带同样 padding/child 的 SingleChildScrollView，其余卡片和回调保留。

只接受指定 SHA-256 的 ARM64、x86_64 Dart 3.6.2 snapshot。现有 allocation call 改用原 snapshot 的 SingleChildScrollView allocation stub，原调用返回 PC、栈图保持。返回处跳转到 ELF RX 段后零填充区中的无调用初始化代码，设置 8 个字段后跳回原 epilogue。只扩大该 RX 段在已有填充中的大小，不增加文件长度、不更改 libflutter/libmpv。ARMv7 保留原样，不声称已修复其滚动。

指令模拟验证了两种架构的所有字段及寄存器/栈保持。当前云环境不能连接真实平台页面，真实相关推荐操作仍需实机确认；不能把启动与模拟检查当作真实平台端到端验证。

## 实现与范围

- `libx2player.so` 通过原 media_kit 的 Create/Dispose 生命周期建立独立 MPV weak client，只读原播放器属性，不修改原播放器库或消费 Dart 的事件队列。仅接受实际加载、有 `time-pos` 且未暂停的唯一 HTTP(S) 播放器；多播放器、切换中、未完成加载或不支持的本地源会明确拒绝。
- 点击入口时在后台线程即时读取地址、User-Agent、Referer 和原始 header 数组，保留 query。地址和请求凭据不放入 Intent、不写公开日志；排队任务通过 AndroidKeyStore AES-GCM 加密保存到私有文件，完成后清除请求凭据。原本地缓存服务会引导至缓存导出，保留原始 IV 处理。
- `MediaDownloader` 使用 Android HttpURLConnection，保留 TLS 校验，跟随有限重定向并以最终 URI 解析相对引用；支持无后缀 HLS、普通有限媒体清单、AES-128 及简单复用音视频的 master variant。使用独立 CookieManager，捕获的鉴权头仅在原 origin 使用；不修改全局 CookieHandler。
- 下载失败显示阶段和 HTTP 状态，不输出签名 query 或密钥。临时媒体和密钥在保存、失败或取消后删除；失败时删除系统目标文档。直接媒体要求可探测时长，仍校验输出轨道、编码和完整时长。
- 静态确认缓存位于 `Context.getDir("flutter", 0)/downloads/video/<videoId>`。
- `index.m3u8` 是完成标记；导出优先读取 `index.raw.m3u8`，保留原 `IV`、`MEDIA-SEQUENCE` 和分片顺序，再把媒体与密钥映射为同一缓存目录的本地文件。
- `enc.key` 为普通 AES-128 HLS 的本地 16 字节密钥；不解析加密 Hive 记录库，不访问其他应用数据。
- 通过 `libx2export.so` 内静态链接的最小 FFmpeg 6.0 本地媒体处理组件，进行流复制、必要的自动位流过滤和 MP4 封装。它不启用网络协议；符号隐藏并绑定在本组件内部，避免与原 `libmpv.so` 的 FFmpeg 冲突。原有 libmpv/libflutter 等 19 个原生库原字节保持不变；ARM64、x86_64 的 libapp.so 接受本文限定的滚动、UI、启动与标题复制修改。
- 原 APK 的 `libmpv.so` 没有编译 MP4 封装器，因此仅调用它的导出符号不能完成本任务；已依据实际 Android 运行测试选择独立最小封装组件。
- 已有缓存导出对缺文件、空分片、缺密钥、错误密钥长度、路径越界、同名分片冲突、主清单、独立音轨、byterange、密钥轮换与不支持的加密方式明确拒绝。播放源下载支持普通 AES-128 密钥切换；复杂独立音轨、fMP4 MAP、byterange、直播和 DRM/SAMPLE-AES 暂不支持。
- 缺失原始清单时，若加密本地清单也没有显式 IV，无法排除原下载器曾丢失 IV，会拒绝导出并要求重新下载。
- 输出会重新打开检查轨道数量、编码和预期时长；失败时不将半成品当作成功。所选目标为系统文件保存 URI，无需新增全盘存储权限。
- 不伪造业务令牌或设备身份，不移除 DRM；当前播放源拒绝请求时明确报错。不读取其他应用的私有目录。
- 缓存列表只显示视频 ID 与缓存大小，不声称恢复了加密下载记录中的影片标题。

## 复现构建

需要 Linux x86_64、Python 3、Java 21 运行时和 `keytool`，以及原 APK。源码不包含原 APK 和本地签名私钥。

运行：

```bash
python3 bootstrap_tools.py
bash ../minimal-ffmpeg/fetch-source.sh
bash ../minimal-ffmpeg/build.sh x86_64 arm64-v8a armeabi-v7a
X2_INPUT_APK=/absolute/path/app.apk python3 build_patch.py
```

默认工具位置为源码同级的 `../patch-tools`，可通过 `X2_PATCH_TOOLS` 覆盖；最小 FFmpeg 库默认为 `../minimal-ffmpeg/<ABI>/lib`，可通过 `X2_FFMPEG_ROOT` 覆盖。自定义 NDK 路径时运行媒体构建脚本需设置 `X2_NDK_ROOT`。结果位于 `../output/`：APK、签名验证文本与 `build-info.json`。首次构建会生成本地开发签名；保留自己的 `build/local-export-key.p12` 才能后续更新自己生成的导出版。此签名不等于原应用签名。

工具为 Apktool 2.11.1、ECJ 3.41.0、Android Platform 35、Build Tools 35.0.0 与 NDK r28c。Google 工具按官方仓库元数据摘要校验；Maven 构件按仓库发布的摘要校验（Apktool 为 SHA-512，ECJ 为 SHA-1）。FFmpeg 6.0 的匹配头文件及许可证随源码放在 `third_party/ffmpeg-6.0`。

构建脚本从输入 APK 重新解包，修改包作用域的 provider authorities/自定义权限、新增下载与配置 Activity 和前台服务，并在原 FlutterActivity/壳入口的 `onCreate` 最后添加入口。`inject_player_capture.py` 在 media_kit 输出管理器的 Create/Dispose 与 engine detach 注入三处只读观察器生命周期回调。原始 FlutterActivity 的混淆名称为 `c9/d`；本补丁只适用于本次分析的 APK 版本，不应直接套用于其他版本。

## 验证说明

验证记录以最终交付的分析报告为准。合成测试素材用于验证明文 HLS、带显式 IV 的 AES-128 HLS、分片/密钥缺失等情况；合成测试通过不代表第三方在线服务一定可连接，也不代表原应用所有媒体格式都已覆盖。
