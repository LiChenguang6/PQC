package org.x2.uitests;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Intent;
import android.os.Bundle;
import org.x2.capturetests.CaptureNative;
import org.x2.export.PlayerCapture;

/** Test APK only. Creates a genuine original-mpv player for controlled HTTP media. */
public final class DownloadInstrumentation extends Instrumentation {
    private Bundle options;
    @Override public void onCreate(Bundle args) { options = args; start(); }
    @Override public void onStart() {
        long handle = 0;
        try {
            Intent launch = new Intent();
            launch.setClassName(getTargetContext(), "com.tencent.a.SetupInfoActivity");
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            Activity activity = startActivitySync(launch);
            if (activity == null) throw new IllegalStateException("launcher did not start");
            System.loadLibrary("capturetest");
            CaptureNative.load(getTargetContext().getApplicationInfo().nativeLibraryDir + "/libmpv.so");
            String uri = options.getString("fixture");
            handle = CaptureNative.create(uri, "X2ControlledUiTest/1.0", "", new String[0], "受控测试视频", false);
            PlayerCapture.register(handle);
            long deadline = System.currentTimeMillis() + 30000;
            boolean ready = false;
            while (System.currentTimeMillis() < deadline) {
                try {
                    PlayerCapture.Source source = PlayerCapture.snapshot();
                    if (uri.equals(source.uri)) { ready = true; break; }
                } catch (java.io.IOException expected) { }
                Thread.sleep(100);
            }
            if (!ready) throw new IllegalStateException("controlled playback not ready");
            Bundle report = new Bundle(); report.putString("result", "CONTROLLED_PLAYER_READY");
            sendStatus(1, report);
            // Host UI automation now uses the production overlay, capture, downloader and SAF page.
            Thread.sleep(180000);
            PlayerCapture.unregister(handle); CaptureNative.terminate(handle); handle = 0;
            finish(Activity.RESULT_OK, report);
        } catch (Throwable error) {
            if (handle != 0) { PlayerCapture.unregister(handle); CaptureNative.terminate(handle); }
            Bundle report = new Bundle(); report.putString("failure", error.getClass().getSimpleName() + ": " + error.getMessage());
            finish(Activity.RESULT_CANCELED, report);
        }
    }
}
