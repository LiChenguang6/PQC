package org.x2.export;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import java.util.concurrent.atomic.AtomicBoolean;

public final class ExportEntry {
    public static void install(final Activity activity) {
        ViewGroup content=(ViewGroup)activity.findViewById(android.R.id.content);
        if(content==null||content.findViewWithTag("x2-download-buttons")!=null)return;
        View underlying=content.getChildCount()==0?null:content.getChildAt(0);
        GestureRow row=new GestureRow(activity,underlying);row.setTag("x2-download-buttons");
        final Button download=new Button(activity);download.setText("下载");Button manage=new Button(activity);manage.setText("管理");
        for(Button b:new Button[]{download,manage}) {b.setTextSize(12);b.setTextColor(Color.WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xDD395A85));row.addView(b,new LinearLayout.LayoutParams(0,-1,1));}
        float density=activity.getResources().getDisplayMetrics().density;
        FrameLayout.LayoutParams params=new FrameLayout.LayoutParams(Math.round(152*density),Math.round(44*density),Gravity.RIGHT|Gravity.TOP);
        params.rightMargin=Math.round(8*density);params.topMargin=Math.round(80*density);activity.addContentView(row,params);
        manage.setOnClickListener(v->activity.startActivity(new Intent(activity,DownloadTasksActivity.class)));
        download.setOnClickListener(v->{
            download.setEnabled(false);download.setText("读取中");final AtomicBoolean done=new AtomicBoolean();
            final Handler main=new Handler(Looper.getMainLooper());
            final Runnable timeout=()->{if(done.compareAndSet(false,true)){download.setEnabled(true);download.setText("下载");if(!activity.isFinishing())message(activity,"读取视频超时，请在当前视频播放时重试。");}};
            main.postDelayed(timeout,15000);
            new Thread(()->{
                PlayerCapture.Source source=null;String failure=null;
                try {source=PlayerCapture.snapshot();}catch(Exception e){failure=e.getMessage();}
                final PlayerCapture.Source captured=source;final String error=failure;
                main.post(()->{
                    if(!done.compareAndSet(false,true))return;main.removeCallbacks(timeout);download.setEnabled(true);download.setText("下载");
                    if(activity.isFinishing()||activity.isDestroyed())return;
                    if(captured==null){message(activity,error==null?"请先播放视频再点击下载。":error);return;}
                    if(isLocalCache(captured.uri))activity.startActivity(new Intent(activity,CacheExportActivity.class));
                    else PlayingExportActivity.open(activity,captured);
                });
            },"X2-read-player").start();
        });
    }
    private static void message(Activity activity,String text){new AlertDialog.Builder(activity).setTitle("下载").setMessage(text).setPositiveButton("知道了",null).show();}
    private static boolean isLocalCache(String value){try{java.net.URI uri=new java.net.URI(value);String host=uri.getHost();return ("localhost".equalsIgnoreCase(host)||"127.0.0.1".equals(host)||"[::1]".equals(host))&&uri.getPath()!=null&&uri.getPath().matches("/[0-9]+/index\\.m3u8");}catch(Exception e){return false;}}

    /** A swipe starting on a floating button is handed to the original page, not swallowed as a drag. */
    public static final class GestureRow extends LinearLayout {
        private final View underlying;private final int slop;private MotionEvent down;private boolean forwarding;
        GestureRow(Activity activity,View underlying){super(activity);this.underlying=underlying;slop=ViewConfiguration.get(activity).getScaledTouchSlop();setOrientation(HORIZONTAL);setMotionEventSplittingEnabled(false);}
        @Override public boolean dispatchTouchEvent(MotionEvent event){
            int action=event.getActionMasked();
            if(action==MotionEvent.ACTION_DOWN){clear();down=MotionEvent.obtain(event);}
            if(!forwarding&&underlying!=null&&down!=null&&action==MotionEvent.ACTION_MOVE&&Math.abs(event.getY()-down.getY())>slop){
                MotionEvent cancel=MotionEvent.obtain(event);cancel.setAction(MotionEvent.ACTION_CANCEL);super.dispatchTouchEvent(cancel);cancel.recycle();
                forwarding=true;send(down);
            }
            if(forwarding){send(event);if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL)clear();return true;}
            boolean handled=super.dispatchTouchEvent(event);if(action==MotionEvent.ACTION_UP||action==MotionEvent.ACTION_CANCEL)clear();return handled;
        }
        private void send(MotionEvent event){int[] own=new int[2],target=new int[2];getLocationOnScreen(own);underlying.getLocationOnScreen(target);MotionEvent copy=MotionEvent.obtain(event);copy.offsetLocation(own[0]-target[0],own[1]-target[1]);underlying.dispatchTouchEvent(copy);copy.recycle();}
        private void clear(){forwarding=false;if(down!=null){down.recycle();down=null;}}
        @Override protected void onDetachedFromWindow(){clear();super.onDetachedFromWindow();}
    }
    private ExportEntry() { }
}
