/*
 * Read-only libmpv client observer. Original libmpv and Flutter AOT are unchanged.
 * The public ABI declarations below are the small subset of mpv/client.h used
 * here (mpv client API major 2). No libmpv/FFmpeg symbol is linked into this DSO.
 */
#include <jni.h>
#include <dlfcn.h>
#include <math.h>
#include <pthread.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

typedef struct mpv_handle mpv_handle;
typedef struct mpv_node mpv_node;
typedef struct mpv_node_list {
    int num;
    mpv_node *values;
    char **keys;
} mpv_node_list;
struct mpv_node {
    union {
        char *string;
        int flag;
        int64_t int64;
        double double_;
        mpv_node_list *list;
        void *ba;
    } u;
    int format;
};
typedef struct mpv_event {
    int event_id;
    int error;
    uint64_t reply_userdata;
    void *data;
} mpv_event;

enum { F_STRING = 1, F_FLAG = 3, F_DOUBLE = 5, F_NODE = 6, F_NODE_ARRAY = 7,
       EVENT_SHUTDOWN = 1, MAX_PLAYERS = 16, MAX_HEADERS = 128,
       MAX_FIELD = 32768, MAX_HEADER_BYTES = 65536 };

typedef struct Api {
    unsigned long (*version)(void);
    mpv_handle *(*weak)(mpv_handle *, const char *);
    int (*get)(mpv_handle *, const char *, int, void *);
    mpv_event *(*wait)(mpv_handle *, double);
    void (*destroy)(mpv_handle *);
    void (*free_)(void *);
    void (*free_node)(mpv_node *);
} Api;

typedef struct Entry {
    uint64_t original;
    mpv_handle *weak;
    int refs;
    int closing;
} Entry;

typedef struct SourceData {
    char *uri, *agent, *referrer, *title;
    char **headers;
    int header_count;
} SourceData;

static Api api;
static void *mpv_library;
static pthread_mutex_t api_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t registry_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t registry_changed = PTHREAD_COND_INITIALIZER;
static Entry *entries[MAX_PLAYERS];
static uint64_t registry_epoch;

static int load_api(void) {
    pthread_mutex_lock(&api_lock);
    if (mpv_library) { pthread_mutex_unlock(&api_lock); return 1; }
    void *lib = NULL;
#ifdef RTLD_NOLOAD
    lib = dlopen("libmpv.so", RTLD_NOW | RTLD_LOCAL | RTLD_NOLOAD);
#endif
    if (!lib) lib = dlopen("libmpv.so", RTLD_NOW | RTLD_LOCAL);
    Api next = {0};
    if (lib) {
#define RESOLVE(field, name) *(void **)(&next.field) = dlsym(lib, name)
        RESOLVE(version, "mpv_client_api_version");
        RESOLVE(weak, "mpv_create_weak_client");
        RESOLVE(get, "mpv_get_property");
        RESOLVE(wait, "mpv_wait_event");
        RESOLVE(destroy, "mpv_destroy");
        RESOLVE(free_, "mpv_free");
        RESOLVE(free_node, "mpv_free_node_contents");
#undef RESOLVE
    }
    int okay = lib && next.version && next.weak && next.get && next.wait &&
               next.destroy && next.free_ && next.free_node &&
               (next.version() >> 16) == 2;
    if (okay) { api = next; mpv_library = lib; }
    else if (lib) dlclose(lib);
    pthread_mutex_unlock(&api_lock);
    return okay;
}

static void remove_entry_locked(Entry *entry) {
    for (int i = 0; i < MAX_PLAYERS; ++i) {
        if (entries[i] == entry) { entries[i] = NULL; ++registry_epoch; }
    }
    entry->closing = 1;
    pthread_cond_broadcast(&registry_changed);
}

/* Own event queue: never consume an event from the original Dart client's queue. */
static void *watch_shutdown(void *opaque) {
    Entry *entry = opaque;
    for (;;) {
        pthread_mutex_lock(&registry_lock);
        int closing = entry->closing;
        pthread_mutex_unlock(&registry_lock);
        if (closing) break;
        mpv_event *event = api.wait(entry->weak, 0.1);
        if (event && event->event_id == EVENT_SHUTDOWN) {
            pthread_mutex_lock(&registry_lock);
            remove_entry_locked(entry);
            pthread_mutex_unlock(&registry_lock);
            break;
        }
    }
    pthread_mutex_lock(&registry_lock);
    while (entry->refs != 0)
        pthread_cond_wait(&registry_changed, &registry_lock);
    pthread_mutex_unlock(&registry_lock);
    api.destroy(entry->weak);
    free(entry);
    return NULL;
}

static char *bounded_copy(const char *value, size_t maximum) {
    if (!value) return NULL;
    size_t size = strnlen(value, maximum + 1);
    if (size > maximum) return NULL;
    char *result = malloc(size + 1);
    if (result) memcpy(result, value, size + 1);
    return result;
}

static int get_string(Entry *entry, const char *name, char **result, int optional) {
    char *text = NULL;
    int rc = api.get(entry->weak, name, F_STRING, &text);
    if (rc < 0) {
        if (optional) { *result = bounded_copy("", 0); return *result != NULL; }
        return 0;
    }
    *result = bounded_copy(text ? text : "", MAX_FIELD);
    if (text) api.free_(text);
    return *result != NULL;
}

static int get_flag(Entry *entry, const char *name, int *value) {
    return api.get(entry->weak, name, F_FLAG, value) >= 0;
}

static void free_source(SourceData *source) {
    free(source->uri); free(source->agent); free(source->referrer); free(source->title);
    for (int i = 0; i < source->header_count; ++i) free(source->headers[i]);
    free(source->headers);
    memset(source, 0, sizeof(*source));
}

static int get_headers(Entry *entry, SourceData *source) {
    mpv_node node = {0};
    int rc = api.get(entry->weak, "http-header-fields", F_NODE, &node);
    if (rc < 0) return 0;
    int okay = 0;
    if (node.format == F_NODE_ARRAY && node.u.list &&
        node.u.list->num >= 0 && node.u.list->num <= MAX_HEADERS &&
        (node.u.list->num == 0 || node.u.list->values)) {
        int count = node.u.list->num;
        source->headers = calloc((size_t)count + 1, sizeof(char *));
        if (source->headers) {
            okay = 1;
            size_t total = 0;
            for (int i = 0; i < count; ++i) {
                mpv_node *item = &node.u.list->values[i];
                if (item->format != F_STRING || !item->u.string) { okay = 0; break; }
                char *copy = bounded_copy(item->u.string, MAX_FIELD);
                if (!copy) { okay = 0; break; }
                total += strlen(copy);
                source->headers[source->header_count++] = copy;
                if (total > MAX_HEADER_BYTES) { okay = 0; break; }
            }
        }
    }
    api.free_node(&node);
    return okay;
}

static int is_http(const char *uri) {
    return uri && ((!strncasecmp(uri, "https://", 8) && uri[8]) ||
                   (!strncasecmp(uri, "http://", 7) && uri[7]));
}

/* Result: 1 HTTP(S), 2 active unsupported, 0 idle/paused, -1 unstable. */
static int read_source(Entry *entry, SourceData *source) {
    int idle = 1, pause = 1;
    double position = -1;
    if (!get_flag(entry, "idle-active", &idle) || !get_flag(entry, "pause", &pause))
        return -1;
    if (idle || pause) return 0;
    /* A pending load can be non-idle and unpaused without having played yet. */
    if (api.get(entry->weak, "time-pos", F_DOUBLE, &position) < 0 ||
        !isfinite(position) || position < 0) return 0;
    if (!get_string(entry, "path", &source->uri, 0)) return -1;
    if (!is_http(source->uri)) return 2;
    if (!get_string(entry, "user-agent", &source->agent, 0) ||
        !get_string(entry, "referrer", &source->referrer, 0) ||
        !get_string(entry, "media-title", &source->title, 1) ||
        !get_headers(entry, source)) return -1;
    char *after = NULL;
    if (!get_string(entry, "path", &after, 0)) return -1;
    int unchanged = !strcmp(source->uri, after);
    free(after);
    if (!get_flag(entry, "idle-active", &idle) || !get_flag(entry, "pause", &pause))
        return -1;
    if (api.get(entry->weak, "time-pos", F_DOUBLE, &position) < 0 ||
        !isfinite(position) || position < 0) return -1;
    return unchanged && !idle && !pause ? 1 : -1;
}

static void throw_io(JNIEnv *env, const char *message) {
    jclass type = (*env)->FindClass(env, "java/io/IOException");
    if (type) (*env)->ThrowNew(env, type, message);
}

/* MPV strings are UTF-8; JNI NewStringUTF expects modified UTF-8 instead. */
static jstring new_utf8(JNIEnv *env, const char *text) {
    jsize size = (jsize)strlen(text);
    jbyteArray bytes = (*env)->NewByteArray(env, size);
    jclass type = (*env)->FindClass(env, "java/lang/String");
    if (!bytes || !type) return NULL;
    (*env)->SetByteArrayRegion(env, bytes, 0, size, (const jbyte *)text);
    if ((*env)->ExceptionCheck(env)) return NULL;
    jmethodID ctor = (*env)->GetMethodID(env, type, "<init>", "([BLjava/lang/String;)V");
    jstring encoding = (*env)->NewStringUTF(env, "UTF-8");
    if (!ctor || !encoding) return NULL;
    jstring result = (*env)->NewObject(env, type, ctor, bytes, encoding);
    (*env)->DeleteLocalRef(env, bytes);
    (*env)->DeleteLocalRef(env, type);
    (*env)->DeleteLocalRef(env, encoding);
    return result;
}

JNIEXPORT jboolean JNICALL
Java_org_x2_export_PlayerCapture_nativeRegister(JNIEnv *env, jclass type, jlong original) {
    (void)env; (void)type;
    if (!original || (uint64_t)(uintptr_t)(uint64_t)original != (uint64_t)original ||
        !load_api()) return JNI_FALSE;
    pthread_mutex_lock(&registry_lock);
    for (int i = 0; i < MAX_PLAYERS; ++i) {
        if (entries[i] && entries[i]->original == (uint64_t)original) {
            pthread_mutex_unlock(&registry_lock); return JNI_TRUE;
        }
    }
    pthread_mutex_unlock(&registry_lock);
    Entry *entry = calloc(1, sizeof(*entry));
    if (!entry) return JNI_FALSE;
    entry->original = (uint64_t)original;
    entry->weak = api.weak((mpv_handle *)(uintptr_t)original, "x2_export_observer");
    if (!entry->weak) { free(entry); return JNI_FALSE; }
    pthread_mutex_lock(&registry_lock);
    int slot = -1, duplicate = 0;
    for (int i = 0; i < MAX_PLAYERS; ++i) {
        if (!entries[i] && slot < 0) slot = i;
        if (entries[i] && entries[i]->original == entry->original) duplicate = 1;
    }
    if (slot < 0 || duplicate) {
        pthread_mutex_unlock(&registry_lock);
        api.destroy(entry->weak); free(entry);
        return duplicate ? JNI_TRUE : JNI_FALSE;
    }
    entries[slot] = entry;
    ++registry_epoch;
    pthread_t thread;
    int rc = pthread_create(&thread, NULL, watch_shutdown, entry);
    if (rc) remove_entry_locked(entry);
    pthread_mutex_unlock(&registry_lock);
    if (rc) { api.destroy(entry->weak); free(entry); return JNI_FALSE; }
    pthread_detach(thread);
    return JNI_TRUE;
}

JNIEXPORT void JNICALL
Java_org_x2_export_PlayerCapture_nativeUnregister(JNIEnv *env, jclass type, jlong original) {
    (void)env; (void)type;
    pthread_mutex_lock(&registry_lock);
    for (int i = 0; i < MAX_PLAYERS; ++i)
        if (entries[i] && entries[i]->original == (uint64_t)original)
            remove_entry_locked(entries[i]);
    pthread_mutex_unlock(&registry_lock);
}

JNIEXPORT void JNICALL
Java_org_x2_export_PlayerCapture_nativeClear(JNIEnv *env, jclass type) {
    (void)env; (void)type;
    pthread_mutex_lock(&registry_lock);
    for (int i = 0; i < MAX_PLAYERS; ++i)
        if (entries[i]) remove_entry_locked(entries[i]);
    pthread_mutex_unlock(&registry_lock);
}

JNIEXPORT jobject JNICALL
Java_org_x2_export_PlayerCapture_nativeSnapshot(JNIEnv *env, jclass type) {
    (void)type;
    Entry *pinned[MAX_PLAYERS];
    int count = 0;
    uint64_t epoch;
    pthread_mutex_lock(&registry_lock);
    epoch = registry_epoch;
    for (int i = 0; i < MAX_PLAYERS; ++i) {
        if (entries[i] && !entries[i]->closing) {
            ++entries[i]->refs;
            pinned[count++] = entries[i];
        }
    }
    pthread_mutex_unlock(&registry_lock);
    SourceData chosen = {0};
    int eligible = 0, active = 0, unstable = 0;
    Entry *chosen_entry = NULL;
    for (int i = 0; i < count; ++i) {
        SourceData current = {0};
        int rc = read_source(pinned[i], &current);
        if (rc == 1 || rc == 2) ++active;
        if (rc == 1) {
            ++eligible;
            if (eligible == 1) { chosen = current; chosen_entry = pinned[i]; }
            else free_source(&current);
        } else {
            if (rc < 0) unstable = 1;
            free_source(&current);
        }
    }
    pthread_mutex_lock(&registry_lock);
    if (registry_epoch != epoch || (chosen_entry && chosen_entry->closing)) unstable = 1;
    for (int i = 0; i < count; ++i) --pinned[i]->refs;
    pthread_cond_broadcast(&registry_changed);
    pthread_mutex_unlock(&registry_lock);
    const char *problem = NULL;
    if (!count) problem = "尚未检测到正在播放的视频，请返回开始播放后重试";
    else if (active > 1) problem = "检测到多个视频同时播放，请停止其他视频后再保存";
    else if (unstable) problem = "视频已切换或播放信息尚未就绪，请在当前视频播放时重试";
    else if (!eligible) problem = "当前视频已暂停，或不是支持的在线播放地址";
    if (problem) {
        free_source(&chosen);
        throw_io(env, problem);
        return NULL;
    }
    jclass string_type = (*env)->FindClass(env, "java/lang/String");
    jclass source_type = (*env)->FindClass(env, "org/x2/export/PlayerCapture$Source");
    if (!string_type || !source_type) { free_source(&chosen); return NULL; }
    jmethodID ctor = (*env)->GetMethodID(env, source_type, "<init>",
        "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)V");
    if (!ctor) { free_source(&chosen); return NULL; }
    jstring uri = new_utf8(env, chosen.uri);
    jstring agent = new_utf8(env, chosen.agent);
    jstring referrer = new_utf8(env, chosen.referrer);
    jstring title = new_utf8(env, chosen.title);
    jobjectArray headers = (*env)->NewObjectArray(env, chosen.header_count, string_type, NULL);
    if (!uri || !agent || !referrer || !title || !headers) { free_source(&chosen); return NULL; }
    for (int i = 0; i < chosen.header_count; ++i) {
        jstring header = new_utf8(env, chosen.headers[i]);
        if (!header) { free_source(&chosen); return NULL; }
        (*env)->SetObjectArrayElement(env, headers, i, header);
        (*env)->DeleteLocalRef(env, header);
        if ((*env)->ExceptionCheck(env)) { free_source(&chosen); return NULL; }
    }
    jobject result = (*env)->NewObject(env, source_type, ctor, uri, agent, referrer, headers, title);
    free_source(&chosen);
    return result;
}
