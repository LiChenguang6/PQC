package org.x2.export;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Collections;

public final class DownloadTasksActivity extends Activity {
    private final Handler main=new Handler();private ListView list;private TextView summary;
    private boolean scrolling;
    private ArrayList<DownloadStore.Job> jobs=new ArrayList<DownloadStore.Job>();private String last="";
    @Override public void onCreate(Bundle state){
        super.onCreate(state);setTitle("下载管理");LinearLayout root=new LinearLayout(this);root.setOrientation(1);
        int pad=(int)(12*getResources().getDisplayMetrics().density);root.setPadding(pad,pad,pad,pad);
        LinearLayout actions=new LinearLayout(this);
        Button settings=new Button(this);settings.setText("下载设置");actions.addView(settings,new LinearLayout.LayoutParams(0,-2,1));settings.setOnClickListener(v->startActivity(new Intent(this,DownloadSettingsActivity.class)));
        Button cache=new Button(this);cache.setText("导出已有缓存");actions.addView(cache,new LinearLayout.LayoutParams(0,-2,1));cache.setOnClickListener(v->startActivity(new Intent(this,CacheExportActivity.class)));root.addView(actions);
        summary=new TextView(this);root.addView(summary);list=new ListView(this);root.addView(list,new LinearLayout.LayoutParams(-1,0,1));
        list.setOnScrollListener(new android.widget.AbsListView.OnScrollListener(){public void onScrollStateChanged(android.widget.AbsListView v,int state){scrolling=state!=SCROLL_STATE_IDLE;}public void onScroll(android.widget.AbsListView v,int first,int visible,int total){}});
        list.setOnItemClickListener((parent,view,position,id)->actions(jobs.get(position)));setContentView(root);
    }
    @Override public void onResume(){super.onResume();last="";refresh();try{for(DownloadStore.Job job:DownloadStore.get(this).all())if(job.active()){DownloadService.start(this);break;}}catch(Exception e){summary.setText(e.getMessage());}main.postDelayed(tick,2000);}
    @Override public void onPause(){main.removeCallbacks(tick);super.onPause();}
    private final Runnable tick=new Runnable(){public void run(){refresh();main.postDelayed(this,2000);}};
    private void refresh(){if(!hasWindowFocus())return;try{
        ArrayList<DownloadStore.Job> current=DownloadStore.get(this).all();Collections.reverse(current);ArrayList<String> rows=new ArrayList<String>();
        int running=0,waiting=0;
        for(DownloadStore.Job job:current){if(job.state.equals("running")||job.state.equals("cancelling"))running++;if(job.state.equals("queued"))waiting++;
            rows.add(job.title+" · "+job.id.substring(0,8)+"\n"+job.stage+(job.state.equals("running")?" · "+job.progress+"%":""));}
        String caption="进行中 "+running+" · 等待 "+waiting+" · 并发上限 "+DownloadConfig.parallel(this)+"\n保存目录："+DownloadConfig.folderLabel(this)+"\n点选任务可取消、重试或删除；已完成的 MP4 默认保留。";if(!caption.contentEquals(summary.getText()))summary.setText(caption);
        String stamp=rows.toString();if(!scrolling&&hasWindowFocus()&&!stamp.equals(last)){int position=list.getFirstVisiblePosition();android.view.View child=list.getChildAt(0);int top=child==null?0:child.getTop();jobs=current;list.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,rows));list.setSelectionFromTop(position,top);last=stamp;}
    }catch(Exception e){summary.setText(e.getMessage());}}
    private void actions(final DownloadStore.Job job){
        ArrayList<String> labels=new ArrayList<String>();ArrayList<String> commands=new ArrayList<String>();
        if(job.state.equals("paused")){labels.add("继续下载");commands.add("resume");}
        else if(job.state.equals("running")||job.state.equals("queued")){labels.add("暂停下载");commands.add("pause");}
        if(job.active()){labels.add("取消下载");commands.add("cancel");}
        else if(!job.state.equals("success")&&(job.source!=null||!job.cache.isEmpty())){labels.add("重新下载");commands.add("retry");}
        labels.add(job.state.equals("success")?"删除任务记录（保留 MP4）":"删除任务并清理未完成文件");commands.add("remove");
        new AlertDialog.Builder(this).setTitle(job.title).setItems(labels.toArray(new String[0]),(dialog,which)->{
            String action=commands.get(which);
            if(action.equals("remove"))new AlertDialog.Builder(this).setTitle("删除此任务？")
                .setMessage(job.state.equals("success")?"仅删除这条记录，已经保存的 MP4 不会删除。":"取消此任务并清理未完成文件，其他任务继续执行。")
                .setPositiveButton("删除",(d,w)->send(action,job.id)).setNegativeButton("保留",null).show();
            else send(action,job.id);
        }).show();
    }
    private void send(String action,String id){try{DownloadService.command(this,action,id);}catch(Exception e){new AlertDialog.Builder(this).setMessage("无法启动后台任务，请在前台重试。").setPositiveButton("知道了",null).show();}}
}
