from pathlib import Path
import subprocess,json,hashlib
B=Path('/workspace/x2-analysis');R=B/'export10-tests';A=str(B/'android-sdk/platform-tools/adb');P='com.example.yinqishe_export';apk=B/'output/X2-cache-export.apk'
def run(*args,timeout=60):return subprocess.check_output([A,*args],timeout=timeout,text=True)
print(run('push',str(apk),'/data/local/tmp/X2-export10.apk'),flush=True)
try:print(run('shell','pm','install','-r','/data/local/tmp/X2-export10.apk',timeout=150),flush=True)
except subprocess.TimeoutExpired:print('Checking installed payload after install timeout',flush=True)
p=run('shell','pm','path',P).strip().split('package:')[1];sha=run('exec-out','sha256sum',p).split()[0];assert sha==hashlib.sha256(apk.read_bytes()).hexdigest()
(R/'installed-results.json').write_text(json.dumps(dict(installed_sha256=sha,matches_delivery=True),indent=2))
subprocess.run(['python3',str(R/'flutter_startup_test.py')],check=True,timeout=130)
