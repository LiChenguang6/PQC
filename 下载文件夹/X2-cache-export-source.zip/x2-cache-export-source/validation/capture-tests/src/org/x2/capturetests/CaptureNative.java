package org.x2.capturetests;

/** Test-only mpv owner. It never reads or attaches to the running application. */
public final class CaptureNative {
    public static native int bridgeFlag(int which);
    public static native boolean requestManager();
    public static native boolean setHomeReady(int value);
    public static native void seedDetails(String path,String uri,int mode);
    public static native void load(String originalLibrary);
    public static native long create(String uri, String userAgent, String referrer,
                                     String[] headers, String title, boolean paused);
    public static native void pause(long handle, boolean value);
    public static native String property(long handle, String name);
    public static native void terminate(long handle);
    private CaptureNative() {}
}
