import prepare
from pathlib import Path
import struct,json,sys
from unicorn import *
from unicorn.arm64_const import *
from unicorn.x86_const import *
B=Path('/workspace/x2-analysis');R=B/'export15-tests';sys.path.insert(0,str(B/'export-patch'));from patch_launch_title import SPECS
results=[]
for abi,s in SPECS.items():
 arm=abi=='arm64-v8a'
 for high in [0,1]:
  for kind in ['true','false','unknown_bool','wrong_class','null','large_ints']:
   u=Uc(UC_ARCH_ARM64 if arm else UC_ARCH_X86,UC_MODE_ARM if arm else UC_MODE_64);u.mem_map(0,0x900000);u.mem_write(0,(R/'asm'/f'{abi}-patched.so').read_bytes());base=high<<32;heap=base+0x1000000;stack=0x2000000;u.mem_map(heap,0x10000);u.mem_map(stack,0x10000)
   controller=heap+0x101;model=heap+0x301;t=heap+0x1001;uri=heap+0x2001;null=heap+0x9001;thr=heap+0x8000
   def put(at,value,fmt='Q'):u.mem_write(at,struct.pack('<'+fmt,value))
   def compressed(at):return at&0xffffffff
   def string(at,text):
    b=text.encode('utf-16le');put(at-1,95<<12,'I');put(at+7,len(b),'I');u.mem_write(at+15,b)
   string(t,'页面标题😀');string(uri,'https://fixture.invalid/media.m3u8?TEST_ONLY_SECRET');put(controller+0x53,compressed(null if kind=='null' else model),'I');put(controller+0x2b,compressed(heap+0x501),'I');put(model-1,(246 if kind=='wrong_class' else 245)<<12,'I');put(model+0x53,compressed(t),'I')
   identity=(1<<40)+17 if kind=='large_ints' else 778899;play=(1<<35)+2 if kind=='large_ints' else 180
   for off,val in [(0x57,identity),(0x3b,play),(0x5f,3),(0x4b,4)]:put(model+off,val)
   boolean=null+0x20 if kind in ['true','large_ints'] else null+0x30 if kind=='false' else null
   put(model+0xb,compressed(boolean),'I');sentinel=stack+0xf000
   if arm:
    for reg,val in [(UC_ARM64_REG_X0,controller),(UC_ARM64_REG_X28,high),(UC_ARM64_REG_X22,null),(UC_ARM64_REG_X15,stack+0x8000),(UC_ARM64_REG_X29,stack+0x9000),(UC_ARM64_REG_X4,0x4444),(UC_ARM64_REG_X6,0x6666)]:u.reg_write(reg,val)
    u.emu_start(s['entry'],s['entry']+4,count=100000);assert u.reg_read(UC_ARM64_REG_X4)==0x4444 and u.reg_read(UC_ARM64_REG_X6)==0x6666;assert u.reg_read(UC_ARM64_REG_X0)==controller
    u.reg_write(UC_ARM64_REG_X0,uri);u.emu_start(s['end'],s['end']+4,count=100000);assert u.reg_read(UC_ARM64_REG_X0)==uri
   else:
    put(thr+0x48,base);put(thr+0x78,null);put(thr+0x80,null+0x20)
    for reg,val in [(UC_X86_REG_RAX,controller),(UC_X86_REG_R14,thr),(UC_X86_REG_RSP,stack+0x8000),(UC_X86_REG_RBP,stack+0x9000),(UC_X86_REG_RSI,0x5555),(UC_X86_REG_RDX,0x6666)]:u.reg_write(reg,val)
    u.emu_start(s['entry'],s['entry']+7,count=100000);assert u.reg_read(UC_X86_REG_RSI)==0x5555 and u.reg_read(UC_X86_REG_RDX)==0x6666;assert u.reg_read(UC_X86_REG_RAX)==controller
    u.reg_write(UC_X86_REG_RAX,uri);put(stack+0x9000,0x1234);put(stack+0x9008,sentinel);u.emu_start(s['end'],sentinel,count=100000);assert u.reg_read(UC_X86_REG_RAX)==uri
   values=struct.unpack('<qqqqqq',u.mem_read(s['buffer']+0x4820,48));seq,magic=struct.unpack('<II',u.mem_read(s['buffer']+8,8));assert seq==2 and magic==0x35543258
   if kind in ['null','wrong_class']:assert values==(-1,-1,-1,-1,-1,0),values
   else:assert values==(identity,play,3,4,1 if kind in ['true','large_ints'] else 0 if kind=='false' else -1,0x3531444d),values
   results.append({'abi':abi,'compressed_heap_high32':high,'case':kind,'passed':True})
(R/'detail-machine-results.json').write_text(json.dumps({'passed':True,'cases':results,'scope':'Dart leaf numeric copies, both ABIs; no real API response'},indent=2));print('PASS',len(results),'metadata leaf cases, compressed heaps and guarded null/wrong-class reads')
