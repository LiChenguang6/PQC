from pathlib import Path
import importlib.util
import json
import subprocess

BASE = Path('/workspace/x2-analysis')
ROOT = BASE / 'ui-download-tests/results'
spec = importlib.util.spec_from_file_location('ui', BASE / 'runtime-logs/final_ui_test.py')
ui = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ui)
ui.ROOT = ROOT

ui.adb('shell', 'am', 'force-stop', ui.PKG)
ui.adb('shell', 'rm', '-f', '/sdcard/Download/X2_100002.mp4')  # previous synthetic test output only
ui.adb('shell', 'am', 'start', '-n', ui.PKG + '/com.tencent.a.SetupInfoActivity')
ui.tap(ui.wait_node('cache-v2-entry', lambda n: n.get('text') == '保存/导出'))
ui.tap(ui.wait_node('cache-v2-menu', lambda n: n.get('text') == '导出已下载缓存'))
ui.tap(ui.wait_node('cache-v2-list', lambda n: '视频 100002' in n.get('text', '')))
ui.tap(ui.wait_node('cache-v2-save', lambda n: n.get('resource-id') == 'android:id/button1'
                    and n.get('text', '').upper() == 'SAVE'))
result = ui.wait_node('cache-v2-success', lambda n: '已保存 MP4' in n.get('text', '') or '导出失败' in n.get('text', ''), seconds=120)
assert '已保存 MP4' in result.get('text'), result.attrib
ui.shot('cache-v2-success')
target = ROOT / 'cache-v2.mp4'
ui.adb('pull', '/sdcard/Download/X2_100002.mp4', str(target))
subprocess.run(['ffmpeg', '-v', 'error', '-i', str(target), '-f', 'null', '-'], capture_output=True, check=True)
record = {'case': 'existing AES128 cache after in-place upgrade', 'status': result.get('text'),
          'bytes': target.stat().st_size, 'full_decode': True}
(ROOT / 'cache-regression.json').write_text(json.dumps(record, ensure_ascii=False, indent=2))
print(json.dumps(record, ensure_ascii=False))
