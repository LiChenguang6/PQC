from pathlib import Path
import subprocess,zipfile,json,threading,http.server,time
B=Path('/workspace/x2-analysis');R=B/'export6-tests';W=R/'runtime';W.mkdir(exist_ok=True);T=B/'patch-tools';N=T/'android-ndk-r28c/toolchains/llvm/prebuilt/linux-x86_64/bin';A=B/'android-sdk/platform-tools/adb'
def run(*a,**kw):return subprocess.run([str(x) for x in a],check=True,**kw)
run(N/'x86_64-linux-android24-clang','-shared','-fPIC','-O2',R/'title_fixture.c','-ldl','-o',W/'libtitlefixture.so')
(W/'classes').mkdir(exist_ok=True);(W/'dex').mkdir(exist_ok=True)
run('java','-jar',T/'ecj.jar','-source','1.8','-target','1.8','-encoding','UTF-8','-bootclasspath',T/'android-35/android.jar','-d',W/'classes',R/'PageTitleTest.java',B/'capture-tests/src/org/x2/capturetests/CaptureNative.java',B/'export-patch/src/org/x2/export/PlayerCapture.java',B/'export-patch/src/org/x2/export/VideoFilename.java')
run(T/'android-15/d8','--min-api','24','--lib',T/'android-35/android.jar','--output',W/'dex',*list((W/'classes').rglob('*.class')))
with zipfile.ZipFile(B/'output/X2-cache-export.apk') as z:
 for f in ['libapp.so','libx2player.so','libmpv.so']:(W/f).write_bytes(z.read('lib/x86_64/'+f))
run(A,'shell','mkdir','-p','/data/local/tmp/x2-title-tests')
for f in [W/'libtitlefixture.so',W/'libapp.so',W/'libx2player.so',W/'libmpv.so',W/'dex/classes.dex',B/'capture-tests/build/libcapturetest.so']:run(A,'push',f,'/data/local/tmp/x2-title-tests/'+f.name,stdout=subprocess.DEVNULL)
class Handler(http.server.BaseHTTPRequestHandler):
 def do_GET(self):
  data=(B/'capture-tests/fixture/capture-fixture.mp4').read_bytes();self.send_response(200);self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('0.0.0.0',18768),Handler);threading.Thread(target=server.serve_forever,daemon=True).start()
try:
 p=subprocess.run([str(A),'shell','CLASSPATH=/data/local/tmp/x2-title-tests/classes.dex LD_LIBRARY_PATH=/data/local/tmp/x2-title-tests app_process -Djava.library.path=/data/local/tmp/x2-title-tests /system/bin org.x2.titletests.PageTitleTest /data/local/tmp/x2-title-tests http://10.0.2.2:18768/fixture.mp4'],capture_output=True,text=True,timeout=60)
finally:server.shutdown();server.server_close()
(R/'title-runtime.log').write_text(p.stdout+p.stderr);print(p.stdout+p.stderr);assert p.returncode==0 and 'TITLE_TEST_SUCCESS' in p.stdout
(R/'title-runtime-results.json').write_text(json.dumps(dict(passed=True,cases=10,scope='Production JNI, original mpv, synthetic short-title ring and manager event; Dart hooks separately machine-tested',output_sha256=json.loads((B/'output/build-info.json').read_text())['output_sha256']),indent=2))
