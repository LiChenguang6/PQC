from pathlib import Path
import importlib.util,json,re
B=Path('/workspace/x2-analysis');ROOT=B/'export4-tests';spec=importlib.util.spec_from_file_location('ui',B/'runtime-logs/final_ui_test.py');ui=importlib.util.module_from_spec(spec);spec.loader.exec_module(ui);ui.ROOT=ROOT
assert (ROOT/'flutter-startup-results.json').exists()
download=ui.wait_node('persisted-buttons-after-process-restart',lambda n:n.get('text')=='下载');nodes=ui.dump('persisted-buttons-after-process-restart');manage=next(n for n in nodes if n.get('text')=='管理')
a=list(map(int,re.findall(r'\d+',download.get('bounds'))));b=list(map(int,re.findall(r'\d+',manage.get('bounds'))))
assert 0<=a[0]<200 and a[1]>250,(a,b)
assert a[1]==b[1] and a[3]==b[3] and a[2]==b[0],(a,b)
assert b[2]<=480 and b[3]<=854,(a,b)
prefs=ui.adb('exec-out','cat','/data/user/0/'+ui.PKG+'/shared_prefs/x2-overlay-position.xml').stdout.decode();assert 'name="x"' in prefs and 'name="y"' in prefs
ui.shot('persisted-buttons-after-process-restart')
r={'position_preserved_after_process_restart':True,'buttons_remain_side_by_side':True,'buttons_clamped_within_screen':True,'download_bounds':a,'manage_bounds':b,'apk_sha256':json.loads((B/'output/build-info.json').read_text())['output_sha256']};(ROOT/'position-results.json').write_text(json.dumps(r,indent=2));print(json.dumps(r),flush=True)
