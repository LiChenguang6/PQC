from pathlib import Path
import importlib.util,time,json,subprocess,xml.etree.ElementTree as ET
B=Path('/workspace/x2-analysis');ROOT=B/'export4-tests';spec=importlib.util.spec_from_file_location('ui',B/'runtime-logs/final_ui_test.py');ui=importlib.util.module_from_spec(spec);spec.loader.exec_module(ui);ui.ROOT=ROOT
ui.adb('shell','am','start','-n',ui.PKG+'/org.x2.export.DownloadSettingsActivity')
ui.tap(ui.wait_node('custom-parallel-button',lambda n:n.get('text','').startswith('同时下载数量：')))
field=ui.wait_node('custom-parallel-input',lambda n:n.get('class')=='android.widget.EditText');ui.tap(field)
ui.adb('shell','input','keyevent','123');ui.adb('shell','input','keyevent','67');ui.adb('shell','input','text','0')
ui.tap(ui.wait_node('invalid-save',lambda n:n.get('text')=='保存'))
ui.wait_node('invalid-rejected',lambda n:n.get('class')=='android.widget.EditText' and n.get('text')=='0')
ui.adb('shell','input','keyevent','67');ui.adb('shell','input','text','5')
ui.tap(ui.wait_node('valid-save',lambda n:n.get('text')=='保存'))
ui.wait_node('parallel-five-saved',lambda n:n.get('text')=='同时下载数量：5')
ui.adb('shell','am','force-stop',ui.PKG)
ui.adb('shell','am','instrument','-w','-e','mode','reset','org.x2.uitests/org.x2.uitests.DownloadInstrumentation')
before=set(ui.adb('shell','find','/sdcard/Download/X2_export3_B','-type','f').stdout.decode().splitlines())
seed=ui.adb('shell','am','instrument','-w','-e','mode','seed','-e','jobs','P1,P2,P3,P4,P5,P6,P7','-e','server','http://127.0.0.1:18767','org.x2.uitests/org.x2.uitests.DownloadInstrumentation').stdout.decode();(ROOT/'seed.log').write_text(seed);assert 'parallel=5' in seed and 'SEEDED_ENCRYPTED_QUEUE' in seed
ui.adb('shell','am','start','-n',ui.PKG+'/org.x2.export.DownloadTasksActivity')
ui.wait_node('five-active',lambda n:'进行中 5' in n.get('text','') and '等待 2' in n.get('text',''),seconds=60)
service=ui.adb('shell','dumpsys','activity','services',ui.PKG).stdout.decode();assert 'isForeground=true' in service;(ROOT/'foreground-service.txt').write_text(service)
end=time.monotonic()+20
while time.monotonic()<end:
 server=json.loads((ROOT/'server-results.json').read_text())
 if len([e for e in server['events'] if e['kind']=='start'])==5:break
 time.sleep(1)
assert server['max_active']==5,server
ui.adb('shell','input','keyevent','3');ui.adb('shell','input','keyevent','223')
power=ui.adb('shell','dumpsys','power').stdout.decode();assert 'mWakefulness=Asleep' in power or 'mWakefulness=Dozing' in power;(ROOT/'screen-off.txt').write_text(power)
for i in range(1,8):(ROOT/('release-P'+str(i))).touch()
end=time.monotonic()+80
while time.monotonic()<end:
 after=set(ui.adb('shell','find','/sdcard/Download/X2_export3_B','-type','f').stdout.decode().splitlines());new=after-before
 if len(new)==7:break
 time.sleep(2)
else:raise RuntimeError('missing parallel output files '+str(new))
for i,remote in enumerate(sorted(new)):
 local=ROOT/('parallel-'+str(i)+'.mp4');ui.adb('pull',remote,str(local));subprocess.run(['ffmpeg','-v','error','-i',str(local),'-f','null','-'],check=True,capture_output=True)
ui.adb('shell','input','keyevent','224');ui.adb('shell','wm','dismiss-keyguard');ui.adb('shell','am','start','-n',ui.PKG+'/org.x2.export.DownloadTasksActivity')
ui.wait_node('all-completed',lambda n:'进行中 0' in n.get('text','') and '等待 0' in n.get('text',''))
server=json.loads((ROOT/'server-results.json').read_text());assert server['max_active']==5,server
r={'custom_input_5_saved_across_process_restart':True,'invalid_zero_rejected':True,'five_simultaneous_real_HTTP_transfers':True,'observed_max_active':server['max_active'],'remaining_two_initially_queued':True,'all_seven_completed_after_screen_off':True,'all_seven_MP4_fully_decode':True,'apk_sha256':json.loads((B/'output/build-info.json').read_text())['output_sha256']};(ROOT/'parallel-results.json').write_text(json.dumps(r,indent=2));print(json.dumps(r),flush=True)
