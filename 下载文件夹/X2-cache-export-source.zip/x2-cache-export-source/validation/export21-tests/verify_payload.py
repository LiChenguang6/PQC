from pathlib import Path
import zipfile,json,hashlib
B=Path('/workspace/x2-analysis');P=B/'export-patch';R=B/'export21-tests';G=Path('/workspace/pqc-upload/下载文件夹')
with zipfile.ZipFile(G/'X2-cache-export.apk') as old,zipfile.ZipFile(B/'output/X2-cache-export.apk') as new:
 for abi,progress,size,pause,pause_size in [('arm64-v8a',0x70c130,0x54,0x70ca18,0xfc),('x86_64',0x6202d4,0x68,0x620e44,0x100)]:
  a=old.read('lib/'+abi+'/libapp.so');b=new.read('lib/'+abi+'/libapp.so');assert a[progress:progress+size]==b[progress:progress+size] and a[pause:pause+pause_size]==b[pause:pause+pause_size]
 for n in ['lib/arm64-v8a/libflutter.so','lib/x86_64/libflutter.so','lib/arm64-v8a/libmpv.so','lib/x86_64/libmpv.so']:assert old.read(n)==new.read(n)
 assert not any('capturetest' in n for n in new.namelist())
with zipfile.ZipFile(G/'X2-cache-export-source.zip') as source:
 for n in ['DownloadStore.java','DownloadService.java','DownloadTasksActivity.java','DownloadConfig.java','VideoIdentity.java','VideoThumbnails.java','VideoPreviewActivity.java','VideoPreviewCard.java','MediaDownloader.java']:
  assert source.read('x2-cache-export-source/export-patch/src/org/x2/export/'+n)==(P/'src/org/x2/export'/n).read_bytes(),n
r={'passed':True,'apk_sha256':hashlib.sha256((B/'output/X2-cache-export.apk').read_bytes()).hexdigest(),'normal_progress_and_pause_callbacks_identical_to_export20':True,'download_preview_dedupe_java_unchanged':True,'real_platform_full_playback_verified':False};(R/'payload-results.json').write_text(json.dumps(r,indent=2));print(r)
