from pathlib import Path
import subprocess,json,hashlib,http.server,threading,re,sys
B=Path('/workspace/x2-analysis');R=B/'export15-tests';A=str(B/'android-sdk/platform-tools/adb');P='com.example.yinqishe_export';apk=B/'output/X2-cache-export.apk'
def run(*args,timeout=60):return subprocess.check_output([A,*args],timeout=timeout,text=True)
if not (R/'fixture/media.m3u8').exists():subprocess.run(['python3',str(R/'prepare_fixture.py')],check=True)
run('shell','am','force-stop',P)
if '--reuse' not in sys.argv:
 print(run('push',str(apk),'/data/local/tmp/X2-export15.apk'),flush=True);print(run('shell','pm','install','-r','/data/local/tmp/X2-export15.apk',timeout=180),flush=True)
p=run('shell','pm','path',P).strip().split('package:')[1];sha=run('exec-out','sha256sum',p).split()[0];assert sha==hashlib.sha256(apk.read_bytes()).hexdigest();(R/'installed-results.json').write_text(json.dumps({'installed_sha256':sha,'matches_delivery':True},indent=2))
if '--no-build' not in sys.argv:subprocess.run(['python3',str(B/'ui-download-tests/build_test_apk.py')],check=True,stdout=(R/'test-build.log').open('w'),stderr=subprocess.STDOUT,timeout=180)
class Handler(http.server.BaseHTTPRequestHandler):
 def do_GET(self):
  route=self.path.split('?')[0]
  if route=='/fixture.mp4':data=(B/'capture-tests/fixture/capture-fixture.mp4').read_bytes()
  else:
   name=route.lstrip('/');assert name in ['media.m3u8','seg0.ts','seg1.ts','seg2.ts'];data=(R/'fixture'/name).read_bytes()
  self.send_response(200);self.send_header('Content-Length',str(len(data)));self.end_headers()
  try:self.wfile.write(data)
  except OSError:pass
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',18781),Handler);server.daemon_threads=True;threading.Thread(target=server.serve_forever,daemon=True).start()
try:
 run('reverse','tcp:18781','tcp:18781');results=json.loads((R/'ui-results.json').read_text()) if (R/'ui-results.json').exists() else {}
 if results.get('apk_sha256')!=sha:results={}
 modes=[('preview15','SAF_PREVIEW_CARD_DURATION_DISK_CACHE_PLAYBACK_MULTISELECT_AND_FAILURE_PASS',['-e','fixture','http://127.0.0.1:18781/fixture.mp4']),('source15','PHONE_SOURCE_DETAILS_EXACT_URI_REJECTION_HLS_PRIVACY_AND_COPY_PASS',['-e','fixture','http://127.0.0.1:18781/media.m3u8?DO_NOT_REPORT_URI']),('delete12','RECORD_ONLY_KEEP_BATCH_FILE_DELETE_FAILURE_RETENTION_AND_UI_OPTIONS_PASS',[])]
 if "--mode" in sys.argv:modes=[m for m in modes if m[0] in sys.argv[sys.argv.index("--mode")+1].split(",")]
 for mode,expected,extra in modes:
  run('shell','am','force-stop',P);log=run('shell','am','instrument','-w','-e','mode',mode,*extra,'org.x2.uitests/org.x2.uitests.DownloadInstrumentation',timeout=180);(R/(mode+'-runtime.log')).write_text(log);print(log,flush=True);assert expected in log,mode;results[mode]={'passed':True}
 results.update(apk_sha256=sha,real_target_video_over_20_seconds_verified=False);(R/'ui-results.json').write_text(json.dumps(results,indent=2))
finally:server.shutdown();server.server_close();run('reverse','--remove','tcp:18781')
