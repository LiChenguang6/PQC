package org.x2.uitests;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.x2.capturetests.CaptureNative;
import org.x2.export.DownloadConfig;
import org.x2.export.DownloadStore;
import org.x2.export.ExportEntry;
import org.x2.export.PlayerCapture;

/** Test APK only. No test entry points or fixture credentials are in the user APK. */
public final class DownloadInstrumentation extends Instrumentation {
    private Bundle options;
    @Override public void onCreate(Bundle args){options=args;start();}
    @Override public void onStart(){long handle=0;try{
        String mode=options.getString("mode","capture");
        if(mode.equals("pauseSeed6")||mode.equals("pauseVerify6")){
            DownloadStore store=DownloadStore.get(getTargetContext());DownloadStore.Job selected=null;
            if(mode.equals("pauseSeed6")){
                for(DownloadStore.Job old:store.all())if(old.title.equals("回归持久暂停"))store.remove(old);
                selected=DownloadStore.playback(getTargetContext(),new PlayerCapture.Source("http://10.0.2.2:18770/slow/Persist.mp4","X2PausePersist/1.0","",new String[0],"回归持久暂停"));store.add(selected);
                final String id=selected.id;runOnMainSync(()->org.x2.export.DownloadService.command(getTargetContext(),"pause",id));awaitState(selected,"paused");Thread.sleep(1500);
            } else {
                for(DownloadStore.Job job:store.all())if(job.title.equals("回归持久暂停"))selected=job;
                if(selected==null||!selected.paused||!selected.state.equals("paused"))throw new AssertionError("paused record not restored: "+(selected==null?"missing":selected.state+"/"+selected.paused));
                final String id=selected.id;runOnMainSync(()->org.x2.export.DownloadService.start(getTargetContext()));Thread.sleep(1200);
                if(!selected.state.equals("paused"))throw new AssertionError("paused task restarted automatically");
                runOnMainSync(()->org.x2.export.DownloadService.command(getTargetContext(),"resume",id));awaitState(selected,"running");
                runOnMainSync(()->org.x2.export.DownloadService.command(getTargetContext(),"cancel",id));awaitState(selected,"cancelled");
                store.remove(selected);
            }
            Bundle report=new Bundle();report.putString("result",mode.equals("pauseSeed6")?"PAUSED_RECORD_SAVED":"PAUSED_RECORD_RESTORED_AND_RESUMED");finish(Activity.RESULT_OK,report);return;
        }
        if(mode.equals("service6")){
            final DownloadStore store=DownloadStore.get(getTargetContext());
            for(DownloadStore.Job old:store.all())if(old.title.startsWith("回归暂停 ")||old.title.equals("回归持久暂停"))store.remove(old);
            org.x2.export.DownloadConfig.setParallel(getTargetContext(),1);
            final DownloadStore.Job a=DownloadStore.playback(getTargetContext(),new PlayerCapture.Source("http://10.0.2.2:18770/slow/A.mp4","X2ServiceRegression/1.0","",new String[0],"回归暂停 A"));
            final DownloadStore.Job b=DownloadStore.playback(getTargetContext(),new PlayerCapture.Source("http://10.0.2.2:18770/slow/B.mp4","X2ServiceRegression/1.0","",new String[0],"回归暂停 B"));
            store.add(a);store.add(b);
            runOnMainSync(()->org.x2.export.DownloadService.start(getTargetContext()));
            awaitState(a,"running");Thread.sleep(1200);
            runOnMainSync(()->org.x2.export.DownloadService.command(getTargetContext(),"pause",a.id));
            awaitState(a,"paused");awaitState(b,"running");int progress=a.progress;Thread.sleep(1500);if(a.progress!=progress)throw new AssertionError("paused progress changed");
            runOnMainSync(()->org.x2.export.DownloadService.command(getTargetContext(),"resume",a.id));Thread.sleep(600);
            if(!a.state.equals("paused")||!a.resumeRequested)throw new AssertionError("resume exceeded parallel limit");
            runOnMainSync(()->org.x2.export.DownloadService.command(getTargetContext(),"cancel",b.id));awaitState(b,"cancelled");awaitState(a,"running");
            runOnMainSync(()->org.x2.export.DownloadService.command(getTargetContext(),"pause",a.id));awaitState(a,"paused");
            runOnMainSync(()->org.x2.export.DownloadService.command(getTargetContext(),"remove",a.id));
            long end=System.currentTimeMillis()+15000;while(store.find(a.id)!=null&&System.currentTimeMillis()<end)Thread.sleep(100);
            if(store.find(a.id)!=null)throw new AssertionError("paused removal failed");
            for(int i=0;i<25;i++){runOnMainSync(()->org.x2.export.DownloadService.command(getTargetContext(),"cancel",b.id));Thread.sleep(50);}
            Thread.sleep(8000);
            if(!b.state.equals("cancelled"))throw new AssertionError("cancel state lost");
            Bundle report=new Bundle();report.putString("result","PAUSE_RESUME_CANCEL_REMOVE_PROCESS_SURVIVED");report.putInt("pid",android.os.Process.myPid());finish(Activity.RESULT_OK,report);return;
        }
        if(mode.equals("reset")){
            DownloadStore store=DownloadStore.get(getTargetContext());
            for(DownloadStore.Job job:store.all())if(job.title.startsWith("任务 ")||job.title.equals("受控测试视频"))store.remove(job);
            Bundle report=new Bundle();report.putString("result","TEST_RECORDS_RESET");finish(Activity.RESULT_OK,report);return;
        }
        if(mode.equals("seed")){
            DownloadStore store=DownloadStore.get(getTargetContext());
            for(String label:options.getString("jobs","A,B,C,D").split(",")){
                String kind=label.equals("E")?"retry":"slow";
                PlayerCapture.Source source=new PlayerCapture.Source(options.getString("server","http://127.0.0.1:18766")+"/"+kind+"/"+label+".mp4?fixture_nonce=BACKGROUND_TEST","X2ControlledBgTest/1.0","",new String[0],options.getString("title","任务 "+label));
                store.add(DownloadStore.playback(getTargetContext(),source));
            }
            Bundle report=new Bundle();report.putString("result","SEEDED_ENCRYPTED_QUEUE");report.putInt("parallel",DownloadConfig.parallel(getTargetContext()));finish(Activity.RESULT_OK,report);return;
        }
        Intent launch=new Intent();launch.setClassName(getTargetContext(),options.getString("activity","com.tencent.a.SetupInfoActivity"));launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        final Activity activity=startActivitySync(launch);
        if(mode.equals("controls6")){
            runOnMainSync(()->content(activity));
            long until=System.currentTimeMillis()+30000;boolean mapped=false;
            System.loadLibrary("capturetest");while(System.currentTimeMillis()<until){if(CaptureNative.requestManager()){mapped=true;break;}Thread.sleep(200);}
            if(!mapped)throw new AssertionError("libapp not mapped");
            PlayerCapture.manageRequested(false);
            runOnMainSync(()->{content(activity);ExportEntry.install(activity);});waitForIdleSync();Thread.sleep(500);
            View row=activity.findViewById(android.R.id.content).findViewWithTag("x2-download-buttons");
            if(((LinearLayout)row).getChildCount()!=1)throw new AssertionError("floating manager still present");
            ActivityMonitor monitor=addMonitor("org.x2.export.DownloadTasksActivity",null,false);
            CaptureNative.requestManager();Activity manager=waitForMonitorWithTimeout(monitor,15000);removeMonitor(monitor);
            if(manager==null)throw new AssertionError("left tab event did not open manager");
            Bundle report=new Bundle();report.putString("result","SINGLE_DOWNLOAD_AND_MANAGER_BRIDGE_PASS");finish(Activity.RESULT_OK,report);return;
        }
        if(mode.equals("drag")){
            getTargetContext().getSharedPreferences("x2-overlay-position",0).edit().clear().commit();
            final ScrollView[] scroll=new ScrollView[1];
            runOnMainSync(()->{scroll[0]=content(activity);ExportEntry.install(activity);});
            waitForIdleSync();Thread.sleep(500);
            View row=activity.findViewById(android.R.id.content).findViewWithTag("x2-download-buttons");int[] location=new int[2];row.getLocationOnScreen(location);
            float oldX=row.getX(),oldY=row.getY();float x=location[0]+row.getWidth()/4f,y=location[1]+row.getHeight()/2f;
            swipe(x,y,x-100,y+250);waitForIdleSync();Thread.sleep(300);
            float newX=row.getX(),newY=row.getY();
            if(Math.abs(newX-oldX)<50||Math.abs(newY-oldY)<100)throw new AssertionError("buttons did not drag");
            if(scroll[0].getScrollY()!=0)throw new AssertionError("drag scrolled underlying page");
            if(!row.hasWindowFocus())throw new AssertionError("drag triggered a click/dialog");
            runOnMainSync(()->{scroll[0]=content(activity);ExportEntry.install(activity);});waitForIdleSync();Thread.sleep(500);
            row=activity.findViewById(android.R.id.content).findViewWithTag("x2-download-buttons");
            if(Math.abs(newX-row.getX())>2||Math.abs(newY-row.getY())>2)throw new AssertionError("position not restored");
            swipe(30,620,30,280);waitForIdleSync();Thread.sleep(200);int after=scroll[0].getScrollY();if(after<=0)throw new AssertionError("uncovered page cannot scroll");
            ActivityMonitor monitor=addMonitor("org.x2.export.DownloadTasksActivity",null,false);
            row.getLocationOnScreen(location);tap(location[0]+row.getWidth()*3f/4,location[1]+row.getHeight()/2f);
            Activity manager=waitForMonitorWithTimeout(monitor,15000);removeMonitor(monitor);if(manager==null)throw new AssertionError("management tap after drag did not open manager");
            Bundle report=new Bundle();report.putString("result","DRAG_PERSIST_AND_MANAGE_PASS");report.putFloat("x",newX);report.putFloat("y",newY);report.putInt("uncovered_page_scroll",after);finish(Activity.RESULT_OK,report);return;
        }
        System.loadLibrary("capturetest");CaptureNative.load(getTargetContext().getApplicationInfo().nativeLibraryDir+"/libmpv.so");String uri=options.getString("fixture");
        handle=CaptureNative.create(uri,"X2ControlledUiTest/1.0","",new String[0],"受控测试视频",false);PlayerCapture.register(handle);
        long deadline=System.currentTimeMillis()+30000;boolean ready=false;
        while(System.currentTimeMillis()<deadline){try{if(uri.equals(PlayerCapture.snapshot().uri)){ready=true;break;}}catch(java.io.IOException e){}Thread.sleep(100);}
        if(!ready)throw new IllegalStateException("controlled playback not ready");
        Bundle report=new Bundle();report.putString("result","CONTROLLED_PLAYER_READY");sendStatus(1,report);Thread.sleep(240000);
        PlayerCapture.unregister(handle);CaptureNative.terminate(handle);handle=0;finish(Activity.RESULT_OK,report);
    }catch(Throwable error){if(handle!=0){PlayerCapture.unregister(handle);CaptureNative.terminate(handle);}Bundle report=new Bundle();report.putString("failure",error.getClass().getSimpleName()+": "+error.getMessage());finish(Activity.RESULT_CANCELED,report);}}
    private void awaitState(DownloadStore.Job job,String expected)throws Exception {long end=System.currentTimeMillis()+20000;while(System.currentTimeMillis()<end){if(job.state.equals(expected))return;Thread.sleep(100);}throw new AssertionError("expected "+expected+" got "+job.state+" / "+job.stage);}
    private ScrollView content(Activity activity){ScrollView view=new ScrollView(activity);LinearLayout column=new LinearLayout(activity);column.setOrientation(1);
        for(int i=0;i<100;i++){TextView text=new TextView(activity);text.setText("相关测试视频 "+i);text.setTextSize(20);text.setHeight(110);column.addView(text);}view.addView(column);activity.setContentView(view);return view;}
    private void tap(float x,float y){long now=SystemClock.uptimeMillis();MotionEvent event=MotionEvent.obtain(now,now,MotionEvent.ACTION_DOWN,x,y,0);event.setSource(android.view.InputDevice.SOURCE_TOUCHSCREEN);sendPointerSync(event);event.recycle();event=MotionEvent.obtain(now,now+60,MotionEvent.ACTION_UP,x,y,0);event.setSource(android.view.InputDevice.SOURCE_TOUCHSCREEN);sendPointerSync(event);event.recycle();}
    private void swipe(float x,float y,float endX,float endY){long down=SystemClock.uptimeMillis();MotionEvent event=MotionEvent.obtain(down,down,MotionEvent.ACTION_DOWN,x,y,0);event.setSource(android.view.InputDevice.SOURCE_TOUCHSCREEN);sendPointerSync(event);event.recycle();
        for(int i=1;i<=8;i++){SystemClock.sleep(25);long now=SystemClock.uptimeMillis();event=MotionEvent.obtain(down,now,i==8?MotionEvent.ACTION_UP:MotionEvent.ACTION_MOVE,x+(endX-x)*i/8,y+(endY-y)*i/8,0);event.setSource(android.view.InputDevice.SOURCE_TOUCHSCREEN);sendPointerSync(event);event.recycle();}}
}
