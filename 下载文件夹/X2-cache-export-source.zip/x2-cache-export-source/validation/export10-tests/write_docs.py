from pathlib import Path
import subprocess,json
B=Path('/workspace/x2-analysis');R=B/'export10-tests';O=B/'output';sha=json.loads((O/'build-info.json').read_text())['output_sha256']
s=subprocess.check_output(['git','-C','/workspace/pqc-upload','show','1c48f22b5ac8fb96a608edca33ffeae9fff92197:下载文件夹/使用说明.md']).decode();s=s.replace('export9','export10').replace('版本码 17','版本码 18');a=s.index('APK SHA-256：');e=s.index('\n',a);s=s[:a]+'APK SHA-256：`'+sha+'`'+s[e:]
a=s.index('## 本次白屏修复');e=s.index('## 保留功能',a);s=s[:a]+'''## 本次测试版：播放器仍在 20 秒后停止

补上另一条本地限制：播放器在进度超过 20 秒、canWatch=false 时会自行暂停并回退。此前只跳过了上层“试看结束”标记，本版开发测试开关额外跳过这条暂停／回退分支。手动暂停和拖动仍保留，禁区白屏修复保留。

安装后在“管理 → 下载设置”保持开发测试开关开启，再重新打开禁区视频。默认不开启；覆盖 ARM64/x86_64，ARMv7 原逻辑不改。

**真实禁区视频播放超过 20 秒尚未验证通过。** 已通过的仅为完整位置回调指令测试：19、20、21、25、65 秒，开关开启时无自动暂停／回退，关闭时保持原行为；不能把这项测试当作真实播放。

云端访问两个内置配置入口返回 403，四条 API 主机在连接阶段被拒绝，因此没有取得真实媒体。服务器若仅提供短清单或试看分片，此本地改动不会补齐完整视频。本包为候选修复版，不宣称完成你要求的真实平台验收。

'''+s[e:];(O/'使用说明.md').write_text(s)
text='# export10 候选修复验证\n\nAPK SHA-256：`'+sha+'`\n\n**真实禁区视频播放 >20 秒：未通过验证（无法取得真实流，非已证明仍停止）。**\n\nPlayerController 的位置回调在 >20 秒且 canWatch=false 时，独立调用 pause 后 seek。加入测试开关分支避免该本地停止路径；保持位置写入、进度回调、通知及开关关闭时的原行为。\n\n40 个完整回调指令测试覆盖 ARM64/x86_64 × 开关开/关 × canWatch 开/关 × 19/20/21/25/65 秒。媒体调用由桩记录，不是实际播放，没有用测试视频替代平台视频。\n\n'
for name in ['network-results.json','comparison-results.json','installed-results.json','flutter-startup-results.json','payload-results.json']:
 p=R/name
 if p.exists():text+='## '+name+'\n\n```json\n'+p.read_text()+'\n```\n\n'
text+='完整 pause-results.json、getter-results.json、machine-results.json 在源码包 validation/export10-tests 中。下载功能字节码与 export9 完全一致，本次没有重复全部历史下载测试。\n';(O/'VALIDATION.md').write_text(text)
