exec(open('/workspace/x2-analysis/export3-tests/first_folder.py').read().split("end=time.monotonic()+60")[0])
import subprocess
end=time.monotonic()+60
while 'CONTROLLED_PLAYER_READY' not in (ROOT/'final-capture.log').read_text():
 if time.monotonic()>end:raise RuntimeError((ROOT/'final-capture.log').read_text())
 time.sleep(1)
files_before=ui.adb('shell','find','/sdcard/Download/X2_export3_B','-type','f').stdout.decode().splitlines()
button=ui.wait_node('final-two-buttons',lambda n:n.get('text')=='下载');nodes=ui.dump('final-two-buttons');manage=next(n for n in nodes if n.get('text')=='管理')
assert button.get('bounds').split(',')[1].split(']')[0]==manage.get('bounds').split(',')[1].split(']')[0]
ui.tap(button)
ui.wait_node('stayed-on-original-player',lambda n:n.get('text')=='下载')
current=ui.adb('shell','dumpsys','activity','activities').stdout.decode();assert 'mResumedActivity' in current and any('mResumedActivity' in line and 'SetupInfoActivity' in line for line in current.splitlines()),current
end=time.monotonic()+45
while time.monotonic()<end:
 files=ui.adb('shell','find','/sdcard/Download/X2_export3_B','-type','f').stdout.decode().splitlines()
 if len(files)==len(files_before)+1:break
 time.sleep(2)
else:raise RuntimeError('remembered folder output missing')
nodes=ui.dump('final-manage-button')
manage=next((n for n in nodes if n.get('text')=='管理'),None)
if manage is not None:ui.tap(manage)
else:
 assert any('网络不给力' in n.get('text','') for n in nodes),[n.get('text') for n in nodes]
 ui.adb('shell','am','start','-n',ui.PKG+'/org.x2.export.DownloadTasksActivity')
ui.wait_node('final-current-video-saved',lambda n:'受控测试视频' in n.get('text','') and '已保存 MP4' in n.get('text',''),seconds=30)
ui.shot('final-manager')
r={'side_by_side_download_manage_buttons':True,'download_click_stayed_on_original_player_activity':True,'remembered_folder_no_picker':True,'captured_original_MPV_source_saved':True,'new_file_in_folder_B':True}
(ROOT/'remembered-folder-results.json').write_text(json.dumps(r,indent=2));print(json.dumps(r),flush=True)
