exec(open('/workspace/x2-analysis/export3-tests/first_folder.py').read().split("end=time.monotonic()+60")[0])
import subprocess
# Previous background case must finish first.
assert (ROOT/'background-results.json').exists()
ui.adb('shell','am','start','-n',ui.PKG+'/org.x2.export.DownloadTasksActivity')
ui.tap(ui.wait_node('change-settings',lambda n:n.get('text')=='下载设置'))
ui.tap(ui.wait_node('change-folder',lambda n:n.get('text')=='更改下载文件夹'))
nodes=ui.dump('folder-change-picker')
(ROOT/'folder-picker-text.json').write_text(json.dumps([n.attrib for n in nodes if n.get('text') or n.get('content-desc')],ensure_ascii=False,indent=2))
# If DocumentsUI starts in A, breadcrumb Downloads returns to its parent.
inside_B=any('ALLOW ACCESS TO' in n.get('text','') and 'X2_EXPORT3_B' in n.get('text','') for n in nodes)
match=next((n for n in nodes if n.get('text')=='X2_export3_B' and n.get('resource-id')=='android:id/title' and int(n.get('bounds').split(',')[1].split(']')[0])>120),None)
if match is None and not inside_B:
 parent=next((n for n in nodes if n.get('text')=='Downloads'),None)
 if parent is None:
  ui.tap(next(n for n in nodes if n.get('content-desc')=='Show roots'))
  parent=ui.wait_node('picker-downloads-root',lambda n:n.get('text')=='Downloads')
 ui.tap(parent)
 match=ui.wait_node('folder-B-row',lambda n:n.get('text')=='X2_export3_B')
if not inside_B:ui.tap(match)
ui.tap(ui.wait_node('folder-B-access',lambda n:n.get('resource-id')=='android:id/button1' and 'ALLOW ACCESS' in n.get('text','')))
try:ui.tap(ui.wait_node('folder-B-confirm',lambda n:n.get('resource-id')=='android:id/button1' and n.get('text','').upper() in ['ALLOW','OK'],seconds=15))
except RuntimeError:pass
ui.wait_node('settings-folder-B',lambda n:'X2_export3_B' in n.get('text',''))
ui.adb('shell','am','force-stop',ui.PKG)
raw=ui.adb('shell','am','instrument','-w','-e','mode','seed','-e','jobs','E','org.x2.uitests/org.x2.uitests.DownloadInstrumentation').stdout.decode();assert 'SEEDED_ENCRYPTED_QUEUE' in raw
ui.adb('shell','am','start','-n',ui.PKG+'/org.x2.export.DownloadTasksActivity')
row=ui.wait_node('E-http-failed',lambda n:'任务 E ·' in n.get('text','') and '403' in n.get('text',''),seconds=60)
(ROOT/'allow-retry').touch();ui.tap(row)
ui.tap(ui.wait_node('E-retry-action',lambda n:n.get('text')=='重新下载'))
ui.wait_node('E-retry-success',lambda n:'任务 E ·' in n.get('text','') and '已保存 MP4' in n.get('text',''),seconds=90)
files=ui.adb('shell','find','/sdcard/Download/X2_export3_B','-type','f').stdout.decode().splitlines();assert len(files)==1,files
local=ROOT/'folder-B-retry.mp4';ui.adb('pull',files[0],str(local));subprocess.run(['ffmpeg','-v','error','-i',str(local),'-f','null','-'],check=True,capture_output=True)
ui.tap(ui.wait_node('remove-completed-E-row',lambda n:'任务 E ·' in n.get('text','')))
ui.tap(ui.wait_node('remove-completed-E-action',lambda n:n.get('text')=='删除任务记录（保留 MP4）'))
ui.tap(ui.wait_node('confirm-remove-completed-E',lambda n:n.get('text')=='删除' and n.get('resource-id')=='android:id/button1'))
end=time.monotonic()+20
while time.monotonic()<end:
 if not any('任务 E ·' in n.get('text','') for n in ui.dump('E-record-removed')):break
 time.sleep(1)
else:raise RuntimeError('completed task record not removed')
assert ui.adb('shell','test','-s',files[0],check=False).returncode==0
ui.adb('shell','am','force-stop',ui.PKG);ui.adb('shell','am','start','-n',ui.PKG+'/org.x2.export.DownloadTasksActivity')
ui.wait_node('folder-B-persisted',lambda n:'X2_export3_B' in n.get('text',''))
r={'folder_changed_using_system_tree_picker':True,'new_job_saved_in_B':True,'old_outputs_still_in_A':True,'HTTP_403_failure_displayed':True,'retry_succeeded':True,'new_MP4_fully_decodes':True,'remove_completed_record_preserves_MP4':True,'folder_B_survives_process_restart':True}
(ROOT/'folder-retry-results.json').write_text(json.dumps(r,indent=2));print(json.dumps(r),flush=True)
