from pathlib import Path
import subprocess,threading,http.server,json,tempfile
B=Path('/workspace/x2-analysis');R=B/'export14-tests';C=R/'host-classes';C.mkdir(exist_ok=True);work=R/'host-work';work.mkdir(exist_ok=True)
java='''import org.x2.export.MediaDownloader;import java.io.File;public class InspectMain{public static void main(String[] a)throws Exception{try{System.out.print(MediaDownloader.inspect(a[0],"FixtureAgent","",new String[]{"aut: FIXTURE_ONLY_SECRET"},new File(a[1]),null));}catch(java.io.IOException e){System.out.print("error="+e.getClass().getSimpleName());}}}'''
(R/'InspectMain.java').write_text(java);subprocess.run(['java','-jar',str(B/'patch-tools/ecj.jar'),'-source','1.8','-target','1.8','-encoding','UTF-8','-d',str(C),str(B/'export-patch/src/org/x2/export/MediaDownloader.java'),str(R/'InspectMain.java')],check=True)
requests=[]
def playlist(count,duration,end=True,key=False):return ('#EXTM3U\n'+('#EXT-X-KEY:METHOD=AES-128,URI="key?secret=FIXTURE_ONLY_SECRET"\n' if key else '')+''.join('#EXTINF:'+str(duration)+',\nseg'+str(i)+'.ts?secret=FIXTURE_ONLY_SECRET\n' for i in range(count))+('#EXT-X-ENDLIST\n' if end else '')).encode()
class H(http.server.BaseHTTPRequestHandler):
 def do_GET(self):
  path=self.path.split('?')[0];requests.append((path,self.headers.get('aut')))
  if path=='/redirect':self.send_response(302);self.send_header('Location','http://localhost:'+str(self.server.server_port)+'/long');self.end_headers();return
  if path=='/denied':self.send_response(403);self.end_headers();return
  values={'/short':playlist(2,6.035),'/long':playlist(15,6),'/live':playlist(3,6,False),'/encrypted':playlist(2,6,True,True),'/invalid':playlist(1,'NaN'),'/direct':b'0000ftypmp42'+b'x'*10000,'/json':b'{"secret":"FIXTURE_ONLY_SECRET"}', '/huge':b'#EXTM3U\n'+b'#'+b'x'*(4*1024*1024),'/master':b'#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=100\nshort\n#EXT-X-STREAM-INF:BANDWIDTH=200\nlong\n'}
  body=values.get(path,b'UNEXPECTED_SEGMENT_ACCESS');self.send_response(200);self.send_header('Content-Length',str(len(body)));self.end_headers()
  try:self.wfile.write(body)
  except OSError:pass
 def log_message(self,*a):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),H);threading.Thread(target=server.serve_forever,daemon=True).start();results=[]
try:
 for route,expected in [('short','manifest_seconds=12.070'),('long','manifest_seconds=90.000'),('live','endlist=0'),('encrypted','encrypted=1'),('master','manifest_depth=1'),('redirect','manifest_seconds=90.000'),('direct','kind=direct_or_unknown'),('json','kind=json'),('invalid','error='),('huge','error='),('denied','error=')]:
  report=subprocess.check_output(['java','-cp',str(C),'InspectMain','http://127.0.0.1:'+str(server.server_port)+'/'+route+'?secret=FIXTURE_ONLY_SECRET',str(work)],text=True,timeout=30)
  assert expected in report,(route,report);assert 'FIXTURE_ONLY_SECRET' not in report and 'http://' not in report and '.ts' not in report
  results.append({'case':route,'passed':True,'report':report})
 assert not any('/seg' in p or '/key' in p for p,a in requests)
 assert next(a for p,a in requests if p=='/short')=='FIXTURE_ONLY_SECRET'
 redirects=[(p,a) for p,a in requests if p=='/long'];assert redirects[-1][1] is None,redirects
 assert not list(work.iterdir()),'temporary directories leaked'
 (R/'inspection-results.json').write_text(json.dumps({'passed':True,'cases':results,'segment_and_key_requests':0,'cross_origin_auth_stripped':True,'report_excludes_fixture_credentials':True,'temporary_directories_cleaned':True},indent=2));print('PASS 11 manifest/transport/privacy cases, zero key or segment fetches')
finally:server.shutdown();server.server_close()
