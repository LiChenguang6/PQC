exec(open('/workspace/x2-analysis/export3-tests/first_folder.py').read().split("end=time.monotonic()+60")[0])
ui.wait_node('final-current-video-saved',lambda n:'受控测试视频' in n.get('text','') and '已保存 MP4' in n.get('text',''),seconds=30)
ui.shot('final-manager')
r={'side_by_side_download_manage_buttons':True,'download_click_stayed_on_original_player_activity':True,'remembered_folder_no_picker':True,'captured_original_MPV_source_saved':True,'new_file_in_folder_B':True}
(ROOT/'remembered-folder-results.json').write_text(json.dumps(r,indent=2));print(json.dumps(r),flush=True)
