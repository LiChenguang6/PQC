from pathlib import Path
import subprocess,json,hashlib,http.server,threading
B=Path('/workspace/x2-analysis');R=B/'export11-tests';A=str(B/'android-sdk/platform-tools/adb');P='com.example.yinqishe_export';apk=B/'output/X2-cache-export.apk'
def run(*args,timeout=60):return subprocess.check_output([A,*args],timeout=timeout,text=True)
print(run('push',str(apk),'/data/local/tmp/X2-export11.apk'),flush=True)
try:print(run('shell','pm','install','-r','/data/local/tmp/X2-export11.apk',timeout=150),flush=True)
except subprocess.TimeoutExpired:print('Verifying payload after install response timeout',flush=True)
p=run('shell','pm','path',P).strip().split('package:')[1];sha=run('exec-out','sha256sum',p).split()[0];assert sha==hashlib.sha256(apk.read_bytes()).hexdigest();(R/'installed-results.json').write_text(json.dumps(dict(installed_sha256=sha,matches_delivery=True),indent=2))
subprocess.run(['python3',str(B/'ui-download-tests/build_test_apk.py')],check=True,stdout=(R/'test-build.log').open('w'),stderr=subprocess.STDOUT,timeout=180)
class Handler(http.server.BaseHTTPRequestHandler):
 def do_GET(self):
  data=(B/'capture-tests/fixture/capture-fixture.mp4').read_bytes();self.send_response(200);self.send_header('Content-Length',str(len(data)));self.end_headers()
  try:self.wfile.write(data)
  except OSError:pass
 def log_message(self,*args):pass
server=http.server.ThreadingHTTPServer(('127.0.0.1',18781),Handler);server.daemon_threads=True;threading.Thread(target=server.serve_forever,daemon=True).start()
try:
 run('reverse','tcp:18781','tcp:18781');run('shell','am','force-stop',P)
 log=run('shell','am','instrument','-w','-e','mode','diagnostic11','-e','fixture','http://127.0.0.1:18781/media.mp4?DO_NOT_REPORT_URI','-e','activity','com.example.yinqishe_app.MainActivity','org.x2.uitests/org.x2.uitests.DownloadInstrumentation',timeout=200)
 (R/'diagnostic-runtime.log').write_text(log);print(log,flush=True);assert 'DIAGNOSTIC_SYNC_WITHOUT_MAIN_FOCUS_MPV_METRICS_PRIVACY_AND_CLIPBOARD_PASS' in log
 (R/'diagnostic-results.json').write_text(json.dumps(dict(passed=True,flag_synchronizes_without_Main_window_focus=True,original_MPV_numeric_properties_read=True,diagnostic_contains_no_source_uris_headers_titles=True,settings_scrolls=True,report_copied_to_clipboard=True,real_forbidden_playback_over_20_seconds_verified=False,apk_sha256=sha),indent=2))
finally:server.shutdown();server.server_close();run('reverse','--remove','tcp:18781')
