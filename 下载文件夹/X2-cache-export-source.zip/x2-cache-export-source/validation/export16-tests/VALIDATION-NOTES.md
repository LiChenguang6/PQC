# 验证记录说明

首次与第二次集成测试在切换完成网格时发现恢复滚动位置导致越界。最初仅限制索引为非负仍未解决。进一步确认 GridView 不能使用 ListView 的 setSelectionFromTop 恢复路径，改为 GridView.setSelection；测试的滚动辅助方法也同步改用网格支持的接口。最终交付文件以 ui-results.json 中的 SHA 为准，失败构建不交付。

当前 UI 测试源码位于 validation/ui-download-tests/src/org/x2/uitests/DownloadInstrumentation.java。

最终 UI 三组测试均通过。启动检查首次在原 libflutter 渲染线程出现 SIGSEGV，保留 startup.log；重新启动检查见 startup-retry.log。27 个 native 库与 export15 字节一致。
