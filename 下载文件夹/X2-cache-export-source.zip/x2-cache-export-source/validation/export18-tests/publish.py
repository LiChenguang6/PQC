from pathlib import Path
import hashlib,json,zipfile,subprocess,shutil,urllib.request,urllib.parse,re
B=Path('/workspace/x2-analysis');P=B/'export-patch';R=B/'export18-tests';O=B/'output';G=Path('/workspace/pqc-upload');F='下载文件夹'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(*a):return subprocess.check_output(a,text=True).strip()
h=sha(O/'X2-cache-export.apk');ui=json.loads((R/'ui-results.json').read_text());assert ui['apk_sha256']==h and all(ui[k]['passed'] for k in ['dedupe18','dedupe18Reload'])
with zipfile.ZipFile(G/F/'X2-cache-export-source.zip') as z:
 changed=[]
 for p in (P/'src').rglob('*.java'):
  key='x2-cache-export-source/export-patch/'+str(p.relative_to(P))
  if key not in z.namelist() or p.read_bytes()!=z.read(key):changed.append(p.name)
 assert set(changed)=={'DownloadStore.java','DownloadService.java','VideoIdentity.java'},changed
with zipfile.ZipFile(G/F/'X2-cache-export.apk') as old,zipfile.ZipFile(O/'X2-cache-export.apk') as new:
 libs=[n for n in old.namelist() if n.startswith('lib/')];assert all(old.read(n)==new.read(n) for n in libs)
(O/'使用说明.md').write_text('''# X2 保存导出版 export18

本版仅增加视频源去重，保留 export17 的界面与系统导航栏设置。

点击下载时，会检查全部保留的任务记录，包括正在下载、暂停、失败、取消与下载完成。同一个源已有记录时不再新增；提示在管理中继续、重试或查看原任务。需要重新下载时，先删除原记录；仅删记录不会删除 MP4，注意自行决定是否保留旧文件。

不以标题判断：同标题但不同视频源可以分别下载。优先使用与当前播放地址精确匹配的视频编号及类型识别视频，可识别该编号下播放地址或令牌变化；没有编号时按规范化后的完整源地址指纹识别，保留查询参数以免把不同视频误认为同一个。不能保证识别无编号且源地址发生变化的视频。

指纹随加密队列保存，下载成功清除播放地址后仍可判断，重启应用也保留。保留中的旧版未完成任务会从仍有的播放地址生成指纹；旧版已完成记录已清除源地址，无法追溯识别。清除应用数据、删除记录后，相关去重依据也被删除。此功能不扫描或删除已有重复 MP4，不使用标题猜测，也不对整个视频做内容哈希。

下载设置仍可开关预览图、每行 1–4 个，视频预览页保留系统导航栏。沿用原包名和签名，请直接覆盖安装，不要先卸载。

APK SHA-256：`'''+h+'`\n')
(O/'VALIDATION.md').write_text('''# export18 验证

APK SHA-256：`'''+h+'''`

Android 10/API29 x86_64 模拟器实际运行：

- 相同规范化源地址、不同标题，在排队、下载、暂停、失败、取消、删除中及完成状态均拒绝重复记录。
- 同标题不同查询资源值允许分别入队；不匹配详情不使用视频编号。
- 相同精确匹配视频编号、类型在源地址变化后仍拒绝重复；确切不同编号的复用端点允许分别入队。
- 8 个线程同时添加同源任务，恰好 1 个成功、7 个拒绝。
- 完成任务清除原地址后保存，结束进程再打开仍可识别；实际 DownloadService.enqueue 拒绝已完成视频，不启动下载。
- 与 export17 源码包对比，业务改动仅 DownloadStore、DownloadService 和新增 VideoIdentity；所有原生库逐字节一致。界面与播放器未改，未重复进行相关全套回归。

旧版已完成记录没有保留源，不支持追溯去重；无精确编号且 URL 改变时也不能保证识别。旧版验证材料为历史记录。
''')
p=P/'README.md';t=p.read_text().replace('源码（export17）','源码（export18）',1).replace('版本码 25','版本码 26',1);i=t.index('## export17');t=t[:i]+'''## export18：源指纹去重

统一加密队列 add 锁内检查源地址 SHA-256 和精确 URI 匹配的视频 ID/类型 SHA-256，避免连点竞争。原源地址在成功后仍清除，只保留加密存储中的指纹。失败/取消任务复用原管理操作，完成任务提示查看；明确不同 ID 可使用同一播放端点。完整查询参数保留，不按标题或猜测性删除令牌去重。旧版保留的源可迁移，旧版成功记录无源不能追溯。删除任务记录允许重新入队，不扫描本地文件内容。测试见 validation/export18-tests。

'''+t[i:];p.write_text(t)
subprocess.run(['python3',str(P/'package_source.py')],check=True)
with zipfile.ZipFile(O/'X2-cache-export-source.zip') as z:assert z.testzip() is None and not any(n.endswith(('.apk','.p12')) for n in z.namelist())
assert not run('git','-C',str(G),'status','--porcelain')
subprocess.run(['git','-C',str(G),'fetch','origin','main'],check=True);subprocess.run(['git','-C',str(G),'merge','--ff-only','origin/main'],check=True)
names=['X2-cache-export.apk','X2-cache-export-source.zip','使用说明.md','VALIDATION.md']
for n in names:shutil.copy2(O/n,G/F/n)
subprocess.run(['git','-C',str(G),'add','--',*[F+'/'+n for n in names]],check=True)
assert set(run('git','-C',str(G),'-c','core.quotepath=false','diff','--cached','--name-only').splitlines())=={F+'/'+n for n in names}
subprocess.run(['git','-C',str(G),'commit','-m','X2 export18: prevent duplicate downloads using persisted source identity'],check=True);subprocess.run(['git','-C',str(G),'push','origin','HEAD:main'],check=True)
c=run('git','-C',str(G),'rev-parse','HEAD');url='https://raw.githubusercontent.com/LiChenguang6/PQC/'+c+'/'+urllib.parse.quote(F+'/X2-cache-export.apk')
with urllib.request.urlopen(url,timeout=60) as response:assert hashlib.sha256(response.read()).hexdigest()==h
result={'commit':c,'url':url,'sha256':h};(R/'published-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False))
