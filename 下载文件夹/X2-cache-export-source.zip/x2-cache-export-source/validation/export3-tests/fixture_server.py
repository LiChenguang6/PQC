from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit,parse_qs
import json,time,threading
ROOT=Path('/workspace/x2-analysis/export3-tests')
MEDIA=Path('/workspace/x2-analysis/capture-tests/fixture/capture-fixture.mp4').read_bytes()
lock=threading.Lock();active=set();max_active=0;events=[]
def record(kind,job):
 global max_active
 with lock:
  if kind=='start':active.add(job)
  elif kind=='finish':active.discard(job)
  max_active=max(max_active,len(active));events.append({'kind':kind,'job':job,'time':time.time(),'active':sorted(active)})
  (ROOT/'server-results.json').write_text(json.dumps({'max_active':max_active,'events':events},indent=2))
class Handler(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def do_GET(self):
  path=urlsplit(self.path).path
  job=path.rsplit('/',1)[-1].split('.')[0]
  if path.startswith('/retry/') and not (ROOT/'allow-retry').exists():self.send_error(403);return
  slow=path.startswith('/slow/')
  if slow:record('start',job)
  try:
   self.send_response(200);self.send_header('Content-Type','video/mp4');self.send_header('Content-Length',str(len(MEDIA)));self.end_headers()
   offset=0
   while offset<len(MEDIA):
    waiting=slow and not (ROOT/("release-"+job)).exists()
    size=128 if waiting else len(MEDIA)
    chunk=MEDIA[offset:offset+size];self.wfile.write(chunk);self.wfile.flush();offset+=len(chunk)
    if waiting:time.sleep(1)
  except (BrokenPipeError,ConnectionResetError):pass
  finally:
   if slow:record('finish',job)
if __name__=='__main__':
 (ROOT/'allow-retry').unlink(missing_ok=True)
 ThreadingHTTPServer(('127.0.0.1',18766),Handler).serve_forever()
