import urllib.request,urllib.error,json,concurrent.futures
from pathlib import Path
hosts=['d1r1vv8zvbqvut.cloudfront.net','drlcjvmgp6ra1.cloudfront.net','rea.5mv4d9bn.work','rea.5n4v4dkk.work','rea.66zif0m5.work','rea.68zvqszy.work']
def probe(host):
 url='https://'+host+('/emys.json' if host.endswith('cloudfront.net') else '/');item={'host':host}
 try:
  with urllib.request.urlopen(url,timeout=15) as response:item.update(status=response.status,bytes=len(response.read(1048576)))
 except urllib.error.HTTPError as e:item.update(status=e.code,headers={k:v for k,v in e.headers.items() if k.lower() in ['server','content-type','x-cache','x-mitmproxy-blocked-reason']},error_body=e.read(160).decode(errors='replace'))
 except Exception as e:item.update(error=str(e))
 return item
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:out=list(pool.map(probe,hosts))
Path('/workspace/x2-analysis/export10-tests/network-results.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
