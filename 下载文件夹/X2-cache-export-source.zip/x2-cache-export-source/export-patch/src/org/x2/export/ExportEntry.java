package org.x2.export;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;

public final class ExportEntry {
    public static void install(final Activity activity) {
        final Button button = new Button(activity);
        button.setText("保存/导出");
        button.setTextSize(12);
        button.setTextColor(Color.WHITE);
        button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xDD395A85));
        button.setContentDescription("保存当前视频或导出缓存MP4，可拖动位置");
        final float density = activity.getResources().getDisplayMetrics().density;
        final FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Math.round(100 * density), Math.round(44 * density),
                Gravity.RIGHT | Gravity.TOP);
        lp.rightMargin = Math.round(8 * density);
        lp.topMargin = Math.round(80 * density);
        activity.addContentView(button, lp);
        button.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                new AlertDialog.Builder(activity).setTitle("保存视频")
                    .setItems(new String[] {"保存当前播放视频", "导出已下载缓存"},
                        new android.content.DialogInterface.OnClickListener() {
                            @Override public void onClick(android.content.DialogInterface dialog, int which) {
                                if (which == 1) {
                                    activity.startActivity(new Intent(activity, CacheExportActivity.class));
                                    return;
                                }
                                button.setEnabled(false); button.setText("正在读取…");
                                new Thread(new Runnable() {
                                    @Override public void run() {
                                        try {
                                            final PlayerCapture.Source captured = PlayerCapture.snapshot();
                                            activity.runOnUiThread(new Runnable() { @Override public void run() {
                                                if (activity.isFinishing()) return;
                                                if (isLocalCache(captured.uri))
                                                    activity.startActivity(new Intent(activity, CacheExportActivity.class));
                                                else PlayingExportActivity.open(activity, captured);
                                            }});
                                        } catch (final Exception error) {
                                            activity.runOnUiThread(new Runnable() { @Override public void run() {
                                                if (!activity.isFinishing()) new AlertDialog.Builder(activity)
                                                    .setTitle("未能读取当前视频")
                                                    .setMessage(error.getMessage() == null ? "请开始播放视频后重试。" : error.getMessage())
                                                    .setPositiveButton("知道了", null).show();
                                            }});
                                        } finally {
                                            activity.runOnUiThread(new Runnable() { @Override public void run() {
                                                button.setEnabled(true); button.setText("保存/导出");
                                            }});
                                        }
                                    }
                                }, "X2-read-player").start();
                            }
                        }).show();
            }
        });
        button.setOnTouchListener(new View.OnTouchListener() {
            float startX, startY, oldX, oldY;
            boolean moved;
            @Override public boolean onTouch(View view, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    startX = event.getRawX(); startY = event.getRawY();
                    oldX = view.getX(); oldY = view.getY(); moved = false;
                } else if (event.getAction() == MotionEvent.ACTION_MOVE) {
                    float dx = event.getRawX() - startX, dy = event.getRawY() - startY;
                    if (Math.abs(dx) + Math.abs(dy) > 12 * density) moved = true;
                    if (moved) {
                        View parent = (View)view.getParent();
                        view.setX(Math.max(0, Math.min(oldX + dx, parent.getWidth() - view.getWidth())));
                        view.setY(Math.max(0, Math.min(oldY + dy, parent.getHeight() - view.getHeight())));
                    }
                } else if (event.getAction() == MotionEvent.ACTION_UP && moved) return true;
                return moved;
            }
        });
    }
    private static boolean isLocalCache(String value) {
        try {
            java.net.URI uri = new java.net.URI(value);
            String host = uri.getHost();
            return ("localhost".equalsIgnoreCase(host) || "127.0.0.1".equals(host) || "[::1]".equals(host))
                    && uri.getPath() != null && uri.getPath().matches("/[0-9]+/index\\.m3u8");
        } catch (Exception ignored) { return false; }
    }
    private ExportEntry() {}
}
